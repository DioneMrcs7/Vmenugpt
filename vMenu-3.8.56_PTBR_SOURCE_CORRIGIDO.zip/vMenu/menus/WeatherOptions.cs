using System.Collections.Generic;

using CitizenFX.Core;

using MenuAPI;

using vMenuShared;

using static vMenuClient.CommonFunctions;
using static vMenuShared.PermissionsManager;

namespace vMenuClient.menus
{
    public class WeatherOptions
    {
        // Variables
        private Menu menu;
        public MenuCheckboxItem dynamicWeatherEnabled;
        public MenuCheckboxItem blackout;
        public MenuCheckboxItem vehicleBlackout;
        public MenuCheckboxItem snowEnabled;
        public static readonly List<string> weatherTypes = new()
        {
            "EXTRASUNNY",
            "CLEAR",
            "NEUTRAL",
            "SMOG",
            "FOGGY",
            "CLOUDS",
            "OVERCAST",
            "CLEARING",
            "RAIN",
            "THUNDER",
            "BLIZZARD",
            "SNOW",
            "SNOWLIGHT",
            "XMAS",
            "HALLOWEEN"
        };
        
        private void CreateMenu()
        {
            // Create the menu.
            menu = new Menu(Game.Player.Name, "Opções de Clima");

            dynamicWeatherEnabled = new MenuCheckboxItem("Ativar/Desativar Clima Dinâmico", "Ative ou desative dynamic clima alterars.", EventManager.DynamicWeatherEnabled);
            blackout = new MenuCheckboxItem("Ativar/Desativar Apagão", "isto desativars ou ativars todos luzes across o mapa.", EventManager.IsBlackoutEnabled);
            vehicleBlackout = new MenuCheckboxItem("Apagão das Luzes dos Veículos", "isto desativars ou ativars Todos os pneus do veículo luzes across o mapa.", !EventManager.IsVehicleLightsEnabled);
            snowEnabled = new MenuCheckboxItem("Ativar Neve Effects", "Isto irá force neve para appear em o chão e ativar neve particle efeitos para peds e veículos. Combine com X-MAS ou Neve Leve clima para best results.", ConfigManager.GetSettingsBool(ConfigManager.Setting.vmenu_enable_snow));
            
            var extrasunny = new MenuItem("Muissoo Ensolarado", "Definir o clima para ~y~extra sunny~s~!") { ItemData = "EXTRASUNNY" };
            var clear = new MenuItem("Limpo", "Definir o clima para ~y~clear~s~!") { ItemData = "CLEAR" };
            var neutral = new MenuItem("Neutro", "Definir o clima para ~y~neutral~s~!") { ItemData = "NEUTRAL" };
            var smog = new MenuItem("Poluição", "Definir o clima para ~y~smog~s~!") { ItemData = "SMOG" };
            var foggy = new MenuItem("Neblina", "Definir o clima para ~y~foggy~s~!") { ItemData = "FOGGY" };
            var clouds = new MenuItem("Cloudy", "Definir o clima para ~y~clouds~s~!") { ItemData = "CLOUDS" };
            var overcast = new MenuItem("Nublado", "Definir o clima para ~y~overcast~s~!") { ItemData = "OVERCAST" };
            var clearing = new MenuItem("Abrindo", "Definir o clima para ~y~clearing~s~!") { ItemData = "CLEARING" };
            var rain = new MenuItem("Rainy", "Definir o clima para ~y~rain~s~!") { ItemData = "RAIN" };
            var thunder = new MenuItem("Trovoada", "Definir o clima para ~y~thunder~s~!") { ItemData = "THUNDER" };
            var blizzard = new MenuItem("Nevasca", "Definir o clima para ~y~blizzard~s~!") { ItemData = "BLIZZARD" };
            var snow = new MenuItem("Neve", "Definir o clima para ~y~neve~s~!") { ItemData = "SNOW" };
            var snowlight = new MenuItem("Neve Leve", "Definir o clima para ~y~light neve~s~!") { ItemData = "SNOWLIGHT" };
            var xmas = new MenuItem("X-MAS Neve", "Definir o clima para ~y~x-mas~s~!") { ItemData = "XMAS" };
            var halloween = new MenuItem("Halloween", "Definir o clima para ~y~htodosoween~s~!") { ItemData = "HALLOWEEN" };
            var removeclouds = new MenuItem("Remover Todos Nuvens", "Remover todos clouds de o sky!");
            var randomizeclouds = new MenuItem("Aleatórioize Nuvens", "Add random clouds para o sky!");

            if (IsAllowed(Permission.WODynamic))
            {
                menu.AddMenuItem(dynamicWeatherEnabled);
            }
            if (IsAllowed(Permission.WOBlackout))
            {
                menu.AddMenuItem(blackout);
            }
            if (IsAllowed(Permission.WOVehBlackout))
            {
                menu.AddMenuItem(vehicleBlackout);
            }
            if (IsAllowed(Permission.WOSetWeather))
            {
                menu.AddMenuItem(snowEnabled);
                menu.AddMenuItem(extrasunny);
                menu.AddMenuItem(clear);
                menu.AddMenuItem(neutral);
                menu.AddMenuItem(smog);
                menu.AddMenuItem(foggy);
                menu.AddMenuItem(clouds);
                menu.AddMenuItem(overcast);
                menu.AddMenuItem(clearing);
                menu.AddMenuItem(rain);
                menu.AddMenuItem(thunder);
                menu.AddMenuItem(blizzard);
                menu.AddMenuItem(snow);
                menu.AddMenuItem(snowlight);
                menu.AddMenuItem(xmas);
                menu.AddMenuItem(halloween);
            }
            if (IsAllowed(Permission.WORandomizeClouds))
            {
                menu.AddMenuItem(randomizeclouds);
            }

            if (IsAllowed(Permission.WORemoveClouds))
            {
                menu.AddMenuItem(removeclouds);
            }

            menu.OnItemSelect += (sender, item, index2) =>
            {
                if (item == removeclouds)
                {
                    ModifyClouds(true);
                }
                else if (item == randomizeclouds)
                {
                    ModifyClouds(false);
                }
                else if (item.ItemData is string weatherType)
                {
                    Notify.Custom($"O clima irá ser alterard para ~y~{issoem.Text}~s~. Isto irá receber {EventGerenciarr.ClimaAlterarHorário} segundos.");
                    UpdateServerWeather(weatherType, EventManager.DynamicWeatherEnabled, EventManager.IsSnowEnabled);
                }
            };

            menu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == dynamicWeatherEnabled)
                {
                    Notify.Custom($"Dynamic clima alterars estão agora {(_checked ? "~g~enabled" : "~r~disabled")}~s~.");
                    UpdateServerWeather(EventManager.GetServerWeather, _checked, EventManager.IsSnowEnabled);
                }
                else if (item == blackout)
                {
                    Notify.Custom($"Apagão mode é agora {(_checked ? "~g~enabled" : "~r~disabled")}~s~.");
                    UpdateServerBlackout(_checked);
                }
                else if (item == vehicleBlackout)
                {
                    Notify.Custom($"Veículo light blackout mode é agora {(_checked ? "~g~enabled" : "~r~disabled")}~s~.");
                    UpdateServerVehicleBlackout(!_checked);
                }
                else if (item == snowEnabled)
                {
                    if (EventManager.GetServerWeather is "XMAS" or "SNOWLIGHT" or "SNOW" or "BLIZZARD")
                    {
                        Notify.Custom($"Neve efeitos não pode ser desativado quando clima é ~y~{EventGerenciarr.GetServidorClima}~s~.");
                        return;
                    }

                    Notify.Custom($"Neve efeitos irá agora ser forced {(_checked ? "~g~enabled" : "~r~disabled")}~s~.");
                    UpdateServerWeather(EventManager.GetServerWeather, EventManager.DynamicWeatherEnabled, _checked);
                }
            };
        }



        /// <summary>
        /// Create the menu if it doesn't exist, and then returns it.
        /// </summary>
        /// <returns>The Menu</returns>
        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }
    }
}
