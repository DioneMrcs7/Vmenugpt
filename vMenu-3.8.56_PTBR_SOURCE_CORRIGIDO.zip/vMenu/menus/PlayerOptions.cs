using System;
using System.Collections.Generic;
using System.Linq;

using CitizenFX.Core;

using MenuAPI;

using vMenuClient.data;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.PermissionsManager;

namespace vMenuClient.menus
{
    public class PlayerOptions
    {
        // Menu variable, will be defined in CreateMenu()
        private Menu menu;

        // Public variables (getters only), return the private variables.
        public bool PlayerGodMode { get; private set; } = UserDefaults.PlayerGodMode;
        public bool PlayerInvisible { get; private set; } = false;
        public bool PlayerStamina { get; private set; } = UserDefaults.UnlimitedStamina;
        public bool PlayerFastRun { get; private set; } = UserDefaults.FastRun;
        public bool PlayerFastSwim { get; private set; } = UserDefaults.FastSwim;
        public bool PlayerSuperJump { get; private set; } = UserDefaults.SuperJump;
        public bool PlayerNoRagdoll { get; private set; } = UserDefaults.NoRagdoll;
        public bool PlayerNeverWanted { get; private set; } = UserDefaults.NeverWanted;
        public bool PlayerIsIgnored { get; private set; } = UserDefaults.EveryoneIgnorePlayer;
        public bool PlayerStayInVehicle { get; private set; } = UserDefaults.PlayerStayInVehicle;
        public bool PlayerFrozen { get; private set; } = false;

        public int PlayerBlood { get; private set; } = 0;

        private readonly Menu CustomDrivingStyleMenu = new("Driving Estilo", "Custom Driving Estilo");

        /// <summary>
        /// Creates the menu.
        /// </summary>
        private void CreateMenu()
        {
            #region create menu and menu items
            // Create the menu.
            menu = new Menu(Game.Player.Name, "Opções do Jogador");

            // Create all checkboxes.
            var playerGodModeCheckbox = new MenuCheckboxItem("Invencibilidade", "Deixa você invencível.", PlayerGodMode);
            var invisibleCheckbox = new MenuCheckboxItem("Invisível", "Makes você invisível para yourself e outros.", PlayerInvisible);
            var unlimitedStaminaCheckbox = new MenuCheckboxItem("Stamina Infinissoa", "Todosows você para run para sempre sem reduzir velocidade ou recebendo dano.", PlayerStamina);
            var fastRunCheckbox = new MenuCheckboxItem("Corrida Rápida", "obter ~g~Snail~s~ poderes e run very fast!", PlayerFastRun);
            SetRunSprintMultiplierForPlayer(Game.Player.Handle, PlayerFastRun && IsAllowed(Permission.POFastRun) ? 1.49f : 1f);
            var fastSwimCheckbox = new MenuCheckboxItem("Nado Rápido", "obter ~g~Snail 2.0~s~ poderes e swim muito rápido!", PlayerFastSwim);
            SetSwimMultiplierForPlayer(Game.Player.Handle, PlayerFastSwim && IsAllowed(Permission.POFastSwim) ? 1.49f : 1f);
            var superJumpCheckbox = new MenuCheckboxItem("Super Pulo", "obter ~g~Snail 3.0~s~ poderes e jump like um campeão!", PlayerSuperJump);
            var noRagdollCheckbox = new MenuCheckboxItem("Sem Ragdoll", "Desativars jogador ragdoll, fazers você não cair desligado seu moto anymais.", PlayerNoRagdoll);
            var neverWantedCheckbox = new MenuCheckboxItem("Nunca Procurado", "Desativars todos desejaed levels.", PlayerNeverWanted);
            var everyoneIgnoresPlayerCheckbox = new MenuCheckboxItem("Todos Ignoram o Jogador", "Todos deixarão você em paz.", PlayerIsIgnored);
            var playerStayInVehicleCheckbox = new MenuCheckboxItem("Permanecer no Veículo", "quando isto é ativado, NPCs irá não ser able para puxar você fora de seu veículo se eles obter irritados em você.", PlayerStayInVehicle);
            var playerFrozenCheckbox = new MenuCheckboxItem("Congelar Jogador", "Freezes seu localização atual.", PlayerFrozen);

            // Wanted level options
            var wantedLevelList = new List<string> { "Sem Nível de Procurado", "1", "2", "3", "4", "5" };
            var setWantedLevel = new MenuListItem("Definir Nível de Procurado", wantedLevelList, GetPlayerWantedLevel(Game.Player.Handle), "Definir seu desejaed level selecionando um valor, e pressioneing entrar.");
            var setArmorItem = new MenuListItem("Definir Tipo de Colete", new List<string> { "Sem Colete", GetLabelText("WT_BA_0"), GetLabelText("WT_BA_1"), GetLabelText("WT_BA_2"), GetLabelText("WT_BA_3"), GetLabelText("WT_BA_4"), }, 0, "Definir o colete level/type para seu jogador.");

            // Blood level options
            var clearBloodBtn = new MenuItem("Limpar Sangue", "Limpo o sangue desligado seu jogador.");
            var bloodList = new List<string> { "BigHitByVehicle", "SCR_Torture", "SCR_TrevorTreeBang", "HOSPITAL_0", "HOSPITAL_1", "HOSPITAL_2", "HOSPITAL_3", "HOSPITAL_4", "HOSPITAL_5", "HOSPITAL_6", "HOSPITAL_7", "HOSPITAL_8", "HOSPITAL_9", "Explosion_Med", "Skin_Melee_0", "Explosion_Large", "Car_Crash_Light", "Car_Crash_Heavy", "Fall_Low", "Fall", "HitByVehicle", "BigRunOverByVehicle", "RunOverByVehicle", "TD_KNIFE_FRONT", "TD_KNIFE_FRONT_VA", "TD_KNIFE_FRONT_VB", "TD_KNIFE_REAR", "TD_KNIFE_REAR_VA", "TD_KNIFE_REAR_VB", "TD_KNIFE_STEALTH", "TD_MELEE_FRONT", "TD_MELEE_REAR", "TD_MELEE_STEALTH", "TD_MELEE_BATWAIST", "TD_melee_face_l", "MTD_melee_face_r", "MTD_melee_face_jaw", "TD_PISTOL_FRONT", "TD_PISTOL_FRONT_KILL", "TD_PISTOL_REAR", "TD_PISTOL_REAR_KILL", "TD_RIFLE_FRONT_KILL", "TD_RIFLE_NONLETHAL_FRONT", "TD_RIFLE_NONLETHAL_REAR", "TD_SHOTGUN_FRONT_KILL", "TD_SHOTGUN_REAR_KILL" };
            var setBloodLevel = new MenuListItem("Definir Nível de Sangue", bloodList, PlayerBlood, "Definirs seu jogadores sangue level.");

            var healPlayerBtn = new MenuItem("Curar Jogador", "Give o jogador máxima health.");
            var cleanPlayerBtn = new MenuItem("Limpar Roupas do Jogador", "Clean seu jogador roupas.");
            var dryPlayerBtn = new MenuItem("Secarro Roupas do Jogador", "fazer seu jogador roupas dry.");
            var wetPlayerBtn = new MenuItem("Molhar Roupas do Jogador", "fazer seu jogador roupas wet.");
            var suicidePlayerBtn = new MenuItem("~r~Commisso Suicide", "Kill yourself por recebendo o pílula. ou por usando um pistola se você tem one.");

            var vehicleAutoPilot = new Menu("Auto Pilot", "Veículo auto pilot opções.");

            MenuController.AddSubmenu(menu, vehicleAutoPilot);

            var vehicleAutoPilotBtn = new MenuItem("Piloto Automático", "Gerenciar veículo auto pilot opções.")
            {
                Label = "→→→"
            };

            var drivingStyles = new List<string>() { "Normal", "Rushed", "Avoid highways", "Drive em reverse", "Custom" };
            var drivingStyle = new MenuListItem("Driving Estilo", drivingStyles, 0, "Definir o driving estilo that é usado para o Drive para Marcador e Drive ao redor Aleatórioly functions.");

            // Scenarios (list can be found in the PedScenarios class)
            var playerScenarios = new MenuListItem("Cenários do Jogador", PedScenarios.Scenarios, 0, "Selecione um cenário e hisso entrar para iniciar isso. Selecionar anoutro cenário irá substituir o atual cenário. se você're já executando o selecionado cenário, selecionaring isso novamente irá parar o cenário.");
            var stopScenario = new MenuItem("Force Stop Scenario", "Isto irá force um executando cenário para parar imediatamente, sem aguardeing para isso para finish isso's 'pararping' animação.");
            #endregion

            #region add items to menu based on permissions
            // Add all checkboxes to the menu. (keeping permissions in mind)
            if (IsAllowed(Permission.POGod))
            {
                menu.AddMenuItem(playerGodModeCheckbox);
            }
            if (IsAllowed(Permission.POInvisible))
            {
                menu.AddMenuItem(invisibleCheckbox);
            }
            if (IsAllowed(Permission.POUnlimitedStamina))
            {
                menu.AddMenuItem(unlimitedStaminaCheckbox);
            }
            if (IsAllowed(Permission.POFastRun))
            {
                menu.AddMenuItem(fastRunCheckbox);
            }
            if (IsAllowed(Permission.POFastSwim))
            {
                menu.AddMenuItem(fastSwimCheckbox);
            }
            if (IsAllowed(Permission.POSuperjump))
            {
                menu.AddMenuItem(superJumpCheckbox);
            }
            if (IsAllowed(Permission.PONoRagdoll))
            {
                menu.AddMenuItem(noRagdollCheckbox);
            }
            if (IsAllowed(Permission.PONeverWanted))
            {
                menu.AddMenuItem(neverWantedCheckbox);
            }
            if (IsAllowed(Permission.POSetWanted))
            {
                menu.AddMenuItem(setWantedLevel);
            }
            if (IsAllowed(Permission.POClearBlood))
            {
                menu.AddMenuItem(clearBloodBtn);
            }
            if (IsAllowed(Permission.POSetBlood))
            {
                menu.AddMenuItem(setBloodLevel);
            }
            if (IsAllowed(Permission.POIgnored))
            {
                menu.AddMenuItem(everyoneIgnoresPlayerCheckbox);
            }
            if (IsAllowed(Permission.POStayInVehicle))
            {
                menu.AddMenuItem(playerStayInVehicleCheckbox);
            }
            if (IsAllowed(Permission.POMaxHealth))
            {
                menu.AddMenuItem(healPlayerBtn);
            }
            if (IsAllowed(Permission.POMaxArmor))
            {
                menu.AddMenuItem(setArmorItem);
            }
            if (IsAllowed(Permission.POCleanPlayer))
            {
                menu.AddMenuItem(cleanPlayerBtn);
            }
            if (IsAllowed(Permission.PODryPlayer))
            {
                menu.AddMenuItem(dryPlayerBtn);
            }
            if (IsAllowed(Permission.POWetPlayer))
            {
                menu.AddMenuItem(wetPlayerBtn);
            }

            menu.AddMenuItem(suicidePlayerBtn);

            if (IsAllowed(Permission.POVehicleAutoPilotMenu))
            {
                menu.AddMenuItem(vehicleAutoPilotBtn);
                MenuController.BindMenuItem(menu, vehicleAutoPilot, vehicleAutoPilotBtn);

                vehicleAutoPilot.AddMenuItem(drivingStyle);

                var startDrivingWaypoint = new MenuItem("Drive para Waypoint", "fazer seu jogador ped drive seu veículo para seu marcador.");
                var startDrivingRandomly = new MenuItem("Drive ao redor Randomly", "fazer seu jogador ped drive seu veículo aleatoriamente ao redor o mapa.");
                var stopDriving = new MenuItem("Stop Driving", "O jogador ped irá find um adequado local para parar o veículo. O tarefa irá ser pararped once o veículo tem reached o adequado parar localização.");
                var forceStopDriving = new MenuItem("Force Stop Driving", "Isto irá parar o driving tarefa imediatamente sem finding um adequado local para parar.");
                var customDrivingStyle = new MenuItem("Custom Driving Estilo", "Selecione um pessoalizado driving estilo. fazer certeza para also ativar isso selecionando o 'Custom' driving estilo em o driving estilos lista.") { Label = "→→→" };
                MenuController.AddSubmenu(vehicleAutoPilot, CustomDrivingStyleMenu);
                vehicleAutoPilot.AddMenuItem(customDrivingStyle);
                MenuController.BindMenuItem(vehicleAutoPilot, CustomDrivingStyleMenu, customDrivingStyle);
                var knownNames = new Dictionary<int, string>()
                {
                    { 0, "Stop para vehicles" },  // Using this flag will allow the driver to stop for other vehicles when appropriate, instead of hitting them.
                    { 1, "Stop para pedestrians" },  // Using this flag will allow the driver to stop for pedestrians when appropriate, instead of hitting them.
                    { 2, "Swerve ao redor Todos os pneus do veículos" },  // Using this flag will allow the driver to stop for other vehicles when appropriate, instead of hitting them.
                    { 3, "Steer ao redor stationary vehicles" },  // Using this flag will allow the driver to steer around a vehicle in order to avoid them when driving.
                    { 4, "Steer ao redor pedestrians" },  // Using this flag will allow the driver to steer around a pedestrian in order to avoid them when driving.
                    { 5, "Steer ao redor objects" },  // Using this flag will allow the driver to steer around objects in order to avoid them when driving.
                    { 6, "Don't steer ao redor Jogador" },  // Using this flag will prevent the driver trying steer around an pedestrian if that pedestrian is the player
                    { 7, "Stop at luzes" },  // Using this flag will cause the driver to stop at traffic lights when appropriate.
                    { 8, "ir desligado road quando avoiding" },  // Using this flag will allow the driver to deliberately go off-road when trying to avoid something.
                    { 9, "Drive em oncoming traffic" },  // Using this flag will allow the driver to deliberately drive into oncoming traffic, when certain conditions are met. Such as avoiding or swerving, or overtaking.
                    { 10, "Drive em reverse" },  // Using this flag will tell the driver that they should drive in reverse.
                    { 11, "Use wander cairtraseira instead de straight line" },  // Using this flag will make the driver use wander pathfinding instead of straight line pathfinding when no route is found.
                    { 12, "Avoid restrissoo areas" },  // Using this flag will tell the driver that they should avoid areas considered restricted. This includes areas like the Army Base, Prison, Airport, or any other areas that might give the Player a Wanted Level for driving through.
                    { 13, "Prevent traseirachão pathfinding" },  // The driver will not perform background pathfinding.
                    { 14, "Adjust velocidade para atual estrada" },  // Using this flag will tell the driver that they should match their speed to the road that they are driving on. Highways use a faster speed than main roads.
                    { 15, "Prevent join em road direction quando moving" },  // The driver avoids joining roads in the direction of traffic when moving.
                    { 16, "Don't avoid target" },  // The driver does not avoid the target destination.
                    { 17, "Target posissoion substituirs entissoy" },  // The target position takes precedence over the target entity.
                    { 18, "Use shortcut links (Use shortest path)" },  // Using this flag will tell the driver that they should try to use Road Nodes flagged as shortcuts. This may divert them down side streets, or through oncoming traffic, if this behavior is not restricted.
                    { 19, "Alterar lanes ao redor obstructions" },  // Using this flag allows the Driver to change lanes to avoid an obstruction.
                    { 20, "Avoid target coords" },  // The driver pathfind away from instead of towards the target coordinates.
                    { 21, "Use swissoched-desligado nodes" },  // Using this flag allows the Driver to use Road Nodes that have been disabled by Zones.
                    { 22, "Prefer navmesh route" },  // Using this flag allows the Driver to use the Navmesh to find a path to their destination instead of the Road Nodes system. This is useful for off-road driving.
                    { 23, "Plane taxi mode" },  // The driver operates as if taxiing an aircraft.
                    { 24, "Force straight line" },  // Using this flag forces the Driver to drive in a straight line to their next destination, ignoring the Navmesh or the Road Nodes system.
                    { 25, "Use string pulling at junctions" },  // The driver uses string pulling for smoother turns at junctions.
                    { 26, "Avoid Adverse Condissoions" },  // The driver avoids "adverse condissoions" (shocking events, etc.) when cruising.
                    { 27, "Avoid turns" },  // The driver avoids turns when cruising.
                    { 28, "Extend route wissoh wander results" },  // The driver extends the route using wandering paths.
                    { 29, "Avoid highways (se possible)" },  // Using this flag prevents the Driver from using a highway when possible.
                    { 30, "Force join em road direction" },  // The driver joins roads in direction of the flow of traffic only.
                    { 31, "Don't terminate tarefa quando achieved" },  // The driver will not terminate the driving task upon reaching the destination.
                };
                for (var i = 0; i < 32; i++)
                {
                    var name = "~r~Unknown Flag";
                    if (knownNames.ContainsKey(i))
                    {
                        name = knownNames[i];
                    }
                    var checkbox = new MenuCheckboxItem(name, "Alternar isto driving estilo flag.", false);
                    CustomDrivingStyleMenu.AddMenuItem(checkbox);
                }
                CustomDrivingStyleMenu.OnCheckboxChange += (sender, item, index, _checked) =>
                {
                    var style = GetStyleFromIndex(drivingStyle.ListIndex);
                    CustomDrivingStyleMenu.MenuSubtitle = $"pessoalizado estilo: {estilo}";
                    if (drivingStyle.ListIndex == 4)
                    {
                        Notify.Custom("Driving estilo atualizado.");
                        SetDriveTaskDrivingStyle(Game.PlayerPed.Handle, style);
                    }
                    else
                    {
                        Notify.Custom("Driving estilo NÃO atualizado porque você temn't ativado o Custom driving estilo em o anterior menu.");
                    }
                };

                vehicleAutoPilot.AddMenuItem(startDrivingWaypoint);
                vehicleAutoPilot.AddMenuItem(startDrivingRandomly);
                vehicleAutoPilot.AddMenuItem(stopDriving);
                vehicleAutoPilot.AddMenuItem(forceStopDriving);

                vehicleAutoPilot.RefreshIndex();

                vehicleAutoPilot.OnItemSelect += async (sender, item, index) =>
                {
                    if (Game.PlayerPed.IsInVehicle() && item != stopDriving && item != forceStopDriving)
                    {
                        if (Game.PlayerPed.CurrentVehicle != null && Game.PlayerPed.CurrentVehicle.Exists() && !Game.PlayerPed.CurrentVehicle.IsDead && Game.PlayerPed.CurrentVehicle.IsDriveable)
                        {
                            if (Game.PlayerPed.CurrentVehicle.Driver == Game.PlayerPed)
                            {
                                if (item == startDrivingWaypoint)
                                {
                                    if (IsWaypointActive())
                                    {
                                        var style = GetStyleFromIndex(drivingStyle.ListIndex);
                                        DriveToWp(style);
                                        Notify.Info("Seu jogador ped é agora driving o veículo para você. Você pode cancelar qualquer horário pressioneionando o Stop Driving botão. O veículo irá parar quando isso tem reached o destino.");
                                    }
                                    else
                                    {
                                        Notify.Error("você precisa um marcador antes você pode drive para isso!");
                                    }

                                }
                                else if (item == startDrivingRandomly)
                                {
                                    var style = GetStyleFromIndex(drivingStyle.ListIndex);
                                    DriveWander(style);
                                    Notify.Info("Seu jogador ped é agora driving o veículo para você. Você pode cancelar qualquer horário pressioneionando o Stop Driving botão.");
                                }
                            }
                            else
                            {
                                Notify.Error("Você deve ser o motorista de este veículo!");
                            }
                        }
                        else
                        {
                            Notify.Error("Seu veículo é broken ou isso faz não exist!");
                        }
                    }
                    else if (item != stopDriving && item != forceStopDriving)
                    {
                        Notify.Error("Você precisa ser em um veículo primeiro!");
                    }
                    if (item == stopDriving)
                    {
                        if (Game.PlayerPed.IsInVehicle())
                        {
                            var veh = GetVehicle();
                            if (veh != null && veh.Exists() && !veh.IsDead)
                            {
                                var outPos = new Vector3();
                                if (GetNthClosestVehicleNode(Game.PlayerPed.Position.X, Game.PlayerPed.Position.Y, Game.PlayerPed.Position.Z, 3, ref outPos, 0, 0, 0))
                                {
                                    Notify.Info("O jogador ped irá find um adequado local para estacionar o carro e irá então parar driving. Por favor aguarde.");
                                    ClearPedTasks(Game.PlayerPed.Handle);
                                    TaskVehiclePark(Game.PlayerPed.Handle, veh.Handle, outPos.X, outPos.Y, outPos.Z, Game.PlayerPed.Heading, 3, 60f, true);
                                    while (Game.PlayerPed.Position.DistanceToSquared2D(outPos) > 3f)
                                    {
                                        await BaseScript.Delay(0);
                                    }
                                    SetVehicleHalt(veh.Handle, 3f, 0, false);
                                    ClearPedTasks(Game.PlayerPed.Handle);
                                    Notify.Info("O jogador ped tem pararped driving.");
                                }
                            }
                        }
                        else
                        {
                            ClearPedTasks(Game.PlayerPed.Handle);
                            Notify.Alert("Seu ped é não em umny veículo.");
                        }
                    }
                    else if (item == forceStopDriving)
                    {
                        ClearPedTasks(Game.PlayerPed.Handle);
                        Notify.Info("Driving tarefa cancelled.");
                    }
                };

                vehicleAutoPilot.OnListItemSelect += (sender, item, listIndex, itemIndex) =>
                {
                    if (item == drivingStyle)
                    {
                        var style = GetStyleFromIndex(listIndex);
                        SetDriveTaskDrivingStyle(Game.PlayerPed.Handle, style);
                        Notify.Info($"Driving tarefa estilo é agora definir para: ~r~{drivingEstilos[listaIndex]}~s~.");
                    }
                };
            }

            if (IsAllowed(Permission.POFreeze))
            {
                menu.AddMenuItem(playerFrozenCheckbox);
            }
            if (IsAllowed(Permission.POScenarios))
            {
                menu.AddMenuItem(playerScenarios);
                menu.AddMenuItem(stopScenario);
            }
            #endregion

            #region handle all events
            // Checkbox changes.
            menu.OnCheckboxChange += (sender, item, itemIndex, _checked) =>
            {
                // God Mode toggled.
                if (item == playerGodModeCheckbox)
                {
                    PlayerGodMode = _checked;
                }
                // Invisibility toggled.
                else if (item == invisibleCheckbox)
                {
                    PlayerInvisible = _checked;
                    SetEntityVisible(Game.PlayerPed.Handle, !PlayerInvisible, false);
                }
                // Unlimited Stamina toggled.
                else if (item == unlimitedStaminaCheckbox)
                {
                    PlayerStamina = _checked;
                    StatSetInt(Game.GenerateHashASCII("MP0_STAMINA"), _checked ? 100 : 0, true);
                }
                // Fast run toggled.
                else if (item == fastRunCheckbox)
                {
                    PlayerFastRun = _checked;
                    SetRunSprintMultiplierForPlayer(Game.Player.Handle, _checked ? 1.49f : 1f);
                }
                // Fast swim toggled.
                else if (item == fastSwimCheckbox)
                {
                    PlayerFastSwim = _checked;
                    SetSwimMultiplierForPlayer(Game.Player.Handle, _checked ? 1.49f : 1f);
                }
                // Super jump toggled.
                else if (item == superJumpCheckbox)
                {
                    PlayerSuperJump = _checked;
                }
                // No ragdoll toggled.
                else if (item == noRagdollCheckbox)
                {
                    PlayerNoRagdoll = _checked;
                }
                // Never wanted toggled.
                else if (item == neverWantedCheckbox)
                {
                    PlayerNeverWanted = _checked;
                    if (!_checked)
                    {
                        SetMaxWantedLevel(5);
                    }
                    else
                    {
                        SetMaxWantedLevel(0);
                    }
                }
                // Everyone ignores player toggled.
                else if (item == everyoneIgnoresPlayerCheckbox)
                {
                    PlayerIsIgnored = _checked;

                    // Manage player is ignored by everyone.
                    SetEveryoneIgnorePlayer(Game.Player.Handle, PlayerIsIgnored);
                    SetPoliceIgnorePlayer(Game.Player.Handle, PlayerIsIgnored);
                    SetPlayerCanBeHassledByGangs(Game.Player.Handle, !PlayerIsIgnored);
                }
                else if (item == playerStayInVehicleCheckbox)
                {
                    PlayerStayInVehicle = _checked;
                }
                // Freeze player toggled.
                else if (item == playerFrozenCheckbox)
                {
                    PlayerFrozen = _checked;

                    if (!MainMenu.NoClipEnabled)
                    {
                        FreezeEntityPosition(Game.PlayerPed.Handle, PlayerFrozen);
                    }
                    else if (!MainMenu.NoClipEnabled)
                    {
                        FreezeEntityPosition(Game.PlayerPed.Handle, PlayerFrozen);
                    }
                }
            };

            // List selections
            menu.OnListItemSelect += (sender, listItem, listIndex, itemIndex) =>
            {
                // Set wanted Level
                if (listItem == setWantedLevel)
                {
                    SetPlayerWantedLevel(Game.Player.Handle, listIndex, false);
                    SetPlayerWantedLevelNow(Game.Player.Handle, false);
                }
                // Set blood level
                else if (listItem == setBloodLevel)
                {
                    ApplyPedDamagePack(Game.PlayerPed.Handle, bloodList[listIndex], 100, 100);
                }
                // Player Scenarios 
                else if (listItem == playerScenarios)
                {
                    PlayScenario(PedScenarios.ScenarioNames[PedScenarios.Scenarios[listIndex]]);
                }
                else if (listItem == setArmorItem)
                {
                    Game.PlayerPed.Armor = listItem.ListIndex * 20;
                }
            };

            // button presses
            menu.OnItemSelect += (sender, item, index) =>
            {
                // Force Stop Scenario button
                if (item == stopScenario)
                {
                    // Play a new scenario named "forcestop" (this scenario doesn't exist, but the "Play" function checks
                    // for the string "forcestop", if that's provided as th scenario name then it will forcefully clear the player task.
                    PlayScenario("forcestop");
                }
                else if (item == clearBloodBtn)
                {
                    Game.PlayerPed.ClearBloodDamage();
                    Game.PlayerPed.ResetVisibleDamage();
                    // not ideal for removing visible bruises & scars, may have some sync issues but could not find an alternative method, anyone who does feel free to update

                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 0, "ALL");
                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 1, "ALL");
                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 2, "ALL");
                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 3, "ALL");
                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 4, "ALL");
                    ClearPedDamageDecalByZone(Game.PlayerPed.Handle, 5, "ALL");
                }
                else if (item == healPlayerBtn)
                {
                    Game.PlayerPed.Health = Game.PlayerPed.MaxHealth;
                    Notify.Success("Jogador healed.");
                }
                else if (item == cleanPlayerBtn)
                {
                    Game.PlayerPed.ClearBloodDamage();
                    Notify.Success("Jogador roupas foram limpas.");
                }
                else if (item == dryPlayerBtn)
                {
                    Game.PlayerPed.WetnessHeight = 0f;
                    Notify.Success("Jogador é agora dry.");
                }
                else if (item == wetPlayerBtn)
                {
                    Game.PlayerPed.WetnessHeight = 2f;
                    Notify.Success("Jogador é agora wet.");
                }
                else if (item == suicidePlayerBtn)
                {
                    CommitSuicide();
                }
            };
            #endregion

        }

        private int GetCustomDrivingStyle()
        {
            var items = CustomDrivingStyleMenu.GetMenuItems();
            var flags = new int[items.Count];
            for (var i = 0; i < items.Count; i++)
            {
                var item = items[i];
                if (item is MenuCheckboxItem checkbox)
                {
                    flags[i] = checkbox.Checked ? 1 : 0;
                }
            }
            var binaryString = "";
            var reverseFlags = flags.Reverse();
            foreach (var i in reverseFlags)
            {
                binaryString += i;
            }
            var binaryNumber = Convert.ToUInt32(binaryString, 2);
            return (int)binaryNumber;
        }

        private int GetStyleFromIndex(int index)
        {
            var style = index switch
            {
                0 => 443,// normal
                1 => 575,// rushed
                2 => 536871355,// Avoid highways
                3 => 1467,// Go in reverse
                4 => GetCustomDrivingStyle(),// custom driving style;
                _ => 0,// no style (impossible, but oh well)
            };
            return style;
        }

        /// <summary>
        /// Checks if the menu exists, if not then it creates it first.
        /// Then returns the menu.
        /// </summary>
        /// <returns>The Player Options Menu</returns>
        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }

    }
}
