-- Manifest data
fx_version 'cerulean'
games {'gta5'}

-- Resource stuff
name 'vMenu'
description 'vMenu 3.8.56 em Português do Brasil, com sistema de permissões e MenuAPI.'
version '3.8.56-ptbr'
author 'Tom Grobbe'
url 'https://github.com/TomGrobbe/vMenu/'

-- Adds additional logging, useful when debugging issues.
client_debug_mode 'false'
server_debug_mode 'false'

-- Adds extra commands for testing and development
experimental_features_enabled '0'

-- Files & scripts
files {
    'Newtonsoft.Json.dll',
    'MenuAPI.dll',
    'config/*.json'
}

client_script 'vMenuClient.net.dll'
server_script 'vMenuServer.net.dll'