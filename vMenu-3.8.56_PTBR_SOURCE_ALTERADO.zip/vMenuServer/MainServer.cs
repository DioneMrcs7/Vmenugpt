﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using CitizenFX.Core;

using Newtonsoft.Json;

using vMenuShared;

using static CitizenFX.Core.Native.API;
using static vMenuServer.DebugLog;
using static vMenuShared.ConfigManager;

namespace vMenuServer
{

    public static class DebugLog
    {
        public enum LogLevel
        {
            error = 1,
            success = 2,
            info = 4,
            warning = 3,
            none = 0
        }

        /// <summary>
        /// Global log data function, only logs when debugging is enabled.
        /// </summary>
        /// <param name="data"></param>
        public static void Log(dynamic data, LogLevel level = LogLevel.none)
        {
            if (MainServer.DebugMode || level == LogLevel.error || level == LogLevel.warning)
            {
                var prefix = "[vMenu] ";
                if (level == LogLevel.error)
                {
                    prefix = "^1[vMenu] [ERROR]^7 ";
                }
                else if (level == LogLevel.info)
                {
                    prefix = "^5[vMenu] [INFO]^7 ";
                }
                else if (level == LogLevel.success)
                {
                    prefix = "^2[vMenu] [SUCCESS]^7 ";
                }
                else if (level == LogLevel.warning)
                {
                    prefix = "^3[vMenu] [WARNING]^7 ";
                }
                Debug.WriteLine($"{prefix}[DEBUG LOG] {data.ToString()}");
            }
        }
    }

    public class MainServer : BaseScript
    {
        #region vars
        // Debug shows more information when doing certain things. Leave it off to improve performance!
        public static bool DebugMode = GetResourceMetadata(GetCurrentResourceName(), "server_debug_mode", 0) == "true";

        public static string Version { get { return GetResourceMetadata(GetCurrentResourceName(), "version", 0); } }

        // Time
        private int CurrentHours
        {
            get { return MathUtil.Clamp(GetSettingsInt(Setting.vmenu_current_hour), 0, 23); }
            set { SetConvarReplicated(Setting.vmenu_current_hour.ToString(), MathUtil.Clamp(value, 0, 23).ToString()); }
        }
        private int CurrentMinutes
        {
            get { return MathUtil.Clamp(GetSettingsInt(Setting.vmenu_current_minute), 0, 59); }
            set { SetConvarReplicated(Setting.vmenu_current_minute.ToString(), MathUtil.Clamp(value, 0, 59).ToString()); }
        }
        private int MinuteClockSpeed
        {
            get
            {
                var value = GetSettingsInt(Setting.vmenu_ingame_minute_duration);
                if (value < 100)
                {
                    value = 2000;
                }

                return value;
            }
        }
        private bool FreezeTime
        {
            get { return GetSettingsBool(Setting.vmenu_freeze_time); }
            set { SetConvarReplicated(Setting.vmenu_freeze_time.ToString(), value.ToString().ToLower()); }
        }
        private bool IsServerTimeSynced { get { return GetSettingsBool(Setting.vmenu_sync_to_machine_time); } }


        // Weather
        private string CurrentWeather
        {
            get
            {
                var value = GetSettingsString(Setting.vmenu_current_weather, "CLEAR");
                if (!WeatherTypes.Contains(value.ToUpper()))
                {
                    return "CLEAR";
                }
                return value;
            }
            set
            {
                if (string.IsNullOrEmpty(value) || !WeatherTypes.Contains(value.ToUpper()))
                {
                    SetConvarReplicated(Setting.vmenu_current_weather.ToString(), "CLEAR");
                }
                SetConvarReplicated(Setting.vmenu_current_weather.ToString(), value.ToUpper());
            }
        }
        private bool DynamicWeatherEnabled
        {
            get { return GetSettingsBool(Setting.vmenu_enable_dynamic_weather); }
            set { SetConvarReplicated(Setting.vmenu_enable_dynamic_weather.ToString(), value.ToString().ToLower()); }
        }
        private bool ManualSnowEnabled
        {
            get { return GetSettingsBool(Setting.vmenu_enable_snow); }
            set { SetConvarReplicated(Setting.vmenu_enable_snow.ToString(), value.ToString().ToLower()); }
        }
        private bool BlackoutEnabled
        {
            get { return GetSettingsBool(Setting.vmenu_blackout_enabled); }
            set { SetConvarReplicated(Setting.vmenu_blackout_enabled.ToString(), value.ToString().ToLower()); }
        }
        private bool VehicleBlackoutEnabled
        {
            get { return GetSettingsBool(Setting.vmenu_vehicle_blackout_enabled); }
            set { SetConvarReplicated(Setting.vmenu_vehicle_blackout_enabled.ToString(), value.ToString().ToLower()); }
        }
        private int DynamicWeatherMinutes
        {
            get { return Math.Max(GetSettingsInt(Setting.vmenu_dynamic_weather_timer), 1); }
        }
        private long lastWeatherChange = 0;

        private readonly List<string> CloudTypes = new()
        {
            "Cloudy 01",
            "RAIN",
            "horizonband1",
            "horizonband2",
            "Puffs",
            "Wispy",
            "Horizon",
            "Stormy 01",
            "Clear 01",
            "Snowy 01",
            "Contrails",
            "altostratus",
            "Nimbus",
            "Cirrus",
            "cirrocumulus",
            "stratoscumulus",
            "horizonband3",
            "Stripey",
            "horsey",
            "shower",
        };
        private readonly List<string> WeatherTypes = new()
        {
            "EXTRASUNNY",
            "CLEAR",
            "NEUTRAL",
            "SMOG",
            "FOGGY",
            "CLOUDS",
            "OVERCAST",
            "CLEARING",
            "RAIN",
            "THUNDER",
            "BLIZZARD",
            "SNOW",
            "SNOWLIGHT",
            "XMAS",
            "HALLOWEEN"
        };
        
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor.
        /// </summary>
        public MainServer()
        {
            // name check
            if (GetCurrentResourceName() != "vMenu")
            {
                var InvalidNameException = new Exception("\r\n\r\n^1[vMenu] INSTALLATION ERROR!\r\nThe nome de o resource é não valid. " +
                    "Por favor alterar o fantigoer nome de '^3" + GetCurrentResourceName() + "^1' to '^2vMenu^1' (case sensitive) instead!\r\n\r\n\r\n^7");
                try
                {
                    throw InvalidNameException;
                }
                catch (Exception e)
                {
                    Debug.Write(e.Message);
                }
            }
            else
            {
                // Add event handlers.
                EventHandlers.Add("vMenu:GetPlayerIdentifiers", new Action<int, NetworkCallbackDelegate>((TargetPlayer, CallbackFunction) =>
                {
                    var data = new List<string>();
                    Players[TargetPlayer].Identifiers.ToList().ForEach(e =>
                    {
                        if (!e.Contains("ip:"))
                        {
                            data.Add(e);
                        }
                    });
                    CallbackFunction(JsonConvert.SerializeObject(data));
                }));

                // check addons file for errors
                Dictionary<string, List<string>> addonsData = new();
                var addons = LoadResourceFile(GetCurrentResourceName(), "config/addons.json") ?? "{}";
                try
                {
                    addonsData = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(addons);
                    // If the above crashes, then the json is invalid and it'll throw warnings in the console.
                }
                catch (JsonReaderException ex)
                {
                    Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Seu addons.json arquivo contains um problem! Erro detalhes: {ex.Mensagem}\n\n");
                }

                // check model-whitelists file for errors
                Dictionary<string, List<string>> whitelistData = new();
                var whitelist = LoadResourceFile(GetCurrentResourceName(), "config/model-whitelists.json") ?? "{}";
                try
                {
                    whitelistData = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(whitelist);
                    // If the above crashes, then the json is invalid and it'll throw warnings in the console.
                }
                catch (JsonReaderException ex)
                {
                    Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Seu model-whitelists.json arquivo contains um problem! Erro detalhes: {ex.Mensagem}\n\n");
                }

                // setup addon permissions
                SetupAddonPerms(whitelistData, addonsData);

                // check extras file for errors
                string extras = LoadResourceFile(GetCurrentResourceName(), "config/extras.json") ?? "{}";
                try
                {
                    JsonConvert.DeserializeObject<Dictionary<string, Dictionary<int, string>>>(extras);
                    // If the above crashes, then the json is invalid and it'll throw warnings in the console.
                }
                catch (JsonReaderException ex)
                {
                    Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Seu extras.json arquivo contains um problem! Erro detalhes: {ex.Mensagem}\n\n");
                }

                // check if permissions are setup (correctly)
                if (!GetSettingsBool(Setting.vmenu_use_permissions))
                {
                    Debug.WriteLine("^3[vMenu] [WARNING] vMenu é definir up para ignore permissions!\nIf you did this em purpose then você pode ignore this aviso.\nIf you did não definir this em purpose, then você deve have made um mistake enquanto definirting up vMenu.\nPor favor read o vMenu documentation (^5https://docs.vespura.com/vmenu^3).\nMost likely você está não executing o permissions.cfg (correctly).^7");
                }

                Tick += PlayersFirstTick;

                // Start the loops
                if (GetSettingsBool(Setting.vmenu_enable_weather_sync))
                {
                    Tick += WeatherLoop;
                }

                if (GetSettingsBool(Setting.vmenu_enable_time_sync))
                {
                    Tick += TimeLoop;
                }

                GlobalState.Set("vmenu_onesync", GetConvar("onesync", "off") == "on", true);
            }
        }
        #endregion

        #region command handler
        [Command("vmenuserver", Restricted = true)]
        internal void ServerCommandHandler(int source, List<object> args, string _)
        {
            if (args != null)
            {
                if (args.Count > 0)
                {
                    if (args[0].ToString().ToLower() == "debug")
                    {
                        DebugMode = !DebugMode;
                        if (source < 1)
                        {
                            Debug.WriteLine($"Debug mode é agora definir para: {DebugMode}.");
                        }
                        else
                        {
                            Players[source].TriggerEvent("chatMessage", $"vMenu Debug mode é agora definir para: {DebugMode}.");
                        }
                        return;
                    }
                    else if (args[0].ToString().ToLower() == "unban" && (source < 1))
                    {
                        if (args.Count() > 1 && !string.IsNullOrEmpty(args[1].ToString()))
                        {
                            var uuid = args[1].ToString().Trim();
                            var bans = BanManager.GetBanList();
                            var banRecord = bans.Find(b => { return b.uuid.ToString() == uuid; });
                            if (banRecord != null)
                            {
                                BanManager.RemoveBan(banRecord);
                                Debug.WriteLine("Jogador has been com sucesso unbanned.");
                            }
                            else
                            {
                                Debug.WriteLine($"Could não find um banned jogador com o provided uuid '{uuid}'.");
                            }
                        }
                        else
                        {
                            Debug.WriteLine("You did não specify um jogador para unban, você deve enter o FULL jogadornome. Usage: vmenuservidor unban \"jogadornome\"");
                        }
                        return;
                    }
                    else if (args[0].ToString().ToLower() == "weather")
                    {
                        if (args.Count < 2 || string.IsNullOrEmpty(args[1].ToString()))
                        {
                            Debug.WriteLine("[vMenu] Inválido command syntax. Use 'vmenuservidor clima <climaType>' instead.");
                        }
                        else
                        {
                            var wtype = args[1].ToString().ToUpper();
                            if (WeatherTypes.Contains(wtype))
                            {
                                TriggerEvent("vMenu:UpdateServerWeather", wtype, DynamicWeatherEnabled, ManualSnowEnabled);
                                Debug.WriteLine($"[vMenu] Clima é agora definir para: {wtype}");
                            }
                            else if (wtype.ToLower() == "dynamic")
                            {
                                if (args.Count == 3 && !string.IsNullOrEmpty(args[2].ToString()))
                                {
                                    if ((args[2].ToString().ToLower() ?? $"{DynamicWeatherEnabled}") == "true")
                                    {
                                        TriggerEvent("vMenu:UpdateServerWeather", CurrentWeather, true, ManualSnowEnabled);
                                        Debug.WriteLine("[vMenu] Dynamic clima é agora girared em.");
                                    }
                                    else if ((args[2].ToString().ToLower() ?? $"{DynamicWeatherEnabled}") == "false")
                                    {
                                        TriggerEvent("vMenu:UpdateServerWeather", CurrentWeather, false, ManualSnowEnabled);
                                        Debug.WriteLine("[vMenu] Dynamic clima é agora girared off.");
                                    }
                                    else
                                    {
                                        Debug.WriteLine("[vMenu] Inválido command usage. Correct syntax: vmenuservidor clima dynamic <true|false>");
                                    }
                                }
                                else
                                {
                                    Debug.WriteLine("[vMenu] Inválido command usage. Correct syntax: vmenuservidor clima dynamic <true|false>");
                                }

                            }
                            else
                            {
                                Debug.WriteLine("[vMenu] This clima type é não valid!");
                            }
                        }
                    }
                    else if (args[0].ToString().ToLower() == "time")
                    {
                        if (args.Count == 2)
                        {
                            if (args[1].ToString().ToLower() == "freeze")
                            {
                                TriggerEvent("vMenu:UpdateServerTime", CurrentHours, CurrentMinutes, !FreezeTime);
                                Debug.WriteLine($"Horário é agora {(FreezeHorário ? "frozen" : "not frozen")}.");
                            }
                            else
                            {
                                Debug.WriteLine("Inválido syntax. Use: ^5vmenuservidor horário <freeze|<hour> <minute>>^7 instead.");
                            }
                        }
                        else if (args.Count > 2)
                        {
                            if (int.TryParse(args[1].ToString(), out var hour))
                            {
                                if (int.TryParse(args[2].ToString(), out var minute))
                                {
                                    if (hour is >= 0 and < 24)
                                    {
                                        if (minute is >= 0 and < 60)
                                        {
                                            TriggerEvent("vMenu:UpdateServerTime", hour, minute, FreezeTime);
                                            Debug.WriteLine($"Horário é agora {(hour < 10 ? ("0" + hour.ToString()) : hour.ToString())}:{(minute < 10 ? ("0" + minute.ToString()) : minute.ToString())}.");
                                        }
                                        else
                                        {
                                            Debug.WriteLine("Inválido minute provided. Value must ser between 0 e 59.");
                                        }
                                    }
                                    else
                                    {
                                        Debug.WriteLine("Inválido hour provided. Value must ser between 0 e 23.");
                                    }
                                }
                                else
                                {
                                    Debug.WriteLine("Inválido syntax. Use: ^5vmenuservidor horário <freeze|<hour> <minute>>^7 instead.");
                                }
                            }
                            else
                            {
                                Debug.WriteLine("Inválido syntax. Use: ^5vmenuservidor horário <freeze|<hour> <minute>>^7 instead.");
                            }
                        }
                        else
                        {
                            Debug.WriteLine("Inválido syntax. Use: ^5vmenuservidor horário <freeze|<hour> <minute>>^7 instead.");
                        }
                    }
                    else if (args[0].ToString().ToLower() == "ban" && source < 1)  // only do this via server console (server id < 1)
                    {
                        if (args.Count > 3)
                        {
                            Player p = null;

                            var findByServerId = args[1].ToString().ToLower() == "id";
                            var identifier = args[2].ToString().ToLower();

                            if (findByServerId)
                            {
                                if (Players.Any(player => player.Handle == identifier))
                                {
                                    p = Players.Single(pl => pl.Handle == identifier);
                                }
                                else
                                {
                                    Debug.WriteLine("[vMenu] Could não find este jogador, make sure they estão online.");
                                    return;
                                }
                            }
                            else
                            {
                                if (Players.Any(player => player.Name.ToLower() == identifier.ToLower()))
                                {
                                    p = Players.Single(pl => pl.Name.ToLower() == identifier.ToLower());
                                }
                                else
                                {
                                    Debug.WriteLine("[vMenu] Could não find este jogador, make sure they estão online.");
                                    return;
                                }
                            }

                            var reason = "Banned by staff para:";
                            args.GetRange(3, args.Count - 3).ForEach(arg => reason += " " + arg);

                            if (p != null)
                            {
                                var ban = new BanManager.BanRecord(
                                    BanManager.GetSafePlayerName(p.Name),
                                    p.Identifiers.ToList(),
                                    new DateTime(3000, 1, 1),
                                    reason,
                                    "Servidor Console",
                                    new Guid()
                                );

                                BanManager.AddBan(ban);
                                BanManager.BanLog($"[vMenu] Jogador {p.Nome}^7 has been banned by Servidor Console para [{motivo}].");
                                TriggerEvent("vMenu:BanSuccessful", JsonConvert.SerializeObject(ban).ToString());
                                var timeRemaining = BanManager.GetRemainingTimeMessage(ban.bannedUntil.Subtract(DateTime.Now));
                                p.Drop($"Você está banned de this servidor. Ban horário remaining: {horárioRemaining}. Banned by: {ban.bannedBy}. Ban motivo: {ban.banMotivo}. Additional information: {vMenuShared.ConfigGerenciarr.GetConfiguraçõesString(vMenuShared.ConfigGerenciarr.Definirting.vmenu_padrão_ban_mensagem_information)}.");
                            }
                            else
                            {
                                Debug.WriteLine("[vMenu] Jogador não found, não foi possível ban jogador.");
                            }
                        }
                        else
                        {
                            Debug.WriteLine("[vMenu] Nãot enough arguments, syntax: ^5vmenuservidor ban <id|nome> <servidor id|usernome> <motivo>^7.");
                        }
                    }
                    else if (args[0].ToString().ToLower() == "help")
                    {
                        Debug.WriteLine("Disponível commands:");
                        Debug.WriteLine("(servidor console somente): vmenuservidor ban <id|nome> <servidor id|usernome> <motivo> (jogador must ser online!)");
                        Debug.WriteLine("(servidor console somente): vmenuservidor unban <uuid>");
                        Debug.WriteLine("vmenuservidor clima <novo clima type | dynamic <true | false>>");
                        Debug.WriteLine("vmenuservidor horário <freeze|<hour> <minute>>");
                        Debug.WriteLine("vmenuservidor migrate (This copies todos banned jogadors in o bans.json arquivo para o novo ban system in vMenu v3.3.0, you somente need para do this once)");
                    }
                    else if (args[0].ToString().ToLower() == "migrate" && source < 1)
                    {
                        var file = LoadResourceFile(GetCurrentResourceName(), "bans.json");
                        if (string.IsNullOrEmpty(file) || file == "[]")
                        {
                            Debug.WriteLine("&1[vMenu] [ERROR]^7 Não bans.json arquivo found ou it's empty.");
                            return;
                        }
                        Debug.WriteLine("^5[vMenu] [INFO]^7 Importing todos ban records de o bans.json arquivo em o novo storage system. ^3This may take some horário...^7");
                        var bans = JsonConvert.DeserializeObject<List<BanManager.BanRecord>>(file);
                        bans.ForEach((br) =>
                        {
                            var record = new BanManager.BanRecord(br.playerName, br.identifiers, br.bannedUntil, br.banReason, br.bannedBy, Guid.NewGuid());
                            BanManager.AddBan(record);
                        });
                        Debug.WriteLine("^2[vMenu] [SUCCESS]^7 Todos ban records have been imported. You agora no longer need o bans.json arquivo.");
                    }
                    else
                    {
                        Debug.WriteLine($"vMenu é atualmente running version: {Version}. Try ^5vmenuservidor help^7 para info.");
                    }
                }
                else
                {
                    Debug.WriteLine($"vMenu é atualmente running version: {Version}. Try ^5vmenuservidor help^7 para info.");
                }
            }
            else
            {
                Debug.WriteLine($"vMenu é atualmente running version: {Version}. Try ^5vmenuservidor help^7 para info.");
            }
        }
        #endregion

        #region kick players from personal vehicle
        /// <summary>
        /// Makes the player leave the personal vehicle.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="vehicleNetId"></param>
        [EventHandler("vMenu:GetOutOfCar")]
        internal void GetOutOfCar([FromSource] Player source, int vehicleNetId)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.PVKickPassengers, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            Entity vehicle = Entity.FromNetworkId(vehicleNetId);

            if (vehicle is null)
            {
                return;
            }

            int vehicleHandle = vehicle.Handle;

            for (int i = -1; i < 15; i++)
            {
                int pedHandle = GetPedInVehicleSeat(vehicleHandle, i);

                if (pedHandle == 0 || !IsPedAPlayer(pedHandle))
                {
                    continue;
                }

                int playerHandle = NetworkGetEntityOwner(pedHandle);
                Player player = GetPlayerFromServerId(playerHandle);

                if (player is null || player == source)
                {
                    continue;
                }

                int warpOutFlag = 16;

                TaskLeaveVehicle(pedHandle, vehicleHandle, warpOutFlag);

                player.TriggerEvent("vMenu:Notify", "O dono de o veículo has kicked you out.");
            }
        }
        #endregion

        #region clear area near pos
        /// <summary>
        /// Clear the area near this point for all players.
        /// </summary>
        [EventHandler("vMenu:ClearArea")]
        internal void ClearAreaNearPos([FromSource] Player source)
        {
            Ped ped = source.Character;
            Vector3 position = ped.Position;

            TriggerClientEvent("vMenu:ClearArea", position);
        }
        #endregion

        #region Manage weather and time changes.
        /// <summary>
        /// Loop used for syncing and keeping track of the time in-game.
        /// </summary>
        /// <returns></returns>
        private async Task TimeLoop()
        {
            if (IsServerTimeSynced)
            {
                var currentTime = DateTime.Now;
                CurrentMinutes = currentTime.Minute;
                CurrentHours = currentTime.Hour;

                // Update this once every 60 seconds.
                await Delay(60000);
            }
            else
            {
                if (!FreezeTime)
                {
                    if ((CurrentMinutes + 1) > 59)
                    {
                        CurrentMinutes = 0;
                        if ((CurrentHours + 1) > 23)
                        {
                            CurrentHours = 0;
                        }
                        else
                        {
                            CurrentHours++;
                        }
                    }
                    else
                    {
                        CurrentMinutes++;
                    }
                }
                await Delay(MinuteClockSpeed);
            }
        }

        /// <summary>
        /// Task used for syncing and changing weather dynamically.
        /// </summary>
        /// <returns></returns>
        private async Task WeatherLoop()
        {
            if (DynamicWeatherEnabled)
            {
                await Delay(DynamicWeatherMinutes * 60000);

                if (GetSettingsBool(Setting.vmenu_enable_weather_sync))
                {
                    // Manage dynamic weather changes.

                    {
                        // Disable dynamic weather because these weather types shouldn't randomly change.
                        if (CurrentWeather is "XMAS" or "HALLOWEEN" or "NEUTRAL")
                        {
                            DynamicWeatherEnabled = false;
                            return;
                        }

                        // Is it time to generate a new weather type?
                        if (GetGameTimer() - lastWeatherChange > (DynamicWeatherMinutes * 60000))
                        {
                            // Choose a new semi-random weather type.
                            RefreshWeather();

                            // Log if debug mode is on how long the change has taken and what the new weather type will be.
                            if (DebugMode)
                            {
                                Log($"Changing clima, novo clima: {AtualClima}");
                            }
                        }
                    }
                }
            }
            else
            {
                await Delay(5000);
            }
        }

        /// <summary>
        /// Select a new random weather type, based on the current weather and some patterns.
        /// </summary>
        private void RefreshWeather()
        {
            var random = new Random().Next(20);
            if (CurrentWeather is "RAIN" or "THUNDER")
            {
                CurrentWeather = "CLEARING";
            }
            else if (CurrentWeather == "CLEARING")
            {
                CurrentWeather = "CLOUDS";
            }
            else
            {
                CurrentWeather = random switch
                {
                    0 or 1 or 2 or 3 or 4 or 5 => CurrentWeather == "EXTRASUNNY" ? "CLEAR" : "EXTRASUNNY",
                    6 or 7 or 8 => CurrentWeather == "SMOG" ? "FOGGY" : "SMOG",
                    9 or 10 or 11 => CurrentWeather == "CLOUDS" ? "OVERCAST" : "CLOUDS",
                    12 or 13 or 14 => CurrentWeather == "CLOUDS" ? "OVERCAST" : "CLOUDS",
                    15 => CurrentWeather == "OVERCAST" ? "THUNDER" : "OVERCAST",
                    16 => CurrentWeather == "CLOUDS" ? "EXTRASUNNY" : "RAIN",
                    _ => CurrentWeather == "FOGGY" ? "SMOG" : "FOGGY",
                };
            }

        }
        #endregion

        #region Sync weather & time with clients
        /// <summary>
        /// Update the weather for all clients.
        /// </summary>
        /// <param name="newWeather"></param>
        /// <param name="dynamicWeatherNew"></param>
        [EventHandler("vMenu:UpdateServerWeather")]
        internal void UpdateWeather([FromSource] Player source, string newWeather, bool dynamicWeatherNew, bool enableSnow)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.WOSetWeather, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            // Automatically enable snow effects whenever one of the snow weather types is selected.
            if (newWeather is "XMAS" or "SNOWLIGHT" or "SNOW" or "BLIZZARD")
            {
                enableSnow = true;
            }

            // Update the new weather related variables.
            CurrentWeather = newWeather;
            DynamicWeatherEnabled = dynamicWeatherNew;
            ManualSnowEnabled = enableSnow;

            // Reset the dynamic weather loop timer to another (default) 10 mintues.
            lastWeatherChange = GetGameTimer();
        }

        [EventHandler("vMenu:UpdateServerBlackout")]
        internal void UpdateBlackout([FromSource] Player source, bool value)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.WOBlackout, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            BlackoutEnabled = value;
        }

        [EventHandler("vMenu:UpdateServerVehicleBlackout")]
        internal void UpdateVehicleBlackout([FromSource] Player source, bool value)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.WOVehBlackout, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            VehicleBlackoutEnabled = value;
        }

        /// <summary>
        /// Set a new random clouds type and opacity for all clients.
        /// </summary>
        /// <param name="removeClouds"></param>
        [EventHandler("vMenu:UpdateServerWeatherCloudsType")]
        internal void UpdateWeatherCloudsType([FromSource] Player source, bool removeClouds)
        {

            if (removeClouds)
            {
                if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.WORemoveClouds, source))
                {
                    BanManager.BanCheater(source);
                    return;
                }

                TriggerClientEvent("vMenu:SetClouds", 0f, "removed");
            }
            else
            {
                if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.WORandomizeClouds, source))
                {
                    BanManager.BanCheater(source);
                    return;
                }

                var opacity = float.Parse(new Random().NextDouble().ToString());
                var type = CloudTypes[new Random().Next(0, CloudTypes.Count)];
                TriggerClientEvent("vMenu:SetClouds", opacity, type);
            }
        }

        /// <summary>
        /// Set and sync the time to all clients.
        /// </summary>
        /// <param name="newHours"></param>
        /// <param name="newMinutes"></param>
        /// <param name="newFreezeTime"></param>
        [EventHandler("vMenu:UpdateServerTime")]
        internal async void UpdateTime([FromSource] Player source, int newHours, int newMinutes, bool newFreezeTime)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.TOSetTime, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            if (GetSettingsBool(Setting.vmenu_smooth_time_transitions))
            {
                CurrentHours = CurrentHours;
                CurrentMinutes = CurrentMinutes;
                FreezeTime = true;
                while (newHours != CurrentHours)
                {
                    if ((CurrentMinutes + 1) > 59)
                    {
                        CurrentMinutes = 0;
                        if ((CurrentHours + 1) > 23)
                        {
                            CurrentHours = 0;
                        }
                        else
                        {
                            CurrentHours++;
                        }
                    }
                    else
                    {
                        CurrentMinutes = CurrentMinutes + 5;
                    }
                    await Delay(0);
                }
                FreezeTime = newFreezeTime;   
            }
            CurrentHours = newHours;
            CurrentMinutes = newMinutes;
        }

        /// <summary>
        /// Set and sync if time is frozen for all clients.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="freezeTime"></param>
        [EventHandler("vMenu:FreezeServerTime")]
        internal void FreezeServerTime([FromSource] Player source, bool freezeTime)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.TOFreezeTime, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            FreezeTime = freezeTime;
        }
        #endregion

        #region Online Players Menu Actions
        /// <summary>
        /// Kick a specific player.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        /// <param name="kickReason"></param>
        [EventHandler("vMenu:KickPlayer")]
        internal void KickPlayer([FromSource] Player source, int target, string kickReason = "You have been kicked de o servidor.")
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.OPKick, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            Player targetPlayer = GetPlayerFromServerId(target);

            if (targetPlayer is null)
            {
                source.TriggerEvent("vMenu:Notify", "Failed para kick target, because o target não foi encontrado. Did they already leave?");
                return;
            }

            if (PermissionsManager.IsAllowed(PermissionsManager.Permission.DontKickMe, targetPlayer))
            {
                source.TriggerEvent("vMenu:Notify", "Sorry, este jogador can ~r~não ~w~ser kicked.");
                return;
            }

            KickLog($"Jogador: {source.Nome} has kicked: {targetJogador.Nome} para: {kickMotivo}.");

            source.TriggerEvent("vMenu:Notify", $"O target jogador (<C>{targetJogador.Nome}</C>) has been kicked.");

            targetPlayer.Drop(kickReason);
        }

        /// <summary>
        /// Kill a specific player.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        [EventHandler("vMenu:KillPlayer")]
        internal void KillPlayer([FromSource] Player source, int target)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.OPKill, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            Player targetPlayer = GetPlayerFromServerId(target);

            if (targetPlayer is null)
            {
                return;
            }

            targetPlayer.TriggerEvent("vMenu:KillMe", source.Name);
        }

        /// <summary>
        /// Teleport a specific player to another player.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        [EventHandler("vMenu:SummonPlayer")]
        internal async void SummonPlayer([FromSource] Player source, int target, int numberOfSeats)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.OPSummon, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            Player targetPlayer = GetPlayerFromServerId(target);

            if (targetPlayer is null)
            {
                return;
            }

            int targetPedHandle;
            Ped targetPed = targetPlayer.Character;

            if (targetPed is null || !DoesEntityExist(targetPedHandle = targetPed.Handle))
            {
                return;
            }

            bool lastVehicle = false;
            Ped sourcePed = source.Character;
            int sourcePedHandle = sourcePed.Handle;
            int sourcePedVehicle = GetVehiclePedIsIn(sourcePedHandle, lastVehicle);

            if (sourcePedVehicle == 0)
            {
                targetPed.Position = sourcePed.Position;
                return;
            }

            bool seatFound = false;

            // Seat indices start at `-1`
            numberOfSeats -= 1;

            for (int i = -1; i < numberOfSeats; i++)
            {
                bool seatFree = GetPedInVehicleSeat(sourcePedVehicle, i) == 0;

                if (!seatFree)
                {
                    continue;
                }

                Vector3 checkPosition;
                long timeout = GetGameTimer() + 1_500;
                Vector3 priorPosition = targetPed.Position;
                Vector3 newPosition = sourcePed.Position + new Vector3(0f, 0f, 5f);

                seatFound = true;
                targetPed.Position = newPosition;

                while (timeout > GetGameTimer() && priorPosition.DistanceToSquared(checkPosition = targetPed.Position) < newPosition.DistanceToSquared(checkPosition))
                {
                    await Delay(100);
                }

                if (timeout < GetGameTimer())
                {
                    source.TriggerEvent("vMenu:Notify", "Failed para teleport jogador.");
                    break;
                }

                SetPedIntoVehicle(targetPedHandle, sourcePedVehicle, i);
                break;
            }

            if (!seatFound)
            {
                source.TriggerEvent("vMenu:Notify", "Não free seats in seu veículo para summoned jogador.");
            }
        }

        [EventHandler("vMenu:SendMessageToPlayer")]
        internal void SendPrivateMessage([FromSource] Player source, int target, string message)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.OPSendMessage, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            bool sourcePmsDisabled = source.State.Get("vmenu_pms_disabled") ?? false;

            if (sourcePmsDisabled)
            {
                source.TriggerEvent("vMenu:Notify", "Você não pode send um privada mensagem se you have privada mensagems desativard yourself. Ativar them in o Outras Configurações menu e tente novamente.");
                return;
            }

            Player targetPlayer = GetPlayerFromServerId(target);

            if (targetPlayer is null)
            {
                source.TriggerEvent("vMenu:Notify", "Failed para send mensagem because o target não foi encontrado. Did they disconnect?");
                return;
            }

            bool targetPmsDisabled = targetPlayer.State.Get("vmenu_pms_disabled") ?? false;

            if (targetPmsDisabled)
            {
                source.TriggerEvent("vMenu:Notify", $"Sorry, seu privada mensagem para <C>{source.Nome}</C>~s~ não foi possível ser delivered because they have privada mensagems desativard.");
                return;
            }

            targetPlayer.TriggerEvent("vMenu:PrivateMessage", source.Handle, message);

            foreach (string playerHandle in joinedPlayers)
            {
                if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.OPSeePrivateMessages, playerHandle))
                {
                    continue;
                }

                Player player = GetPlayerFromServerId(playerHandle);

                player?.TriggerEvent("vMenu:Notify", $"[vMenu Staff Log] <C>{source.Nome}</C>~s~ sent um PM para <C>{targetJogador.Nome}</C>~s~: {mensagem}");
            }
        }
        #endregion

        #region logging and update checks notifications
        /// <summary>
        /// If enabled using convars, will log all kick actions to the server console as well as an external file.
        /// </summary>
        /// <param name="kickLogMesage"></param>
        private static void KickLog(string kickLogMesage)
        {
            //if (GetConvar("vMenuLogKickActions", "true") == "true")
            if (GetSettingsBool(Setting.vmenu_log_kick_actions))
            {
                var file = LoadResourceFile(GetCurrentResourceName(), "vmenu.log") ?? "";
                var date = DateTime.Now;
                var formattedDate = (date.Day < 10 ? "0" : "") + date.Day + "-" +
                    (date.Month < 10 ? "0" : "") + date.Month + "-" +
                    (date.Year < 10 ? "0" : "") + date.Year + " " +
                    (date.Hour < 10 ? "0" : "") + date.Hour + ":" +
                    (date.Minute < 10 ? "0" : "") + date.Minute + ":" +
                    (date.Second < 10 ? "0" : "") + date.Second;
                var outputFile = file + $"[\t{formattedDate}\t] [KICK ACTION] {kickLogMesage}\n";
                SaveResourceFile(GetCurrentResourceName(), "vmenu.log", outputFile, -1);
                Debug.WriteLine("^3[vMenu] [KICK]^7 " + kickLogMesage + "\n");
            }
        }

        #endregion

        #region Add teleport location
        [EventHandler("vMenu:SaveTeleportLocation")]
        internal void AddTeleportLocation([FromSource] Player source, string locationJson)
        {
            if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.MSTeleportSaveLocation, source))
            {
                BanManager.BanCheater(source);
                return;
            }

            TeleportLocation teleportLocation;

            try
            {
                teleportLocation = JsonConvert.DeserializeObject<TeleportLocation>(locationJson);
            }
            catch
            {
                Log("Teleport localização não foi possível ser deserialized, localização foi não salvo.", LogLevel.error);
                return;
            }

            if (GetTeleportLocationsData().Exists(loc => loc.name == teleportLocation.name))
            {
                Log("A teleport localização com this nome already exists, localização foi não salvo.", LogLevel.error);
                return;
            }
            var locs = GetLocations();
            locs.teleports.Add(teleportLocation);
            if (!SaveResourceFile(GetCurrentResourceName(), "config/locations.json", JsonConvert.SerializeObject(locs, Formatting.Indented), -1))
            {
                Log("Could não salvar localizaçãos.json arquivo, motivo desconhecido.", LogLevel.error);
            }
            TriggerClientEvent("vMenu:UpdateTeleportLocations", JsonConvert.SerializeObject(locs.teleports));
        }
        #endregion

        #region Infinity bits
        // TODO: Replace this logic and all child logic with statebags (server set, client read)
        [EventHandler("vMenu:RequestPlayerList")]
        internal void RequestPlayerListFromPlayer([FromSource] Player player)
        {
            player.TriggerEvent("vMenu:ReceivePlayerList", Players.Select(p => new
            {
                n = p.Name,
                s = int.Parse(p.Handle),
            }));
        }

        [EventHandler("vMenu:GetPlayerCoords")]
        internal void GetPlayerCoords([FromSource] Player source, long rpcId, int playerId, NetworkCallbackDelegate callback)
        {
            var coords = Vector3.Zero;

            if (PermissionsManager.IsAllowed(PermissionsManager.Permission.OPTeleport, source))
            {
                Player targetPlayer = GetPlayerFromServerId(playerId);

                if (targetPlayer is not null)
                {
                    Ped targetPed = targetPlayer.Character;

                    if (targetPed is not null && DoesEntityExist(targetPed.Handle))
                    {
                        coords = targetPed.Position;
                    }
                }
            }

            source.TriggerEvent("vMenu:GetPlayerCoords:reply", rpcId, coords);
        }
        #endregion

        #region Player join/quit
        private readonly HashSet<string> joinedPlayers = new();

        private IEnumerable<Player> GetJoinQuitNotifPlayers()
        {
            List<Player> players = [];

            foreach (string playerHandle in joinedPlayers)
            {
                if (!PermissionsManager.IsAllowed(PermissionsManager.Permission.MSJoinQuitNotifs, playerHandle))
                {
                    continue;
                }

                Player player = GetPlayerFromServerId(playerHandle);

                if (player is not null)
                {
                    players.Add(player);
                }
            }

            return players;
        }

        private async Task PlayersFirstTick()
        {
            Tick -= PlayersFirstTick;

            // Allow plenty of time for the connected clients to restart their client scripts
            await Delay(3_000);

            foreach (var player in Players)
            {
                joinedPlayers.Add(player.Handle);

                PermissionsManager.SetPermissionsForPlayer(player);
                SupplementaryPermissionManager.SetPermissionsForPlayer(player);
            }
        }

        [EventHandler("playerJoining")]
        internal void OnPlayerJoining([FromSource] Player sourcePlayer)
        {
            joinedPlayers.Add(sourcePlayer.Handle);

            PermissionsManager.SetPermissionsForPlayer(sourcePlayer);
            SupplementaryPermissionManager.SetPermissionsForPlayer(sourcePlayer);

            string sourcePlayerName = sourcePlayer.Name;

            foreach (Player notifPlayer in GetJoinQuitNotifPlayers())
            {
                notifPlayer.TriggerEvent("vMenu:PlayerJoinQuit", sourcePlayerName, null);
            }
        }

        [EventHandler("playerDropped")]
        internal void OnPlayerDropped([FromSource] Player sourcePlayer, string reason)
        {
            if (!joinedPlayers.Contains(sourcePlayer.Handle))
            {
                return;
            }

            joinedPlayers.Remove(sourcePlayer.Handle);

            string sourcePlayerName = sourcePlayer.Name;
            
            foreach (Player notifPlayer in GetJoinQuitNotifPlayers())
            {
                notifPlayer.TriggerEvent("vMenu:PlayerJoinQuit", sourcePlayerName, reason);
            }
        }
        #endregion

        #region Utilities
        private void SetupAddonPerms(Dictionary<string, List<string>> whitelists, Dictionary<string, List<string>> addons)
        {
            if (whitelists.ContainsKey("whitelistedweapons"))
            {
                foreach (var whitelist in whitelists["whitelistedweapons"])
                {
                    if (!SupplementaryPermissionManager.Permission.Contains("WW" + whitelist.ToLower().Replace("weapon_", "")))
                    {
                        SupplementaryPermissionManager.Permission.Add("WW" + whitelist.ToLower().Replace("weapon_", ""));
                    }
                }
            }
            if (whitelists.ContainsKey("whitelistedvehicle"))
            {
                foreach (var whitelist in whitelists["whitelistedvehicle"])
                {
                    if (!SupplementaryPermissionManager.Permission.Contains("VW" + whitelist.ToLower()))
                    {
                        SupplementaryPermissionManager.Permission.Add("VW" + whitelist.ToLower());
                    }
                }
            }
            if (whitelists.ContainsKey("whitelistedpeds"))
            {
                foreach (var whitelist in whitelists["whitelistedpeds"])
                {
                    if (!SupplementaryPermissionManager.Permission.Contains("PW" + whitelist.ToLower()))
                    {
                        SupplementaryPermissionManager.Permission.Add("PW" + whitelist.ToLower());
                    }
                }
            }
            
            List<string> supplementaryPermissions = [
                "#################################################################",
                "# THIS IS A TEMPLATE FILE. #",
                "# DO NÃOT EDIT, MAKE A COPY AND EDIT THE COPY. #",
                "#################################################################",
            ];
            foreach (string permission in SupplementaryPermissionManager.Permission)
            {
                supplementaryPermissions.Add("add_ace builtin.everyone \"" + SupplementaryPermissionManager.GetAceName(permission) + "\" allow");
            }
            Directory.CreateDirectory(Path.Combine(GetResourcePath(GetCurrentResourceName()), "config", "templates"));
            File.WriteAllLines(Path.Combine(GetResourcePath(GetCurrentResourceName()), "config", "templates", "SupplementaryPermissionTemplate.cfg"), supplementaryPermissions.ToArray());
        }
        private Player GetPlayerFromServerId(string serverId)
        {
            if (!int.TryParse(serverId, out int serverIdInt))
            {
                return null;
            }

            return GetPlayerFromServerId(serverIdInt);
        }

        private Player GetPlayerFromServerId(int serverId)
        {
            string serverIdString = serverId.ToString();

            if (serverId <= 0 || !DoesPlayerExist(serverIdString))
            {
                return null;
            }

            return Players[serverId];
        }
        #endregion
    }
}
