﻿using System.Collections.Generic;
using System.Linq;

using CitizenFX.Core;

using MenuAPI;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.PermissionsManager;

namespace vMenuClient.menus
{
    public class PersonalVehicle
    {
        // Variables
        private Menu menu;
        public bool EnableVehicleBlip { get; private set; } = UserDefaults.PVEnableVehicleBlip;

        // Empty constructor
        public PersonalVehicle() { }

        public Vehicle CurrentPersonalVehicle { get; internal set; } = null;

        public Menu VehicleDoorsMenu { get; internal set; } = null;


        /// <summary>
        /// Creates the menu.
        /// </summary>
        private void CreateMenu()
        {
            // Menu
            menu = new Menu(GetSafePlayerName(Game.Player.Name), "Veículo Pessoal Opções");

            // menu items
            var setVehice = new MenuItem("Definir Veículo", "Definirs seu veículo atual como seu pessoal veículo. se você já tem um pessoal veículo definir então isto irá substituir seu seleção.") { Label = "Veículo Atual: Nenhum" };
            var toggleEngine = new MenuItem("Ligar/Desligar Motor", "Alternars o motor em ou desligado, even quando você're não dentro de o veículo. Isto não funcionar se outra pessoa é atualmente usando seu veículo.");
            var toggleLights = new MenuListItem("Definir Luzes do Veículo", new List<string>() { "Force em", "Force desligado", "Redefinir" }, 0, "Isto irá ativar ou desativar seu veículo headluzes, o motor de seu veículo precisas para ser running para isto para funcionar.");
            var toggleStance = new MenuListItem("Altura do Veículo", new List<string>() { "Padrão", "Lowered" }, 0, "Selecionar stance para seu Veículo Pessoal.");
            var kickAllPassengers = new MenuItem("Remover Passageiros", "Isto irá remover todos passageiros de seu pessoal veículo.");
            //MenuItem
            var lockDoors = new MenuItem("Trancarro Portas do Veículo", "Isto irá lock todcomo ums suas veículo portas para todos jogadores. qualquer pessoa já dentro irá always ser able para sair o veículo, even se o portas estão trancadas.");
            var unlockDoors = new MenuItem("Destrancarro Portas do Veículo", "Isto irá destrancar todcomo ums suas veículo portas para todos jogadores.");
            var doorsMenuBtn = new MenuItem("Portas do Veículo", "Abrir, fechar, remover e restaurar veículo portcomo umqui.")
            {
                Label = "→→→"
            };
            var soundHorn = new MenuItem("Sound Horn", "Sounds o buzina de o veículo.");
            var toggleAlarm = new MenuItem("Ativar/Desativar Som do Alarme", "Alternars o veículo alarme sound em ou desligado. Isto não definir um alarme. isso algunsnte alternars o atual estado do som de o alarme.");
            var enableBlip = new MenuCheckboxItem("Add Blip para Veículo Pessoal", "Ativa ou desativa o blip that gets adicionado quando você marcar um veículo como seu pessoal veículo.", EnableVehicleBlip) { Style = MenuCheckboxItem.CheckboxStyle.Cross };
            var exclusiveDriver = new MenuCheckboxItem("Exclusive Driver", "se ativado, então você irá ser o algunsnte one that pode entrar o motoristas seat. outro jogadores irá não ser able para drive o carro. eles ainda pode ser passageiros.", false) { Style = MenuCheckboxItem.CheckboxStyle.Cross };
            //submenu
            VehicleDoorsMenu = new Menu("Portas do Veículo", "Gerenciar Portas do Veículo");
            MenuController.AddSubmenu(menu, VehicleDoorsMenu);
            MenuController.BindMenuItem(menu, VehicleDoorsMenu, doorsMenuBtn);

            // This is always allowed if this submenu is created/allowed.
            menu.AddMenuItem(setVehice);

            // Add conditional features.

            // Toggle engine.
            if (IsAllowed(Permission.PVToggleEngine))
            {
                menu.AddMenuItem(toggleEngine);
            }

            // Toggle lights
            if (IsAllowed(Permission.PVToggleLights))
            {
                menu.AddMenuItem(toggleLights);
            }

            // Toggle stance
            if (IsAllowed(Permission.PVToggleStance))
            {
                menu.AddMenuItem(toggleStance);
            }

            // Kick vehicle passengers
            if (IsAllowed(Permission.PVKickPassengers))
            {
                menu.AddMenuItem(kickAllPassengers);
            }

            // Lock and unlock vehicle doors
            if (IsAllowed(Permission.PVLockDoors))
            {
                menu.AddMenuItem(lockDoors);
                menu.AddMenuItem(unlockDoors);
            }

            if (IsAllowed(Permission.PVDoors))
            {
                menu.AddMenuItem(doorsMenuBtn);
            }

            // Sound horn
            if (IsAllowed(Permission.PVSoundHorn))
            {
                menu.AddMenuItem(soundHorn);
            }

            // Toggle alarm sound
            if (IsAllowed(Permission.PVToggleAlarm))
            {
                menu.AddMenuItem(toggleAlarm);
            }

            // Enable blip for personal vehicle
            if (IsAllowed(Permission.PVAddBlip))
            {
                menu.AddMenuItem(enableBlip);
            }

            if (IsAllowed(Permission.PVExclusiveDriver))
            {
                menu.AddMenuItem(exclusiveDriver);
            }


            // Handle list presses
            menu.OnListItemSelect += (sender, item, itemIndex, index) =>
            {
                var veh = CurrentPersonalVehicle;
                if (veh != null && veh.Exists())
                {
                    if (!NetworkHasControlOfEntity(CurrentPersonalVehicle.Handle))
                    {
                        if (!NetworkRequestControlOfEntity(CurrentPersonalVehicle.Handle))
                        {
                            Notify.Error("você atualmente não pode controlar este veículo. é outra pessoa atualmente driving seu carro? Por favor tente novamente depois making certeza outro jogadores estão não controlarando seu veículo.");
                            return;
                        }
                    }

                    if (item == toggleLights)
                    {
                        PressKeyFob(CurrentPersonalVehicle);
                        if (itemIndex == 0)
                        {
                            SetVehicleLights(CurrentPersonalVehicle.Handle, 3);
                        }
                        else if (itemIndex == 1)
                        {
                            SetVehicleLights(CurrentPersonalVehicle.Handle, 1);
                        }
                        else
                        {
                            SetVehicleLights(CurrentPersonalVehicle.Handle, 0);
                        }
                    }
                    else if (item == toggleStance)
                    {
                        PressKeyFob(CurrentPersonalVehicle);
                        if (itemIndex == 0)
                        {
                            SetReduceDriftVehicleSuspension(CurrentPersonalVehicle.Handle, false);
                        }
                        else if (itemIndex == 1)
                        {
                            SetReduceDriftVehicleSuspension(CurrentPersonalVehicle.Handle, true);
                        }
                    }

                }
                else
                {
                    Notify.Error("você tem não yet selecionado um pessoal veículo, ou seu veículo foi excluído. Definir um pessoal veículo antes você pode use these opções.");
                }
            };

            // Handle checkbox changes
            menu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == enableBlip)
                {
                    EnableVehicleBlip = _checked;
                    if (EnableVehicleBlip)
                    {
                        if (CurrentPersonalVehicle != null && CurrentPersonalVehicle.Exists())
                        {
                            if (CurrentPersonalVehicle.AttachedBlip == null || !CurrentPersonalVehicle.AttachedBlip.Exists())
                            {
                                CurrentPersonalVehicle.AttachBlip();
                            }
                            CurrentPersonalVehicle.AttachedBlip.Sprite = BlipSprite.PersonalVehicleCar;
                            CurrentPersonalVehicle.AttachedBlip.Name = "Veículo Pessoal";
                        }
                        else
                        {
                            Notify.Error("você tem não yet selecionado um pessoal veículo, ou seu veículo foi excluído. Definir um pessoal veículo antes você pode use these opções.");
                        }

                    }
                    else
                    {
                        if (CurrentPersonalVehicle != null && CurrentPersonalVehicle.Exists() && CurrentPersonalVehicle.AttachedBlip != null && CurrentPersonalVehicle.AttachedBlip.Exists())
                        {
                            CurrentPersonalVehicle.AttachedBlip.Delete();
                        }
                    }
                }
                else if (item == exclusiveDriver)
                {
                    if (CurrentPersonalVehicle != null && CurrentPersonalVehicle.Exists())
                    {
                        if (NetworkRequestControlOfEntity(CurrentPersonalVehicle.Handle))
                        {
                            if (_checked)
                            {
                                // SetVehicleExclusiveDriver, but the current version is broken in C# so we manually execute it.
                                CitizenFX.Core.Native.Function.Call((CitizenFX.Core.Native.Hash)0x41062318F23ED854, CurrentPersonalVehicle, true);
                                SetVehicleExclusiveDriver_2(CurrentPersonalVehicle.Handle, Game.PlayerPed.Handle, 1);
                            }
                            else
                            {
                                // SetVehicleExclusiveDriver, but the current version is broken in C# so we manually execute it.
                                CitizenFX.Core.Native.Function.Call((CitizenFX.Core.Native.Hash)0x41062318F23ED854, CurrentPersonalVehicle, false);
                                SetVehicleExclusiveDriver_2(CurrentPersonalVehicle.Handle, 0, 1);
                            }
                        }
                        else
                        {
                            item.Checked = !_checked;
                            Notify.Error("você atualmente não pode controlar este veículo. é outra pessoa atualmente driving seu carro? Por favor tente novamente depois making certeza outro jogadores estão não controlarando seu veículo.");
                        }
                    }
                }
            };

            // Handle button presses.
            menu.OnItemSelect += (sender, item, index) =>
            {
                if (item == setVehice)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        var veh = GetVehicle();
                        if (veh != null && veh.Exists())
                        {
                            if (Game.PlayerPed == veh.Driver)
                            {
                                CurrentPersonalVehicle = veh;
                                veh.PreviouslyOwnedByPlayer = true;
                                veh.IsPersistent = true;
                                if (EnableVehicleBlip && IsAllowed(Permission.PVAddBlip))
                                {
                                    if (veh.AttachedBlip == null || !veh.AttachedBlip.Exists())
                                    {
                                        veh.AttachBlip();
                                    }
                                    veh.AttachedBlip.Sprite = BlipSprite.PersonalVehicleCar;
                                    veh.AttachedBlip.Name = "Veículo Pessoal";
                                }
                                var name = GetLabelText(veh.DisplayName);
                                if (string.IsNullOrEmpty(name) || name.ToLower() == "null")
                                {
                                    name = veh.DisplayName;
                                }
                                item.Label = $"Atual Veículo: {nome}";
                            }
                            else
                            {
                                Notify.Error(CommonErrors.NeedToBeTheDriver);
                            }
                        }
                        else
                        {
                            Notify.Error(CommonErrors.NoVehicle);
                        }
                    }
                    else
                    {
                        Notify.Error(CommonErrors.NoVehicle);
                    }
                }
                else if (CurrentPersonalVehicle != null && CurrentPersonalVehicle.Exists())
                {
                    if (item == kickAllPassengers)
                    {
                        Ped[] occupants = CurrentPersonalVehicle.Occupants;

                        if (occupants.Count() > 0 && occupants.Any(p => p != Game.PlayerPed && p.IsPlayer))
                        {
                            TriggerServerEvent("vMenu:GetOutOfCar", CurrentPersonalVehicle.NetworkId);
                        }
                        else
                        {
                            Notify.Info("há estão no outro jogadores em seu veículo that precisa para ser expulsos.");
                        }
                    }
                    else
                    {
                        if (!NetworkHasControlOfEntity(CurrentPersonalVehicle.Handle))
                        {
                            if (!NetworkRequestControlOfEntity(CurrentPersonalVehicle.Handle))
                            {
                                Notify.Error("você atualmente não pode controlar este veículo. é outra pessoa atualmente driving seu carro? Por favor tente novamente depois making certeza outro jogadores estão não controlarando seu veículo.");
                                return;
                            }
                        }

                        if (item == toggleEngine)
                        {
                            PressKeyFob(CurrentPersonalVehicle);
                            SetVehicleEngineOn(CurrentPersonalVehicle.Handle, !CurrentPersonalVehicle.IsEngineRunning, true, true);
                        }

                        else if (item == lockDoors || item == unlockDoors)
                        {
                            PressKeyFob(CurrentPersonalVehicle);
                            var _lock = item == lockDoors;
                            LockOrUnlockDoors(CurrentPersonalVehicle, _lock);
                        }

                        else if (item == soundHorn)
                        {
                            PressKeyFob(CurrentPersonalVehicle);
                            SoundHorn(CurrentPersonalVehicle);
                        }

                        else if (item == toggleAlarm)
                        {
                            PressKeyFob(CurrentPersonalVehicle);
                            ToggleVehicleAlarm(CurrentPersonalVehicle);
                        }
                    }
                }
                else
                {
                    Notify.Error("você tem não yet selecionado um pessoal veículo, ou seu veículo foi excluído. Definir um pessoal veículo antes você pode use these opções.");
                }
            };

            #region Doors submenu 
            var openAll = new MenuItem("Abrir Todcomo ums Portas", "Abrir Todos os pneus do veículo portas.");
            var closeAll = new MenuItem("Fechar Todcomo ums Portas", "Fechar Todos os pneus do veículo portas.");
            var LF = new MenuItem("Porta Dianteira Esquerda", "Abrir/fechar o esquerda dianteira porta.");
            var RF = new MenuItem("Porta Dianteira Direissoa", "Abrir/fechar o direissoa dianteira porta.");
            var LR = new MenuItem("Porta Traseira Esquerda", "Abrir/fechar o esquerda traseira porta.");
            var RR = new MenuItem("Porta Traseira Direissoa", "Abrir/fechar o direissoa traseira porta.");
            var HD = new MenuItem("Hood", "Abrir/fechar o hood.");
            var TR = new MenuItem("Trunk", "Abrir/fechar o trunk.");
            var E1 = new MenuItem("Extra 1", "Abrir/fechar o extra porta (#1). Nota isto porta é não presente em maioria veículos.");
            var E2 = new MenuItem("Extra 2", "Abrir/fechar o extra porta (#2). Nota isto porta é não presente em maioria veículos.");
            var BB = new MenuItem("Bomb Bay", "Abrir/fechar o bomb bay. somente disponível em alguns planes.");
            var doors = new List<string>() { "Dianteira Esquerda", "Dianteira Direissoa", "Traseira Esquerda", "Traseira Direissoa", "Hood", "Trunk", "Extra 1", "Extra 2", "Bomb Bay" };
            var removeDoorList = new MenuListItem("Remover Porta", doors, 0, "Remover um specific veículo porta completely.");
            var deleteDoors = new MenuCheckboxItem("Excluir Portas Removidas", "quando ativado, portas that você removerr usando o lista acima irá ser excluído de o mundo. se desativado, então o portas irá just cair em o chão.", false);

            VehicleDoorsMenu.AddMenuItem(LF);
            VehicleDoorsMenu.AddMenuItem(RF);
            VehicleDoorsMenu.AddMenuItem(LR);
            VehicleDoorsMenu.AddMenuItem(RR);
            VehicleDoorsMenu.AddMenuItem(HD);
            VehicleDoorsMenu.AddMenuItem(TR);
            VehicleDoorsMenu.AddMenuItem(E1);
            VehicleDoorsMenu.AddMenuItem(E2);
            VehicleDoorsMenu.AddMenuItem(BB);
            VehicleDoorsMenu.AddMenuItem(openAll);
            VehicleDoorsMenu.AddMenuItem(closeAll);
            VehicleDoorsMenu.AddMenuItem(removeDoorList);
            VehicleDoorsMenu.AddMenuItem(deleteDoors);

            VehicleDoorsMenu.OnListItemSelect += (sender, item, index, itemIndex) =>
            {
                var veh = CurrentPersonalVehicle;
                if (veh != null && veh.Exists())
                {
                    if (!NetworkHasControlOfEntity(CurrentPersonalVehicle.Handle))
                    {
                        if (!NetworkRequestControlOfEntity(CurrentPersonalVehicle.Handle))
                        {
                            Notify.Error("você atualmente não pode controlar este veículo. é outra pessoa atualmente driving seu carro? Por favor tente novamente depois making certeza outro jogadores estão não controlarando seu veículo.");
                            return;
                        }
                    }

                    if (item == removeDoorList)
                    {
                        PressKeyFob(veh);
                        SetVehicleDoorBroken(veh.Handle, index, deleteDoors.Checked);
                    }
                }
            };

            VehicleDoorsMenu.OnItemSelect += (sender, item, index) =>
            {
                var veh = CurrentPersonalVehicle;
                if (veh != null && veh.Exists() && !veh.IsDead)
                {
                    if (!NetworkHasControlOfEntity(CurrentPersonalVehicle.Handle))
                    {
                        if (!NetworkRequestControlOfEntity(CurrentPersonalVehicle.Handle))
                        {
                            Notify.Error("você atualmente não pode controlar este veículo. é outra pessoa atualmente driving seu carro? Por favor tente novamente depois making certeza outro jogadores estão não controlarando seu veículo.");
                            return;
                        }
                    }

                    if (index < 8)
                    {
                        var open = GetVehicleDoorAngleRatio(veh.Handle, index) > 0.1f;
                        PressKeyFob(veh);
                        if (open)
                        {
                            SetVehicleDoorShut(veh.Handle, index, false);
                        }
                        else
                        {
                            SetVehicleDoorOpen(veh.Handle, index, false, false);
                        }
                    }
                    else if (item == openAll)
                    {
                        PressKeyFob(veh);
                        for (var door = 0; door < 8; door++)
                        {
                            SetVehicleDoorOpen(veh.Handle, door, false, false);
                        }
                    }
                    else if (item == closeAll)
                    {
                        PressKeyFob(veh);
                        for (var door = 0; door < 8; door++)
                        {
                            SetVehicleDoorShut(veh.Handle, door, false);
                        }
                    }
                    else if (item == BB && veh.HasBombBay)
                    {
                        PressKeyFob(veh);
                        var bombBayOpen = AreBombBayDoorsOpen(veh.Handle);
                        if (bombBayOpen)
                        {
                            veh.CloseBombBay();
                        }
                        else
                        {
                            veh.OpenBombBay();
                        }
                    }
                    else
                    {
                        Notify.Error("você tem não yet selecionado um pessoal veículo, ou seu veículo foi excluído. Definir um pessoal veículo antes você pode use these opções.");
                    }
                }
            };
            #endregion
        }



        private async void SoundHorn(Vehicle veh)
        {
            if (veh != null && veh.Exists())
            {
                var timer = GetGameTimer();
                while (GetGameTimer() - timer < 1000)
                {
                    SoundVehicleHornThisFrame(veh.Handle);
                    await Delay(0);
                }
            }
        }

        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }
    }
}
