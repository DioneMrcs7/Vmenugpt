using System;
using System.Collections.Generic;
using System.Linq;

using CitizenFX.Core;

using MenuAPI;

using Newtonsoft.Json;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;

namespace vMenuClient.menus
{
    public class SavedVehicles
    {
        // Variables
        private Menu classMenu;
        private Menu savedVehicleTypeMenu;
        private readonly Menu vehicleCategoryMenu = new("Categories", "Gerenciar Veículos Salvos");
        private readonly Menu savedVehiclesCategoryMenu = new("Category", "I get updated at runtime!");
        private readonly Menu selectedVehicleMenu = new("Gerenciar Veículo", "Gerenciar this salvo veículo.");
        private readonly Menu unavailableVehiclesMenu = new("Veículos Ausentes", "Veículos Salvos Indisponíveis");
        private Dictionary<string, VehicleInfo> savedVehicles = new();
        private readonly List<Menu> subMenus = new();
        private KeyValuePair<string, VehicleInfo> currentlySelectedVehicle = new();
        private int deleteButtonPressedCount = 0;
        private int replaceButtonPressedCount = 0;
        private SavedVehicleCategory currentCategory;

        // Need to be editable from other functions
        private readonly MenuListItem setCategoryBtn = new("Definir Categoria do Veículo", new List<string> { }, 0, "Definirs this Veículo's categoria. Selecionar para salvar.");

        /// <summary>
        /// Creates the menu.
        /// </summary>
        private void CreateClassMenu()
        {
            var menuTitle = "Veículos Salvos";
            #region Create menus and submenus
            // Create the menu.
            classMenu = new Menu(menuTitle, "Gerenciar Veículos Salvos");

            for (var i = 0; i < 23; i++)
            {
                var categoryMenu = new Menu("Veículos Salvos", GetLabelText($"VEH_CLASS_{i}"));

                var vehClassButton = new MenuItem(GetLabelText($"VEH_CLASS_{i}"), $"Todos salvo veículos de o {GetLabelText($"VEH_CLASS_{i}")} categoria.");
                subMenus.Add(categoryMenu);
                MenuController.AddSubmenu(classMenu, categoryMenu);
                classMenu.AddMenuItem(vehClassButton);
                vehClassButton.Label = "→→→";
                MenuController.BindMenuItem(classMenu, categoryMenu, vehClassButton);

                categoryMenu.OnMenuClose += (sender) =>
                {
                    UpdateMenuAvailableCategories();
                };

                categoryMenu.OnItemSelect += (sender, item, index) =>
                {
                    UpdateSelectedVehicleMenu(item, sender);
                };
            }

            var unavailableModels = new MenuItem("Veículos Salvos Indisponíveis", "These veículos estão atualmente undisponível because o models estão não present in o game. These veículos estão most likely não being streamed de o servidor.")
            {
                Label = "→→→"
            };

            classMenu.AddMenuItem(unavailableModels);
            MenuController.BindMenuItem(classMenu, unavailableVehiclesMenu, unavailableModels);
            MenuController.AddSubmenu(classMenu, unavailableVehiclesMenu);


            MenuController.AddMenu(savedVehicleTypeMenu);
            MenuController.AddMenu(savedVehiclesCategoryMenu);
            MenuController.AddMenu(selectedVehicleMenu);

            // Load selected category
            vehicleCategoryMenu.OnItemSelect += async (sender, item, index) =>
            {
                // Create new category
                if (item.ItemData is not SavedVehicleCategory savedVehicleCategory)
                {
                    var name = await GetUserInput(windowTitle: "Digite um categoria nome.", maxInputLength: 30);
                    if (string.IsNullOrEmpty(name) || name.ToLower() == "uncategorized" || name.ToLower() == "create new")
                    {
                        Notify.Error(CommonErrors.InvalidInput);
                        return;
                    }
                    else
                    {
                        var description = await GetUserInput(windowTitle: "Digite um categoria description (optional).", maxInputLength: 120);
                        var newCategory = new SavedVehicleCategory
                        {
                            Name = name,
                            Description = description
                        };

                        if (StorageManager.SaveJsonData("saved_veh_category_" + name, JsonConvert.SerializeObject(newCategory), false))
                        {
                            Notify.Success($"Seu categoria (~g~<C>{name}</C>~s~) has been salvo.");
                            Log($"Salvard Categoria {name}.");
                            MenuController.CloseAllMenus();
                            UpdateSavedVehicleCategoriesMenu();
                            savedVehiclesCategoryMenu.OpenMenu();

                            currentCategory = newCategory;
                        }
                        else
                        {
                            Notify.Error($"Salvando falhou, most likely because this nome (~y~<C>{name}</C>~s~) é already in use.");
                            return;
                        }
                    }
                }
                // Select an old category
                else
                {
                    currentCategory = savedVehicleCategory;
                }

                bool isUncategorized = currentCategory.Name == "Uncategorized";

                savedVehiclesCategoryMenu.MenuTitle = currentCategory.Name;
                savedVehiclesCategoryMenu.MenuSubtitle = $"~s~Categoria: ~y~{currentCategory.Name}";
                savedVehiclesCategoryMenu.ClearMenuItems();

                var iconNames = Enum.GetNames(typeof(MenuItem.Icon)).ToList();

                string ChangeCallback(MenuDynamicListItem item, bool left)
                {
                    int currentIndex = iconNames.IndexOf(item.CurrentItem);
                    int newIndex = left ? currentIndex - 1 : currentIndex + 1;

                    // If going past the start or end of the list
                    if (iconNames.ElementAtOrDefault(newIndex) == default)
                    {
                        if (left)
                        {
                            newIndex = iconNames.Count - 1;
                        }
                        else
                        {
                            newIndex = 0;
                        }
                    }

                    item.RightIcon = (MenuItem.Icon)newIndex;

                    return iconNames[newIndex];
                }

                var renameBtn = new MenuItem("Renomear Categoria", "Renomear this categoria.")
                {
                    Enabled = !isUncategorized
                };
                var descriptionBtn = new MenuItem("Alterar Categoria Description", "Alterar this categoria's description.")
                {
                    Enabled = !isUncategorized
                };
                var iconBtn = new MenuDynamicListItem("Alterar Categoria Icon", iconNames[(int)currentCategory.Icon], new MenuDynamicListItem.ChangeItemCallback(ChangeCallback), "Alterar this categoria's icon. Selecionar para salvar.")
                {
                    Enabled = !isUncategorized,
                    RightIcon = currentCategory.Icon
                };
                var deleteBtn = new MenuItem("Excluir Categoria", "Excluir this categoria. This não pode ser desfeito!")
                {
                    RightIcon = MenuItem.Icon.WARNING,
                    Enabled = !isUncategorized
                };
                var deleteCharsBtn = new MenuCheckboxItem("Excluir Todos Veículos", "If checked, quando \"Excluir Categoria\" é pressed, todos o salvo veículos in this categoria will ser excluird as well. If não checked, salvo veículos will ser moved para \"Uncategorized\".")
                {
                    Enabled = !isUncategorized
                };

                savedVehiclesCategoryMenu.AddMenuItem(renameBtn);
                savedVehiclesCategoryMenu.AddMenuItem(descriptionBtn);
                savedVehiclesCategoryMenu.AddMenuItem(iconBtn);
                savedVehiclesCategoryMenu.AddMenuItem(deleteBtn);
                savedVehiclesCategoryMenu.AddMenuItem(deleteCharsBtn);

                var spacer = GetSpacerMenuItem("↓ Vehicles ↓");
                savedVehiclesCategoryMenu.AddMenuItem(spacer);

                if (savedVehicles.Count > 0)
                {
                    List<MenuItem> spawnableVehicles = [];   
                    List<MenuItem> unspawnableVehicles = [];   

                    foreach (var kvp in savedVehicles)
                    {
                        string name = kvp.Key;
                        VehicleInfo vehicle = kvp.Value;

                        if (string.IsNullOrEmpty(vehicle.Category))
                        {
                            if (!isUncategorized)
                            {
                                continue;
                            }
                        }
                        else
                        {
                            if (vehicle.Category != currentCategory.Name)
                            {
                                continue;
                            }
                        }

                        string buttonName = name.Substring(4);
                        bool canUse = IsModelInCdimage(vehicle.model);
                        string buttonDescription = "Gerenciar this salvo veículo.";

                        if (!canUse)
                        {
                            buttonName = $"~italic~{buttonName}~italic~";
                            buttonDescription += "\n\n~r~NÃOTE~w~~s~: This model não foi encontrado, e so cannot ser criared.";
                        }

                        var btn = new MenuItem(buttonName, buttonDescription)
                        {
                            Label = $"({vehicle.name}) →→→",
                            LeftIcon = canUse ? MenuItem.Icon.NONE : MenuItem.Icon.LOCK,
                            ItemData = kvp,
                        };

                        if (canUse)
                        {
                            spawnableVehicles.Add(btn);
                        }
                        else
                        {
                            unspawnableVehicles.Add(btn);
                        }
                    }

                    // Menu order: Category buttons -> Spawnable vehs -> Unspawnable vehs
                    foreach (MenuItem menuItem in spawnableVehicles.Concat(unspawnableVehicles))
                    {
                        savedVehiclesCategoryMenu.AddMenuItem(menuItem);
                    }
                }
            };

            savedVehiclesCategoryMenu.OnItemSelect += async (sender, item, index) =>
            {
                switch (index)
                {
                    // Rename Category
                    case 0:
                        var name = await GetUserInput(windowTitle: "Digite um novo categoria nome", defaultText: currentCategory.Name, maxInputLength: 30);

                        if (string.IsNullOrEmpty(name) || name.ToLower() == "uncategorized" || name.ToLower() == "create new")
                        {
                            Notify.Error(CommonErrors.InvalidInput);
                            return;
                        }
                        else if (GetAllCategoryNames().Contains(name) || !string.IsNullOrEmpty(GetResourceKvpString("saved_veh_category_" + name)))
                        {
                            Notify.Error(CommonErrors.SaveNameAlreadyExists);
                            return;
                        }

                        string oldName = currentCategory.Name;

                        currentCategory.Name = name;

                        if (StorageManager.SaveJsonData("saved_veh_category_" + name, JsonConvert.SerializeObject(currentCategory), false))
                        {
                            StorageManager.DeleteSavedStorageItem("saved_veh_category_" + oldName);

                            int totalCount = 0;
                            int updatedCount = 0;

                            if (savedVehicles.Count > 0)
                            {
                                foreach (var kvp in savedVehicles)
                                {
                                    string saveName = kvp.Key;
                                    VehicleInfo vehicle = kvp.Value;

                                    if (string.IsNullOrEmpty(vehicle.Category))
                                    {
                                        continue;
                                    }

                                    if (vehicle.Category != oldName)
                                    {
                                        continue;
                                    }

                                    totalCount++;

                                    vehicle.Category = name;

                                    if (StorageManager.SaveVehicleInfo(saveName, vehicle, true))
                                    {
                                        updatedCount++;
                                        Log($"Atualizado categoria para \"{saveName}\"");
                                    }
                                    else
                                    {
                                        Log($"Something went wrong quando updating categoria para \"{saveName}\"");
                                    }
                                }
                            }

                            Notify.Success($"Seu categoria has been renomed para ~g~<C>{name}</C>~s~. {updatedCount}/{totalCount} vehicles updated.");
                            MenuController.CloseAllMenus();
                            UpdateSavedVehicleCategoriesMenu();
                            vehicleCategoryMenu.OpenMenu();
                        }
                        else
                        {
                            Notify.Error("Something went wrong enquanto renaming seu categoria, seu antigo categoria will NÃOT ser excluird because de this.");
                        }
                        break;

                    // Change Category Description
                    case 1:
                        var description = await GetUserInput(windowTitle: "Digite um novo categoria description", defaultText: currentCategory.Description, maxInputLength: 120);

                        currentCategory.Description = description;

                        if (StorageManager.SaveJsonData("saved_veh_category_" + currentCategory.Name, JsonConvert.SerializeObject(currentCategory), true))
                        {
                            Notify.Success($"Seu categoria description has been alterard.");
                            MenuController.CloseAllMenus();
                            UpdateSavedVehicleCategoriesMenu();
                            vehicleCategoryMenu.OpenMenu();
                        }
                        else
                        {
                            Notify.Error("Something went wrong enquanto changing seu categoria description.");
                        }
                        break;

                    // Delete Category
                    case 3:
                        if (item.Label == "Tem certeza?")
                        {
                            bool deleteVehicles = (sender.GetMenuItems().ElementAt(4) as MenuCheckboxItem).Checked;

                            item.Label = "";
                            DeleteResourceKvp("saved_veh_category_" + currentCategory.Name);

                            int totalCount = 0;
                            int updatedCount = 0;

                            if (savedVehicles.Count > 0)
                            {
                                foreach (var kvp in savedVehicles)
                                {
                                    string saveName = kvp.Key;
                                    VehicleInfo vehicle = kvp.Value;

                                    if (string.IsNullOrEmpty(vehicle.Category))
                                    {
                                        continue;
                                    }

                                    if (vehicle.Category != currentCategory.Name)
                                    {
                                        continue;
                                    }

                                    totalCount++;

                                    if (deleteVehicles)
                                    {
                                        updatedCount++;

                                        DeleteResourceKvp(saveName);
                                    }
                                    else
                                    {
                                        vehicle.Category = "Uncategorized";

                                        if (StorageManager.SaveVehicleInfo(saveName, vehicle, true))
                                        {
                                            updatedCount++;
                                            Log($"Atualizado categoria para \"{saveName}\"");
                                        }
                                        else
                                        {
                                            Log($"Something went wrong quando updating categoria para \"{saveName}\"");
                                        }
                                    }
                                }
                            }

                            Notify.Success($"Seu salvo categoria has been excluird. {updatedCount}/{totalCount} vehicles {(deleteVehicles ? "deleted" : "updated")}.");
                            MenuController.CloseAllMenus();
                            UpdateSavedVehicleCategoriesMenu();
                            vehicleCategoryMenu.OpenMenu();
                        }
                        else
                        {
                            item.Label = "Tem certeza?";
                        }
                        break;

                    // Load saved vehicle menu
                    default:
                        if (item.ItemData is not KeyValuePair<string, VehicleInfo> vehicleInfo)
                        {
                            break;
                        }

                        List<string> categoryNames = GetAllCategoryNames();
                        List<MenuItem.Icon> categoryIcons = GetCategoryIcons(categoryNames);
                        int nameIndex = categoryNames.IndexOf(currentCategory.Name);

                        setCategoryBtn.ItemData = categoryIcons;
                        setCategoryBtn.ListItems = categoryNames;
                        setCategoryBtn.ListIndex = nameIndex == 1 ? 0 : nameIndex;
                        setCategoryBtn.RightIcon = categoryIcons[setCategoryBtn.ListIndex];

                        selectedVehicleMenu.MenuSubtitle = $"{vehicleInfo.Key.Substring(4)} ({vehicleInfo.Value.name})";
                        currentlySelectedVehicle = vehicleInfo;
                        MenuController.CloseAllMenus();
                        selectedVehicleMenu.OpenMenu();
                        MenuController.AddSubmenu(savedVehiclesCategoryMenu, selectedVehicleMenu);
                        break;
                }
            };

            // Change Category Icon
            savedVehiclesCategoryMenu.OnDynamicListItemSelect += (_, _, currentItem) =>
            {
                var iconNames = Enum.GetNames(typeof(MenuItem.Icon)).ToList();
                int iconIndex = iconNames.IndexOf(currentItem);

                currentCategory.Icon = (MenuItem.Icon)iconIndex;

                if (StorageManager.SaveJsonData("saved_veh_category_" + currentCategory.Name, JsonConvert.SerializeObject(currentCategory), true))
                {
                    Notify.Success($"Seu categoria icon been alterard para ~g~<C>{iconNames[iconIndex]}</C>~s~.");
                    UpdateSavedVehicleCategoriesMenu();
                }
                else
                {
                    Notify.Error("Something went wrong enquanto changing seu categoria icon.");
                }
            };

            var spawnVehicle = new MenuItem("Criar Veículo");
            var renameVehicle = new MenuItem("Renomear Veículo", "Renomear seu salvo veículo.");
            var replaceVehicle = new MenuItem("~r~Substituir Veículo", "Seu salvo veículo will ser substituído com o veículo você está atualmente sitting in. ~r~Aviso: this can NÃOT ser undone!");
            var deleteVehicle = new MenuItem("~r~Excluir Veículo", "~r~This will excluir seu salvo veículo. Aviso: this can NÃOT ser undone!");
            selectedVehicleMenu.AddMenuItem(spawnVehicle);
            selectedVehicleMenu.AddMenuItem(renameVehicle);
            selectedVehicleMenu.AddMenuItem(setCategoryBtn);
            selectedVehicleMenu.AddMenuItem(replaceVehicle);
            selectedVehicleMenu.AddMenuItem(deleteVehicle);

            selectedVehicleMenu.OnMenuOpen += (sender) =>
            {
                bool vehicleModelExists = IsModelInCdimage(currentlySelectedVehicle.Value.model);

                spawnVehicle.Enabled = vehicleModelExists;
                spawnVehicle.Description = vehicleModelExists ? "Criar this salvo veículo." : "This model não foi encontrado in o game arquivos. Most likely because this é um addon veículo e it's atualmente não streamed by o servidor.";

                spawnVehicle.Label = "(" + GetDisplayNameFromVehicleModel(currentlySelectedVehicle.Value.model).ToLower() + ")";
            };

            selectedVehicleMenu.OnMenuClose += (sender) =>
            {
                selectedVehicleMenu.RefreshIndex();
                deleteButtonPressedCount = 0;
                deleteVehicle.Label = "";
                replaceButtonPressedCount = 0;
                replaceVehicle.Label = "";
            };

            selectedVehicleMenu.OnItemSelect += async (sender, item, index) =>
            {
                if (item == spawnVehicle)
                {
                    if (MainMenu.VehicleSpawnerMenu != null)
                    {
                        await SpawnVehicle(currentlySelectedVehicle.Value.model, MainMenu.VehicleSpawnerMenu.SpawnInVehicle, MainMenu.VehicleSpawnerMenu.ReplaceVehicle, false, vehicleInfo: currentlySelectedVehicle.Value, saveName: currentlySelectedVehicle.Key.Substring(4));
                    }
                    else
                    {
                        await SpawnVehicle(currentlySelectedVehicle.Value.model, true, true, false, vehicleInfo: currentlySelectedVehicle.Value, saveName: currentlySelectedVehicle.Key.Substring(4));
                    }
                }
                else if (item == renameVehicle)
                {
                    var newName = await GetUserInput(windowTitle: "Digite um novo nome para este veículo.", maxInputLength: 30);
                    if (string.IsNullOrEmpty(newName))
                    {
                        Notify.Error(CommonErrors.InvalidInput);
                    }
                    else
                    {
                        if (StorageManager.SaveVehicleInfo("veh_" + newName, currentlySelectedVehicle.Value, false))
                        {
                            DeleteResourceKvp(currentlySelectedVehicle.Key);
                            while (!selectedVehicleMenu.Visible)
                            {
                                await BaseScript.Delay(0);
                            }
                            Notify.Success("Seu veículo has com sucesso been renomed.");
                            UpdateMenuAvailableCategories();
                            selectedVehicleMenu.GoBack();
                            currentlySelectedVehicle = new KeyValuePair<string, VehicleInfo>(); // clear the old info
                        }
                        else
                        {
                            Notify.Error("This nome é already in use ou something desconhecido falhou. Contact o servidor dono se you believe something é wrong.");
                        }
                    }
                }
                else if (item == replaceVehicle)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        if (replaceButtonPressedCount == 0)
                        {
                            replaceButtonPressedCount = 1;
                            item.Label = "Pressione novamente para confirmar.";
                            Notify.Alert("Tem certeza you want para replace este veículo? Pressione o botão novamente para confirmar.");
                        }
                        else
                        {
                            replaceButtonPressedCount = 0;
                            item.Label = "";
                            SaveVehicle(currentlySelectedVehicle.Key.Substring(4), currentlySelectedVehicle.Value.Category);
                            selectedVehicleMenu.CloseMenu();
                            Notify.Success("Seu salvo veículo has been substituído com seu veículo atual.");
                        }
                    }
                    else
                    {
                        Notify.Error("Você precisa ser in um veículo before você pode replace seu antigo veículo.");
                    }
                }
                else if (item == deleteVehicle)
                {
                    if (deleteButtonPressedCount == 0)
                    {
                        deleteButtonPressedCount = 1;
                        item.Label = "Pressione novamente para confirmar.";
                        Notify.Alert("Tem certeza you want para excluir este veículo? Pressione o botão novamente para confirmar.");
                    }
                    else
                    {
                        deleteButtonPressedCount = 0;
                        item.Label = "";
                        DeleteResourceKvp(currentlySelectedVehicle.Key);
                        UpdateMenuAvailableCategories();
                        selectedVehicleMenu.GoBack();
                        Notify.Success("Seu salvo veículo has been excluird.");
                    }
                }
                if (item != deleteVehicle) // if any other button is pressed, restore the delete vehicle button pressed count.
                {
                    deleteButtonPressedCount = 0;
                    deleteVehicle.Label = "";
                }
                if (item != replaceVehicle)
                {
                    replaceButtonPressedCount = 0;
                    replaceVehicle.Label = "";
                }
            };

            // Update category preview icon
            selectedVehicleMenu.OnListIndexChange += (_, listItem, _, newSelectionIndex, _) =>
            {
                if (listItem.ItemData is List<MenuItem.Icon> icons)
                {
                    listItem.RightIcon = icons[newSelectionIndex];
                }
            };

            // Update vehicle's category
            selectedVehicleMenu.OnListItemSelect += async (_, listItem, listIndex, _) =>
            {
                string name = listItem.ListItems[listIndex];

                if (name == "Create New")
                {
                    var newName = await GetUserInput(windowTitle: "Digite um categoria nome.", maxInputLength: 30);
                    if (string.IsNullOrEmpty(newName) || newName.ToLower() == "uncategorized" || newName.ToLower() == "create new")
                    {
                        Notify.Error(CommonErrors.InvalidInput);
                        return;
                    }
                    else
                    {
                        var description = await GetUserInput(windowTitle: "Digite um categoria description (optional).", maxInputLength: 120);
                        var newCategory = new SavedVehicleCategory
                        {
                            Name = newName,
                            Description = description
                        };

                        if (StorageManager.SaveJsonData("saved_veh_category_" + newName, JsonConvert.SerializeObject(newCategory), false))
                        {
                            Notify.Success($"Seu categoria (~g~<C>{newName}</C>~s~) has been salvo.");
                            Log($"Salvard Categoria {newName}.");
                            MenuController.CloseAllMenus();
                            UpdateSavedVehicleCategoriesMenu();
                            savedVehiclesCategoryMenu.OpenMenu();

                            currentCategory = newCategory;
                            name = newName;
                        }
                        else
                        {
                            Notify.Error($"Salvando falhou, most likely because this nome (~y~<C>{newName}</C>~s~) é already in use.");
                            return;
                        }
                    }
                }

                VehicleInfo vehicle = currentlySelectedVehicle.Value;

                vehicle.Category = name;

                if (StorageManager.SaveVehicleInfo(currentlySelectedVehicle.Key, vehicle, true))
                {
                    Notify.Success("Seu veículo foi salvo com sucesso.");
                }
                else
                {
                    Notify.Error("Seu veículo não foi possível ser salvo. Motivo desconhecido. :(");
                }

                MenuController.CloseAllMenus();
                UpdateSavedVehicleCategoriesMenu();
                vehicleCategoryMenu.OpenMenu();
            };

            unavailableVehiclesMenu.InstructionalButtons.Add(Control.FrontendDelete, "Excluir Veículo!");

            unavailableVehiclesMenu.ButtonPressHandlers.Add(new Menu.ButtonPressHandler(Control.FrontendDelete, Menu.ControlPressCheckType.JUST_RELEASED, new Action<Menu, Control>((m, c) =>
            {
                if (m.Size > 0)
                {
                    var index = m.CurrentIndex;
                    if (index < m.Size)
                    {
                        var item = m.GetMenuItems().Find(i => i.Index == index);
                        if (item != null && item.ItemData is KeyValuePair<string, VehicleInfo> sd)
                        {
                            if (item.Label == "~r~Tem certeza?")
                            {
                                Log("Undisponível salvo veículo excluird, data: " + JsonConvert.SerializeObject(sd));
                                DeleteResourceKvp(sd.Key);
                                unavailableVehiclesMenu.GoBack();
                                UpdateMenuAvailableCategories();
                            }
                            else
                            {
                                item.Label = "~r~Tem certeza?";
                            }
                        }
                        else
                        {
                            Notify.Error("Somehow este veículo não foi encontrado.");
                        }
                    }
                    else
                    {
                        Notify.Error("You somehow gerenciard para trigger deletion de um menu item that doesn't exist, how...?");
                    }
                }
                else
                {
                    Notify.Error("There estão currrently no undisponível veículos para excluir!");
                }
            }), true));

            void ResetAreYouSure()
            {
                foreach (var i in unavailableVehiclesMenu.GetMenuItems())
                {
                    if (i.ItemData is KeyValuePair<string, VehicleInfo> vd)
                    {
                        i.Label = $"({vd.Value.name})";
                    }
                }
            }
            unavailableVehiclesMenu.OnMenuClose += (sender) => ResetAreYouSure();
            unavailableVehiclesMenu.OnIndexChange += (sender, oldItem, newItem, oldIndex, newIndex) => ResetAreYouSure();

            #endregion
        }

        private void CreateTypeMenu()
        {
            savedVehicleTypeMenu = new("Veículos Salvos", "Selecionar de class ou custom categoria");

            var saveVehicle = new MenuItem("Salvar Veículo Atual", "Salvar o veículo você está atualmente sitting in.")
            {
                LeftIcon = MenuItem.Icon.CAR
            };
            var classButton = new MenuItem("Classe do Veículo", "Selecionared um salvo veículo by its class.")
            {
                Label = "→→→"
            };
            var categoryButton = new MenuItem("Categoria do Veículo", "Selecionared um salvo veículo by its custom categoria.")
            {
                Label = "→→→"
            };

            savedVehicleTypeMenu.AddMenuItem(saveVehicle);
            savedVehicleTypeMenu.AddMenuItem(classButton);
            savedVehicleTypeMenu.AddMenuItem(categoryButton);

            savedVehicleTypeMenu.OnItemSelect += (sender, item, index) =>
            {
                if (item == saveVehicle)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        SaveVehicle();
                    }
                    else
                    {
                        Notify.Error("Você está atualmente não in any veículo. Por favor enter um veículo before trying para salvar it.");
                    }
                }
                else if (item == classButton)
                {
                    UpdateMenuAvailableCategories();
                }
                else if (item == categoryButton)
                {
                    UpdateSavedVehicleCategoriesMenu();
                }
            };

            MenuController.BindMenuItem(savedVehicleTypeMenu, GetClassMenu(), classButton);
            MenuController.BindMenuItem(savedVehicleTypeMenu, vehicleCategoryMenu, categoryButton);
        }

        /// <summary>
        /// Updates the selected vehicle.
        /// </summary>
        /// <param name="selectedItem"></param>
        /// <returns>A bool, true if successfull, false if unsuccessfull</returns>
        private bool UpdateSelectedVehicleMenu(MenuItem selectedItem, Menu parentMenu = null)
        {
            if (selectedItem.ItemData is not KeyValuePair<string, VehicleInfo> vehicleInfo)
            {
                return false;
            }

            List<string> categoryNames = GetAllCategoryNames();
            List<MenuItem.Icon> categoryIcons = GetCategoryIcons(categoryNames);
            setCategoryBtn.ItemData = categoryIcons;
            setCategoryBtn.ListItems = categoryNames;
            setCategoryBtn.ListIndex = 0;
            setCategoryBtn.RightIcon = categoryIcons[0];
            selectedVehicleMenu.MenuSubtitle = $"{vehicleInfo.Key.Substring(4)} ({vehicleInfo.Value.name})";
            currentlySelectedVehicle = vehicleInfo;
            MenuController.CloseAllMenus();
            selectedVehicleMenu.OpenMenu();
            if (parentMenu != null)
            {
                MenuController.AddSubmenu(parentMenu, selectedVehicleMenu);
            }
            return true;
        }


        /// <summary>
        /// Updates the available vehicle category list.
        /// </summary>
        public void UpdateMenuAvailableCategories()
        {
            savedVehicles = GetSavedVehicles();

            for (var i = 0; i < GetClassMenu().Size - 1; i++)
            {
                if (savedVehicles.Any(a => GetVehicleClassFromName(a.Value.model) == i && IsModelInCdimage(a.Value.model)))
                {
                    GetClassMenu().GetMenuItems()[i].RightIcon = MenuItem.Icon.NONE;
                    GetClassMenu().GetMenuItems()[i].Label = "→→→";
                    GetClassMenu().GetMenuItems()[i].Enabled = true;
                    GetClassMenu().GetMenuItems()[i].Description = $"Todos salvo veículos de o {GetClassMenu().GetMenuItems()[i].Text} categoria.";
                }
                else
                {
                    GetClassMenu().GetMenuItems()[i].Label = "";
                    GetClassMenu().GetMenuItems()[i].RightIcon = MenuItem.Icon.LOCK;
                    GetClassMenu().GetMenuItems()[i].Enabled = false;
                    GetClassMenu().GetMenuItems()[i].Description = $"You do não have any salvo veículos that belong para o {GetClassMenu().GetMenuItems()[i].Text} categoria.";
                }
            }

            // Check if the items count will be changed. If there are less cars than there were before, one probably got deleted
            // so in that case we need to refresh the index of that menu just to be safe. If not, keep the index where it is for improved
            // usability of the menu.
            foreach (var m in subMenus)
            {
                var size = m.Size;
                var vclass = subMenus.IndexOf(m);

                var count = savedVehicles.Count(a => GetVehicleClassFromName(a.Value.model) == vclass);
                if (count < size)
                {
                    m.RefreshIndex();
                }
            }

            foreach (var m in subMenus)
            {
                // Clear items but don't reset the index because we can guarantee that the index won't be out of bounds.
                // this is the case because of the loop above where we reset the index if the items count changes.
                m.ClearMenuItems(true);
            }

            // Always clear this index because it's useless anyway and it's safer.
            unavailableVehiclesMenu.ClearMenuItems();

            foreach (var sv in savedVehicles)
            {
                if (IsModelInCdimage(sv.Value.model))
                {
                    var vclass = GetVehicleClassFromName(sv.Value.model);
                    var menu = subMenus[vclass];

                    var savedVehicleBtn = new MenuItem(sv.Key.Substring(4), $"Gerenciar this salvo veículo.")
                    {
                        Label = $"({sv.Value.name}) →→→",
                        ItemData = sv
                    };
                    menu.AddMenuItem(savedVehicleBtn);
                }
                else
                {
                    var missingVehItem = new MenuItem(sv.Key.Substring(4), "This model não foi encontrado in o game arquivos. Most likely because this é um addon veículo e it's atualmente não streamed by o servidor.")
                    {
                        Label = "(" + sv.Value.name + ")",
                        Enabled = false,
                        LeftIcon = MenuItem.Icon.LOCK,
                        ItemData = sv
                    };
                    //SetResourceKvp(sv.Key + "_tmp_dupe", JsonConvert.SerializeObject(sv.Value));
                    unavailableVehiclesMenu.AddMenuItem(missingVehItem);
                }
            }
            foreach (var m in subMenus)
            {
                m.SortMenuItems((A, B) =>
                {
                    return A.Text.ToLower().CompareTo(B.Text.ToLower());
                });
            }
        }

        /// <summary>
        /// Updates the saved vehicle categories menu.
        /// </summary>
        private void UpdateSavedVehicleCategoriesMenu()
        {
            savedVehicles = GetSavedVehicles();

            var categories = GetAllCategoryNames();

            vehicleCategoryMenu.ClearMenuItems();

            var createCategoryBtn = new MenuItem("Create Categoria", "Create um novo veículo categoria.")
            {
                Label = "→→→"
            };
            vehicleCategoryMenu.AddMenuItem(createCategoryBtn);

            var spacer = GetSpacerMenuItem("↓ Veículo Categories ↓");
            vehicleCategoryMenu.AddMenuItem(spacer);

            var uncategorized = new SavedVehicleCategory
            {
                Name = "Uncategorized",
                Description = "Todos salvo veículos that have não been assigned para um categoria."
            };
            var uncategorizedBtn = new MenuItem(uncategorized.Name, uncategorized.Description)
            {
                Label = "→→→",
                ItemData = uncategorized
            };
            vehicleCategoryMenu.AddMenuItem(uncategorizedBtn);
            MenuController.BindMenuItem(vehicleCategoryMenu, savedVehiclesCategoryMenu, uncategorizedBtn);

            // Remove "Create New" and "Uncategorized"
            categories.RemoveRange(0, 2);

            if (categories.Count > 0)
            {
                categories.Sort((a, b) => a.ToLower().CompareTo(b.ToLower()));
                foreach (var item in categories)
                {
                    SavedVehicleCategory category = StorageManager.GetSavedVehicleCategoryData("saved_veh_category_" + item);

                    var btn = new MenuItem(category.Name, category.Description)
                    {
                        Label = "→→→",
                        LeftIcon = category.Icon,
                        ItemData = category
                    };
                    vehicleCategoryMenu.AddMenuItem(btn);
                    MenuController.BindMenuItem(vehicleCategoryMenu, savedVehiclesCategoryMenu, btn);
                }
            }

            vehicleCategoryMenu.RefreshIndex();
        }

        private List<string> GetAllCategoryNames()
        {
            var categories = new List<string>();
            var handle = StartFindKvp("saved_veh_category_");
            while (true)
            {
                var foundCategory = FindKvp(handle);
                if (string.IsNullOrEmpty(foundCategory))
                {
                    break;
                }
                else
                {
                    categories.Add(foundCategory.Substring(19));
                }
            }
            EndFindKvp(handle);

            categories.Insert(0, "Create New");
            categories.Insert(1, "Uncategorized");

            return categories;
        }

        private List<MenuItem.Icon> GetCategoryIcons(List<string> categoryNames)
        {
            List<MenuItem.Icon> icons = new List<MenuItem.Icon> { };

            foreach (var name in categoryNames)
            {
                icons.Add(StorageManager.GetSavedVehicleCategoryData("saved_veh_category_" + name).Icon);
            }

            return icons;
        }

        /// <summary>
        /// Create the menu if it doesn't exist, and then returns it.
        /// </summary>
        /// <returns>The Menu</returns>
        public Menu GetClassMenu()
        {
            if (classMenu == null)
            {
                CreateClassMenu();
            }
            return classMenu;
        }

        public Menu GetTypeMenu()
        {
            if (savedVehicleTypeMenu == null)
            {
                CreateTypeMenu();
            }
            return savedVehicleTypeMenu;
        }

        public struct SavedVehicleCategory
        {
            public string Name;
            public string Description;
            public MenuItem.Icon Icon;
        }
    }
}
