using CitizenFX.Core;

using MenuAPI;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.ConfigManager;

namespace vMenuClient.menus
{
    public class Recording
    {
        // Variables
        private Menu menu;

        private void CreateMenu()
        {
            AddTextEntryByHash(0x86F10CE6, "Upload To Cfx.re Forum"); // Replace the "Upload To Social Club" button in gallery
            AddTextEntry("ERROR_UPLOAD", "Tem certeza you want para upload this photo para Cfx.re forum?"); // Replace the warning message text for uploading

            // Create the menu.
            menu = new Menu("Gravação", "Opções de Gravação");

            var takePic = new MenuItem("Take Photo", "Takes um photo e salvars it para o Pause Menu gtodosery.");
            var openPmGallery = new MenuItem("Abrir Gtodosery", "Abrirs o Pause Menu gtodosery.");
            var startRec = new MenuItem("Start Gravação", "Start um novo game gravação using GTA V's built in gravação.");
            var stopRec = new MenuItem("Stop Gravação", "Stop e salvar seu atual gravação.");
            var openEditor = new MenuItem("Rockstar Editor", "Abrir o rockstar editor, note you might want para quit o session primeiro before doing this para prevent some issues.");

            menu.AddMenuItem(takePic);
            menu.AddMenuItem(openPmGallery);
            menu.AddMenuItem(startRec);
            menu.AddMenuItem(stopRec);
            menu.AddMenuItem(openEditor);

            menu.OnItemSelect += async (sender, item, index) =>
            {
                if (item == startRec)
                {
                    if (IsRecording())
                    {
                        Notify.Alert("Você está already gravação um clip, você precisa stop gravação primeiro before você pode start gravação again!");
                    }
                    else
                    {
                        StartRecording(1);
                    }
                }
                else if (item == openPmGallery)
                {
                    ActivateFrontendMenu(Game.GenerateHashASCII("FE_MENU_VERSION_MP_PAUSE"), true, 3);
                }
                else if (item == takePic)
                {
                    BeginTakeHighQualityPhoto();
                    SaveHighQualityPhoto(-1);
                    FreeMemoryForHighQualityPhoto();
                }
                else if (item == stopRec)
                {
                    if (!IsRecording())
                    {
                        Notify.Alert("Você está atualmente NÃOT gravação um clip, você precisa start gravação primeiro before você pode stop e salvar um clip.");
                    }
                    else
                    {
                        StopRecordingAndSaveClip();
                    }
                }
                else if (item == openEditor)
                {
                    if (GetSettingsBool(Setting.vmenu_quit_session_in_rockstar_editor))
                    {
                        QuitSession();
                    }
                    ActivateRockstarEditor();
                    // wait for the editor to be closed again.
                    while (IsPauseMenuActive())
                    {
                        await BaseScript.Delay(0);
                    }
                    // then fade in the screen.
                    DoScreenFadeIn(1);
                    Notify.Alert("You esquerda seu previous session before entering o Rockstar Editaror. Restart o game para ser able para rejoin o servidor's main session.", true, true);
                }
            };

        }

        /// <summary>
        /// Create the menu if it doesn't exist, and then returns it.
        /// </summary>
        /// <returns>The Menu</returns>
        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }
    }
}
