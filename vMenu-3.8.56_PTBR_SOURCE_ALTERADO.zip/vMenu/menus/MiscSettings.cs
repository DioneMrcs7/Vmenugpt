﻿using System;
using System.Collections.Generic;
using System.Linq;

using CitizenFX.Core;

using MenuAPI;

using Newtonsoft.Json;

using vMenuClient.data;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.ConfigManager;
using static vMenuShared.PermissionsManager;

namespace vMenuClient.menus
{
    public class MiscSettings
    {
        // Variables
        private Menu menu;
        private Menu teleportOptionsMenu;
        private Menu developerToolsMenu;
        private Menu entitySpawnerMenu;

        public bool ShowSpeedoKmh { get; private set; } = UserDefaults.MiscSpeedKmh;
        public bool ShowSpeedoMph { get; private set; } = UserDefaults.MiscSpeedMph;
        public bool ShowCoordinates { get; private set; } = false;
        public bool HideHud { get; private set; } = false;
        public bool HideRadar { get; private set; } = false;
        public bool ShowLocation { get; private set; } = UserDefaults.MiscShowLocation;
        public bool DeathNotifications { get; private set; } = UserDefaults.MiscDeathNotifications;
        public bool JoinQuitNotifications { get; private set; } = UserDefaults.MiscJoinQuitNotifications;
        public bool LockCameraX { get; private set; } = false;
        public bool LockCameraY { get; private set; } = false;
        public bool MPPedPreviews { get; private set; } = UserDefaults.MPPedPreviews;
        public bool ShowLocationBlips { get; private set; } = UserDefaults.MiscLocationBlips;
        public bool ShowPlayerBlips { get; private set; } = UserDefaults.MiscShowPlayerBlips;
        public bool MiscShowOverheadNames { get; private set; } = UserDefaults.MiscShowOverheadNames;
        public bool ShowVehicleModelDimensions { get; private set; } = false;
        public bool ShowPedModelDimensions { get; private set; } = false;
        public bool ShowPropModelDimensions { get; private set; } = false;
        public bool ShowEntityHandles { get; private set; } = false;
        public bool ShowEntityModels { get; private set; } = false;
        public bool ShowEntityNetOwners { get; private set; } = false;
        public bool MiscRespawnDefaultCharacter { get; private set; } = UserDefaults.MiscRespawnDefaultCharacter;
        public bool RestorePlayerAppearance { get; private set; } = UserDefaults.MiscRestorePlayerAppearance;
        public bool RestorePlayerWeapons { get; private set; } = UserDefaults.MiscRestorePlayerWeapons;
        public bool DrawTimeOnScreen { get; internal set; } = UserDefaults.MiscShowTime;
        public bool MiscRightAlignMenu { get; private set; } = UserDefaults.MiscRightAlignMenu;
        private bool _disablePrivateMessages;
        public bool MiscDisablePrivateMessages
        {
            get => _disablePrivateMessages;
            set
            {
                _disablePrivateMessages = value;
                Game.Player.State.Set("vmenu_pms_disabled", value, true);
            }
        }
        public bool MiscDisableControllerSupport { get; private set; } = UserDefaults.MiscDisableControllerSupport;

        internal bool TimecycleEnabled { get; private set; } = false;
        internal int LastTimeCycleModifierIndex { get; private set; } = UserDefaults.MiscLastTimeCycleModifierIndex;
        internal int LastTimeCycleModifierStrength { get; private set; } = UserDefaults.MiscLastTimeCycleModifierStrength;


        // keybind states
        public bool KbTpToWaypoint { get; private set; } = UserDefaults.KbTpToWaypoint;
        public int KbTpToWaypointKey { get; } = vMenuShared.ConfigManager.GetSettingsInt(vMenuShared.ConfigManager.Setting.vmenu_teleport_to_wp_keybind_key) != -1
            ? vMenuShared.ConfigManager.GetSettingsInt(vMenuShared.ConfigManager.Setting.vmenu_teleport_to_wp_keybind_key)
            : 168; // 168 (F7 by default)
        public bool KbDriftMode { get; private set; } = UserDefaults.KbDriftMode;
        public bool KbRecordKeys { get; private set; } = UserDefaults.KbRecordKeys;
        public bool KbRadarKeys { get; private set; } = UserDefaults.KbRadarKeys;
        public bool KbPointKeys { get; private set; } = UserDefaults.KbPointKeys;

        internal static List<vMenuShared.ConfigManager.TeleportLocation> TpLocations = new();

        public MiscSettings()
        {
            // Sets statebag when resource starts
            MiscDisablePrivateMessages = UserDefaults.MiscDisablePrivateMessages;
        }

        /// <summary>
        /// Creates the menu.
        /// </summary>
        private void CreateMenu()
        {
            MenuController.MenuAlignment = MiscRightAlignMenu ? MenuController.MenuAlignmentOption.Right : MenuController.MenuAlignmentOption.Left;
            if (MenuController.MenuAlignment != (MiscRightAlignMenu ? MenuController.MenuAlignmentOption.Right : MenuController.MenuAlignmentOption.Left))
            {
                Notify.Error(CommonErrors.RightAlignedNotSupported);

                // (re)set the default to left just in case so they don't get this error again in the future.
                MenuController.MenuAlignment = MenuController.MenuAlignmentOption.Left;
                MiscRightAlignMenu = false;
                UserDefaults.MiscRightAlignMenu = false;
            }

            // Create the menu.
            menu = new Menu(Game.Player.Name, "Outras Configurações");
            teleportOptionsMenu = new Menu(Game.Player.Name, "Opções de Teleporte");
            developerToolsMenu = new Menu(Game.Player.Name, "Development Tools");
            entitySpawnerMenu = new Menu(Game.Player.Name, "Gerador de Entidades");

            // teleport menu
            var teleportMenu = new Menu(Game.Player.Name, "Locais de Teleporte");
            var teleportMenuBtn = new MenuItem("Locais de Teleporte", "Teleport para pre-configured localizaçãos, adicionado por o servidor dono.");
            MenuController.AddSubmenu(menu, teleportMenu);
            MenuController.BindMenuItem(menu, teleportMenu, teleportMenuBtn);

            // keybind settings menu
            var keybindMenu = new Menu(Game.Player.Name, "Configurações de Teclas");
            var keybindMenuBtn = new MenuItem("Configurações de Teclas", "Ative ou desative keybinds para alguns opções.");
            MenuController.AddSubmenu(menu, keybindMenu);
            MenuController.BindMenuItem(menu, keybindMenu, keybindMenuBtn);

            // keybind settings menu items
            var kbTpToWaypoint = new MenuCheckboxItem("Teleportar até o Marcador", "Teleport para seu marcador quando pressioneing o keybind. por padrão, isto keybind é definir para ~r~F7~s~, servidor donos estão able para alterar isto comoever so ask eles se você não know qual isso é.", KbTpToWaypoint);
            var kbDriftMode = new MenuCheckboxItem("Drift Mode", "Faz com que seu veículo tem almaioria no traction enquanto hantigoing esquerda shift em keyboard, ou X em controlarler.", KbDriftMode);
            var kbRecordKeys = new MenuCheckboxItem("Controles de Gravação", "Ativa ou desativa o gravação (gameplay gravação para o Rockstar edissoor) hotkeys em both keyboard e controlarler.", KbRecordKeys);
            var kbRadarKeys = new MenuCheckboxItem("Minimap Controls", "pressione o Multijogador Info (z em keyboard, baixo arrow em controlarler) key para swissoch between expanded radar e normal radar.", KbRadarKeys);
            var kbPointKeysCheckbox = new MenuCheckboxItem("Finger Point Controls", "Ativars o finger point alternar key. O padrão QWERTY keyboard mapaping para isto é 'B', ou para controlarler quickly double tap o direissoa analog stick.", KbPointKeys);
            var backBtn = new MenuItem("Voltar");

            // Create the menu items.
            var rightAlignMenu = new MenuCheckboxItem("Alinhar Menu à Direissoa", "se você deseja vMenu para appear em o esquerda lado de seu tela, desativar esta opção. Esta opção irá ser salvo imediatamente. você não precisa para click salvar preferences.", MiscRightAlignMenu);
            var disablePms = new MenuCheckboxItem("Desativar Privada Mensagems", "Prevent outros de sending você um privada mensagem via o Jogadores Online menu. isto also prevents você de sending mensagems para outro jogadores.", MiscDisablePrivateMessages);
            var disableControllerKey = new MenuCheckboxItem("Desativar Controller Support", "isto desativars o controlarler menu alternar key. Isto NÃO desativar o navigation botãos.", MiscDisableControllerSupport);
            var speedKmh = new MenuCheckboxItem("Mostrar Velocidade em KM/H", "Mostrar um velocidadeometer em seu tela indicating seu velocidade em KM/h.", ShowSpeedoKmh);
            var speedMph = new MenuCheckboxItem("Mostrar Velocidade em MPH", "Mostrar um velocidadeometer em seu tela indicating seu velocidade em MPH.", ShowSpeedoMph);
            var coords = new MenuCheckboxItem("Mostrar Coordenadas", "Mostrar seu atual coordenadas em o top de seu tela.", ShowCoordinates);
            var hideRadar = new MenuCheckboxItem("Hide Radar", "Ocultar o radar/minimapa.", HideRadar);
            var hideHud = new MenuCheckboxItem("Hide Hud", "Ocultar todos hud elements.", HideHud);
            var showLocation = new MenuCheckboxItem("Exibir Localização", "Mostrars seu localização atual e heading, como well como o nearest cross estrada. Similar like PLD. ~r~Aviso: isto feature (can) receber(s) cima para -4.6 FPS quando running em 60 Hz.", ShowLocation) { LeftIcon = MenuItem.Icon.WARNING };
            var drawTime = new MenuCheckboxItem("Mostrar Horário na Tela", "Mostrars você o atual horário em tela.", DrawTimeOnScreen);
            var saveSettings = new MenuItem("Salvar Configurações Pessoais", "Salvar seu configurações atuais. Todos salvando é done em o client lado, se você re-insttodos janelas você irá lose seu configurações. Configurações estão shared across todos servidors usando vMenu.")
            {
                RightIcon = MenuItem.Icon.TICK
            };
            var joinQuitNotifs = new MenuCheckboxItem("Join / Quisso Notifications", "Receive notifications quando algunsone joins ou sairs o servidor.", JoinQuitNotifications);
            var deathNotifs = new MenuCheckboxItem("Death Notifications", "Receive notifications quando algunsone dies ou gets killed.", DeathNotifications);
            var nightVision = new MenuCheckboxItem("Ativar/Desativar Visão Noturna", "Ative ou desative night vision.", false);
            var thermalVision = new MenuCheckboxItem("Ativar/Desativar Visão Térmica", "Ative ou desative thermal vision.", false);
            var vehModelDimensions = new MenuCheckboxItem("Mostrar Dimensões do Veículo", "Draws o model outlines para every veículo that's atualmente fechar para você.", ShowVehicleModelDimensions);
            var propModelDimensions = new MenuCheckboxItem("Mostrar Dimensões dos Objetos", "Draws o model outlines para every prop that's atualmente fechar para você.", ShowPropModelDimensions);
            var pedModelDimensions = new MenuCheckboxItem("Mostrar Dimensões do Ped", "Draws o model outlines para every ped that's atualmente fechar para você.", ShowPedModelDimensions);
            var showEntityHandles = new MenuCheckboxItem("Mostrar IDs das Entidades", "Draws o o entidade handles para todos fechar entidades (você deve ativar o outline functions acima para isto para funcionar).", ShowEntityHandles);
            var showEntityModels = new MenuCheckboxItem("Mostrar Modelos das Entidades", "Draws o o entidade models para todos fechar entidades (você deve ativar o outline functions acima para isto para funcionar).", ShowEntityModels);
            var showEntityNetOwners = new MenuCheckboxItem("Mostrar Donos das Entidades", "Draws o o entidade net dono para todos fechar entidades (você deve ativar o outline functions acima para isto para funcionar).", ShowEntityNetOwners);
            var dimensionsDistanceSlider = new MenuSliderItem("Mostrar Raio das Dimensões", "Mostrar entidade model/handle/dimension draw alcance.", 0, 20, 20, false);

            var clearArea = new MenuItem("Limpar Área", "Limpos o area ao redor seu jogador (100 metros). Dano, sujeira, peds, props, veículos, etc. Everything gets limpas cima, reparado e redefinir para o padrão mundo state.");
            var lockCamX = new MenuCheckboxItem("Lock Camera Horizontal Rotation", "Locks seu câmera horizontal rotation. Could ser useful em helicopters I guess.", false);
            var lockCamY = new MenuCheckboxItem("Lock Camera Vertical Rotation", "Locks seu câmera vertical rotation. Could ser useful em helicopters I guess.", false);

            var mpPedPreview = new MenuCheckboxItem("Prévia 3D do Ped MP", "Mostrars um 3D Ped preview quando viewing salvo MP Peds.", MPPedPreviews);

            // Entity spawner
            var spawnNewEntity = new MenuItem("Criar Novo Entidade", "Criars entidade em o mundo e lets você definir issos posissoion e rotation");
            var confirmEntityPosition = new MenuItem("Confirm Entissoy Posissoion", "Stops placing entidade e definirs isso em isso localização atual.");
            var cancelEntity = new MenuItem("Cancelar", "Excluirs atual entidade e cancelars issos localment");
            var confirmAndDuplicate = new MenuItem("Confirm Entissoy Posissoion e Duplicate", "Stops placing entidade e definirs isso em isso localização atual e creates novo one para local.");

            var connectionSubmenu = new Menu(Game.Player.Name, "Opções de Conexão");
            var connectionSubmenuBtn = new MenuItem("Opções de Conexão", "Servidor connection/game quisso opções.");

            var quitSession = new MenuItem("Quisso Session", "Leaves você connected para o servidor, but quissos o rede session. ~r~Can não ser usado quando você está o host.");
            var rejoinSession = new MenuItem("Re-join Session", "isto may não funcionar em todos cases, but você pode try para use isto se você deseja para re-join o anterior session depois clicking 'Quisso Session'.");
            var quitGame = new MenuItem("Quisso Game", "Exissos o game depois 5 segundos.");
            var disconnectFromServer = new MenuItem("Disconnect de Servidor", "Disconnects você de o servidor e regirars você para o servidorlista. ~r~isto feature é não recomendado, quisso o game completely instead e reiniciar isso para um better experience.");
            connectionSubmenu.AddMenuItem(quitSession);
            connectionSubmenu.AddMenuItem(rejoinSession);
            connectionSubmenu.AddMenuItem(quitGame);
            connectionSubmenu.AddMenuItem(disconnectFromServer);

            var enableTimeCycle = new MenuCheckboxItem("Ativar Horáriocycle Modifier", "Ative ou desative o horáriocycle modifier de o lista abaixo.", TimecycleEnabled);
            var timeCycleModifiersListData = TimeCycles.Timecycles.ToList();
            for (var i = 0; i < timeCycleModifiersListData.Count; i++)
            {
                timeCycleModifiersListData[i] += $" ({i + 1}/{timeCycleModifiersListData.Count})";
            }
            var timeCycles = new MenuListItem("TM", timeCycleModifiersListData, MathUtil.Clamp(LastTimeCycleModifierIndex, 0, Math.Max(0, timeCycleModifiersListData.Count - 1)), "Selecione um horáriocycle modifier e ativar o checkbox acima.");
            var timeCycleIntensity = new MenuSliderItem("Timecycle Modifier Intensissoy", "Definir o horáriocycle modifier intensissoy.", 0, 20, LastTimeCycleModifierStrength, true);

            var locationBlips = new MenuCheckboxItem("Localização Blips", "Mostrars blips em o mapa para alguns common localizaçãos.", ShowLocationBlips);
            var playerBlips = new MenuCheckboxItem("Mostrar Blips dos Jogadores", "Mostrars blips em o mapa para todos jogadores. ~y~Nota para quando o servidor é usando OneSync Infinissoy: isto won't funcionar para jogadores that estão too far away.", ShowPlayerBlips);
            var playerNames = new MenuCheckboxItem("Mostrar Nomes dos Jogadores", "Ativa ou desativa jogador overhead nomes.", MiscShowOverheadNames);
            var respawnDefaultCharacter = new MenuCheckboxItem("Recriar como Padrão MP Character", "se você ativar isto, então você irá (re)criar como seu padrão salvo MP character. Nota o servidor dono can globtodosy desativar esta opção. para definir seu padrão character, ir para one de seu salvo MP Characters e click o 'Definir como Personagem Padrão' botão.", MiscRespawnDefaultCharacter);
            var restorePlayerAppearance = new MenuCheckboxItem("Restaurar Aparência do Jogador", "Restaurar seu jogador's pele whenever você recriar depois sendo morto. Re-joining um servidor irá não restaurar seu anterior pele.", RestorePlayerAppearance);
            var restorePlayerWeapons = new MenuCheckboxItem("Restaurar Armas do Jogador", "Restaurar sucomo umrmas whenever você recriar depois sendo morto. Re-joining um servidor irá não restaurar seu anterior armas.", RestorePlayerWeapons);

            MenuController.AddSubmenu(menu, connectionSubmenu);
            MenuController.BindMenuItem(menu, connectionSubmenu, connectionSubmenuBtn);

            keybindMenu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == kbTpToWaypoint)
                {
                    KbTpToWaypoint = _checked;
                }
                else if (item == kbDriftMode)
                {
                    KbDriftMode = _checked;
                }
                else if (item == kbRecordKeys)
                {
                    KbRecordKeys = _checked;
                }
                else if (item == kbRadarKeys)
                {
                    KbRadarKeys = _checked;
                }
                else if (item == kbPointKeysCheckbox)
                {
                    KbPointKeys = _checked;
                }
            };
            keybindMenu.OnItemSelect += (sender, item, index) =>
            {
                if (item == backBtn)
                {
                    keybindMenu.GoBack();
                }
            };

            connectionSubmenu.OnItemSelect += (sender, item, index) =>
            {
                if (item == quitGame)
                {
                    CommonFunctions.QuitGame();
                }
                else if (item == quitSession)
                {
                    if (NetworkIsSessionActive())
                    {
                        if (NetworkIsHost())
                        {
                            Notify.Error("Sorry, você não pode sair o session quando você está o host. isto would prevent outro jogadores de joining/staying em o servidor.");
                        }
                        else
                        {
                            QuitSession();
                        }
                    }
                    else
                    {
                        Notify.Error("Você está atualmente não em umny session.");
                    }
                }
                else if (item == rejoinSession)
                {
                    if (NetworkIsSessionActive())
                    {
                        Notify.Error("Você está já connected para um session.");
                    }
                    else
                    {
                        Notify.Info("Attempting para re-join o session.");
                        NetworkSessionHost(-1, 32, false);
                    }
                }
                else if (item == disconnectFromServer)
                {

                    RegisterCommand("disconnect", new Action<dynamic, dynamic, dynamic>((a, b, c) => { }), false);
                    ExecuteCommand("disconnect");
                }
            };

            // Teleportation options
            if (IsAllowed(Permission.MSTeleportToWp) || IsAllowed(Permission.MSTeleportLocations) || IsAllowed(Permission.MSTeleportToCoord))
            {
                var teleportOptionsMenuBtn = new MenuItem("Opções de Teleporte", "Various teleport opções.") { Label = "→→→" };
                menu.AddMenuItem(teleportOptionsMenuBtn);
                MenuController.BindMenuItem(menu, teleportOptionsMenu, teleportOptionsMenuBtn);

                var tptowp = new MenuItem("Teleportar até o Marcador", "Teleport para o marcador em seu mapa.");
                var tpToCoord = new MenuItem("Teleportar para Coordenadas", "Digissoe x, y, z coordenadas e você irá ser teleported para that localização.");
                var saveLocationBtn = new MenuItem("Salvar Local de Teleporte", "Adds seu localização atual para o teleport localizaçãos menu e salvars isso em o servidor.");
                teleportOptionsMenu.OnItemSelect += async (sender, item, index) =>
                {
                    // Teleport to waypoint.
                    if (item == tptowp)
                    {
                        TeleportToWp();
                    }
                    else if (item == tpToCoord)
                    {
                        var x = await GetUserInput("Digissoe X coordinate.");
                        if (string.IsNullOrEmpty(x))
                        {
                            Notify.Error(CommonErrors.InvalidInput);
                            return;
                        }
                        var y = await GetUserInput("Digissoe Y coordinate.");
                        if (string.IsNullOrEmpty(y))
                        {
                            Notify.Error(CommonErrors.InvalidInput);
                            return;
                        }
                        var z = await GetUserInput("Digissoe Z coordinate.");
                        if (string.IsNullOrEmpty(z))
                        {
                            Notify.Error(CommonErrors.InvalidInput);
                            return;
                        }


                        if (!float.TryParse(x, out var posX))
                        {
                            if (int.TryParse(x, out var intX))
                            {
                                posX = intX;
                            }
                            else
                            {
                                Notify.Error("você did não entrar um válido X coordinate.");
                                return;
                            }
                        }
                        if (!float.TryParse(y, out var posY))
                        {
                            if (int.TryParse(y, out var intY))
                            {
                                posY = intY;
                            }
                            else
                            {
                                Notify.Error("você did não entrar um válido Y coordinate.");
                                return;
                            }
                        }
                        if (!float.TryParse(z, out var posZ))
                        {
                            if (int.TryParse(z, out var intZ))
                            {
                                posZ = intZ;
                            }
                            else
                            {
                                Notify.Error("você did não entrar um válido Z coordinate.");
                                return;
                            }
                        }

                        await TeleportToCoords(new Vector3(posX, posY, posZ), true);
                    }
                    else if (item == saveLocationBtn)
                    {
                        SavePlayerLocationToLocationsFile();
                    }
                };

                if (IsAllowed(Permission.MSTeleportToWp))
                {
                    teleportOptionsMenu.AddMenuItem(tptowp);
                    keybindMenu.AddMenuItem(kbTpToWaypoint);
                }
                if (IsAllowed(Permission.MSTeleportToCoord))
                {
                    teleportOptionsMenu.AddMenuItem(tpToCoord);
                }
                if (IsAllowed(Permission.MSTeleportLocations))
                {
                    teleportOptionsMenu.AddMenuItem(teleportMenuBtn);

                    MenuController.AddSubmenu(teleportOptionsMenu, teleportMenu);
                    MenuController.BindMenuItem(teleportOptionsMenu, teleportMenu, teleportMenuBtn);
                    teleportMenuBtn.Label = "→→→";

                    teleportMenu.OnMenuOpen += (sender) =>
                    {
                        if (teleportMenu.Size != TpLocations.Count())
                        {
                            teleportMenu.ClearMenuItems();
                            foreach (var location in TpLocations)
                            {
                                var x = Math.Round(location.coordinates.X, 2);
                                var y = Math.Round(location.coordinates.Y, 2);
                                var z = Math.Round(location.coordinates.Z, 2);
                                var heading = Math.Round(location.heading, 2);
                                var tpBtn = new MenuItem(location.name, $"Teleport para ~y~{localização.nome}~n~~s~x: ~y~{x}~n~~s~y: ~y~{y}~n~~s~z: ~y~{z}~n~~s~heading: ~y~{heading}") { ItemData = location };
                                teleportMenu.AddMenuItem(tpBtn);
                            }
                        }
                    };

                    teleportMenu.OnItemSelect += async (sender, item, index) =>
                    {
                        if (item.ItemData is vMenuShared.ConfigManager.TeleportLocation tl)
                        {
                            await TeleportToCoords(tl.coordinates, true);
                            SetEntityHeading(Game.PlayerPed.Handle, tl.heading);
                            SetGameplayCamRelativeHeading(0f);
                        }
                    };

                    if (IsAllowed(Permission.MSTeleportSaveLocation))
                    {
                        teleportOptionsMenu.AddMenuItem(saveLocationBtn);
                    }
                }

            }

            #region dev tools menu

            var devToolsBtn = new MenuItem("Developer Tools", "Various development/debug tools.") { Label = "→→→" };
            menu.AddMenuItem(devToolsBtn);
            MenuController.AddSubmenu(menu, developerToolsMenu);
            MenuController.BindMenuItem(menu, developerToolsMenu, devToolsBtn);

            // clear area and coordinates
            if (IsAllowed(Permission.MSClearArea))
            {
                developerToolsMenu.AddMenuItem(clearArea);
            }
            if (IsAllowed(Permission.MSShowCoordinates))
            {
                developerToolsMenu.AddMenuItem(coords);
            }

            // model outlines
            if ((!vMenuShared.ConfigManager.GetSettingsBool(vMenuShared.ConfigManager.Setting.vmenu_disable_entity_outlines_tool)) && (IsAllowed(Permission.MSDevTools)))
            {
                developerToolsMenu.AddMenuItem(vehModelDimensions);
                developerToolsMenu.AddMenuItem(propModelDimensions);
                developerToolsMenu.AddMenuItem(pedModelDimensions);
                developerToolsMenu.AddMenuItem(showEntityHandles);
                developerToolsMenu.AddMenuItem(showEntityModels);
                developerToolsMenu.AddMenuItem(showEntityNetOwners);
                developerToolsMenu.AddMenuItem(dimensionsDistanceSlider);
            }


            // timecycle modifiers
            developerToolsMenu.AddMenuItem(timeCycles);
            developerToolsMenu.AddMenuItem(enableTimeCycle);
            developerToolsMenu.AddMenuItem(timeCycleIntensity);

            developerToolsMenu.OnSliderPositionChange += (sender, item, oldPos, newPos, itemIndex) =>
            {
                if (item == timeCycleIntensity)
                {
                    ClearTimecycleModifier();
                    if (TimecycleEnabled)
                    {
                        SetTimecycleModifier(TimeCycles.Timecycles[timeCycles.ListIndex]);
                        var intensity = newPos / 20f;
                        SetTimecycleModifierStrength(intensity);
                    }
                    UserDefaults.MiscLastTimeCycleModifierIndex = timeCycles.ListIndex;
                    UserDefaults.MiscLastTimeCycleModifierStrength = timeCycleIntensity.Position;
                }
                else if (item == dimensionsDistanceSlider)
                {
                    FunctionsController.entityRange = newPos / 20f * 2000f; // max radius = 2000f;
                }
            };

            developerToolsMenu.OnListIndexChange += (sender, item, oldIndex, newIndex, itemIndex) =>
            {
                if (item == timeCycles)
                {
                    ClearTimecycleModifier();
                    if (TimecycleEnabled)
                    {
                        SetTimecycleModifier(TimeCycles.Timecycles[timeCycles.ListIndex]);
                        var intensity = timeCycleIntensity.Position / 20f;
                        SetTimecycleModifierStrength(intensity);
                    }
                    UserDefaults.MiscLastTimeCycleModifierIndex = timeCycles.ListIndex;
                    UserDefaults.MiscLastTimeCycleModifierStrength = timeCycleIntensity.Position;
                }
            };

            developerToolsMenu.OnItemSelect += (sender, item, index) =>
            {
                if (item == clearArea)
                {
                    BaseScript.TriggerServerEvent("vMenu:ClearArea");
                }
            };

            developerToolsMenu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == vehModelDimensions)
                {
                    ShowVehicleModelDimensions = _checked;
                }
                else if (item == propModelDimensions)
                {
                    ShowPropModelDimensions = _checked;
                }
                else if (item == pedModelDimensions)
                {
                    ShowPedModelDimensions = _checked;
                }
                else if (item == showEntityHandles)
                {
                    ShowEntityHandles = _checked;
                }
                else if (item == showEntityModels)
                {
                    ShowEntityModels = _checked;
                }
                else if (item == showEntityNetOwners)
                {
                    ShowEntityNetOwners = _checked;
                }
                else if (item == enableTimeCycle)
                {
                    TimecycleEnabled = _checked;
                    ClearTimecycleModifier();
                    if (TimecycleEnabled)
                    {
                        SetTimecycleModifier(TimeCycles.Timecycles[timeCycles.ListIndex]);
                        var intensity = timeCycleIntensity.Position / 20f;
                        SetTimecycleModifierStrength(intensity);
                    }
                }
                else if (item == coords)
                {
                    ShowCoordinates = _checked;
                }
            };

            if (IsAllowed(Permission.MSEntitySpawner))
            {
                var entSpawnerMenuBtn = new MenuItem("Gerador de Entidades", "Criar e move entidades") { Label = "→→→" };
                developerToolsMenu.AddMenuItem(entSpawnerMenuBtn);
                MenuController.BindMenuItem(developerToolsMenu, entitySpawnerMenu, entSpawnerMenuBtn);

                entitySpawnerMenu.AddMenuItem(spawnNewEntity);
                entitySpawnerMenu.AddMenuItem(confirmEntityPosition);
                entitySpawnerMenu.AddMenuItem(confirmAndDuplicate);
                entitySpawnerMenu.AddMenuItem(cancelEntity);

                entitySpawnerMenu.OnItemSelect += async (sender, item, index) =>
                {
                    if (item == spawnNewEntity)
                    {
                        if (EntitySpawner.CurrentEntity != null || EntitySpawner.Active)
                        {
                            Notify.Error("Você está já placing one entidade, definir issos localização ou cancelar e tente novamente!");
                            return;
                        }

                        var result = await GetUserInput(windowTitle: "Digissoe model nome");

                        if (string.IsNullOrEmpty(result))
                        {
                            Notify.Error(CommonErrors.InvalidInput);
                        }

                        EntitySpawner.SpawnEntity(result, Game.PlayerPed.Position);
                    }
                    else if (item == confirmEntityPosition || item == confirmAndDuplicate)
                    {
                        if (EntitySpawner.CurrentEntity != null)
                        {
                            EntitySpawner.FinishPlacement(item == confirmAndDuplicate);
                        }
                        else
                        {
                            Notify.Error("No entissoy para confirm posissoion para!");
                        }
                    }
                    else if (item == cancelEntity)
                    {
                        if (EntitySpawner.CurrentEntity != null)
                        {
                            EntitySpawner.CurrentEntity.Delete();
                        }
                        else
                        {
                            Notify.Error("No entissoy para cancel!");
                        }
                    }
                };
            }

            #endregion


            // Keybind options
            if (IsAllowed(Permission.MSDriftMode))
            {
                keybindMenu.AddMenuItem(kbDriftMode);
            }
            // always allowed keybind menu options
            keybindMenu.AddMenuItem(kbRecordKeys);
            keybindMenu.AddMenuItem(kbRadarKeys);
            keybindMenu.AddMenuItem(kbPointKeysCheckbox);
            keybindMenu.AddMenuItem(backBtn);

            // Always allowed
            menu.AddMenuItem(rightAlignMenu);
            menu.AddMenuItem(disablePms);
            menu.AddMenuItem(disableControllerKey);
            menu.AddMenuItem(speedKmh);
            menu.AddMenuItem(speedMph);
            menu.AddMenuItem(keybindMenuBtn);
            keybindMenuBtn.Label = "→→→";
            if (IsAllowed(Permission.MSConnectionMenu))
            {
                menu.AddMenuItem(connectionSubmenuBtn);
                connectionSubmenuBtn.Label = "→→→";
            }
            if (IsAllowed(Permission.MSShowLocation))
            {
                menu.AddMenuItem(showLocation);
            }
            menu.AddMenuItem(drawTime); // always allowed
            if (IsAllowed(Permission.MSJoinQuitNotifs))
            {
                menu.AddMenuItem(joinQuitNotifs);
            }
            if (IsAllowed(Permission.MSDeathNotifs))
            {
                menu.AddMenuItem(deathNotifs);
            }
            if (IsAllowed(Permission.MSNightVision))
            {
                menu.AddMenuItem(nightVision);
            }
            if (IsAllowed(Permission.MSThermalVision))
            {
                menu.AddMenuItem(thermalVision);
            }
            if (IsAllowed(Permission.MSLocationBlips))
            {
                menu.AddMenuItem(locationBlips);
                ToggleBlips(ShowLocationBlips);
            }
            if (IsAllowed(Permission.MSPlayerBlips))
            {
                menu.AddMenuItem(playerBlips);
            }
            if (IsAllowed(Permission.MSOverheadNames))
            {
                menu.AddMenuItem(playerNames);
            }
            // always allowed, it just won't do anything if the server owner disabled the feature, but players can still toggle it.
            menu.AddMenuItem(respawnDefaultCharacter);
            if (IsAllowed(Permission.MSRestoreAppearance))
            {
                menu.AddMenuItem(restorePlayerAppearance);
            }
            if (IsAllowed(Permission.MSRestoreWeapons))
            {
                menu.AddMenuItem(restorePlayerWeapons);
            }

            // Always allowed
            menu.AddMenuItem(hideRadar);
            menu.AddMenuItem(hideHud);
            menu.AddMenuItem(lockCamX);
            menu.AddMenuItem(lockCamY);

            // If disabled at a server level, don't show the option to players
            if (GetSettingsBool(Setting.vmenu_mp_ped_preview))
            {
                menu.AddMenuItem(mpPedPreview);
            }

            menu.AddMenuItem(saveSettings);

            // Handle checkbox changes.
            menu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (item == rightAlignMenu)
                {

                    MenuController.MenuAlignment = _checked ? MenuController.MenuAlignmentOption.Right : MenuController.MenuAlignmentOption.Left;
                    MiscRightAlignMenu = _checked;
                    UserDefaults.MiscRightAlignMenu = MiscRightAlignMenu;

                    if (MenuController.MenuAlignment != (_checked ? MenuController.MenuAlignmentOption.Right : MenuController.MenuAlignmentOption.Left))
                    {
                        Notify.Error(CommonErrors.RightAlignedNotSupported);
                        // (re)set the default to left just in case so they don't get this error again in the future.
                        MenuController.MenuAlignment = MenuController.MenuAlignmentOption.Left;
                        MiscRightAlignMenu = false;
                        UserDefaults.MiscRightAlignMenu = false;
                    }

                }
                else if (item == disablePms)
                {
                    MiscDisablePrivateMessages = _checked;
                }
                else if (item == disableControllerKey)
                {
                    MiscDisableControllerSupport = _checked;
                    MenuController.EnableMenuToggleKeyOnController = !_checked;
                }
                else if (item == speedKmh)
                {
                    ShowSpeedoKmh = _checked;
                }
                else if (item == speedMph)
                {
                    ShowSpeedoMph = _checked;
                }
                else if (item == hideHud)
                {
                    HideHud = _checked;
                    DisplayHud(!_checked);
                }
                else if (item == hideRadar)
                {
                    HideRadar = _checked;
                    if (!_checked)
                    {
                        DisplayRadar(true);
                    }
                }
                else if (item == showLocation)
                {
                    ShowLocation = _checked;
                }
                else if (item == drawTime)
                {
                    DrawTimeOnScreen = _checked;
                }
                else if (item == deathNotifs)
                {
                    DeathNotifications = _checked;
                }
                else if (item == joinQuitNotifs)
                {
                    JoinQuitNotifications = _checked;
                }
                else if (item == nightVision)
                {
                    SetNightvision(_checked);
                }
                else if (item == thermalVision)
                {
                    SetSeethrough(_checked);
                }
                else if (item == lockCamX)
                {
                    LockCameraX = _checked;
                }
                else if (item == lockCamY)
                {
                    LockCameraY = _checked;
                }
                else if (item == mpPedPreview)
                {
                    MPPedPreviews = _checked;
                }
                else if (item == locationBlips)
                {
                    ToggleBlips(_checked);
                    ShowLocationBlips = _checked;
                }
                else if (item == playerBlips)
                {
                    ShowPlayerBlips = _checked;
                }
                else if (item == playerNames)
                {
                    MiscShowOverheadNames = _checked;
                }
                else if (item == respawnDefaultCharacter)
                {
                    MiscRespawnDefaultCharacter = _checked;
                }
                else if (item == restorePlayerAppearance)
                {
                    RestorePlayerAppearance = _checked;
                }
                else if (item == restorePlayerWeapons)
                {
                    RestorePlayerWeapons = _checked;
                }

            };

            // Handle button presses.
            menu.OnItemSelect += (sender, item, index) =>
            {
                if (item == saveSettings)
                {
                    UserDefaults.SaveSettings();
                }
            };
        }


        /// <summary>
        /// Create the menu if it doesn't exist, and then returns it.
        /// </summary>
        /// <returns>The Menu</returns>
        public Menu GetMenu()
        {
            if (menu == null)
            {
                CreateMenu();
            }
            return menu;
        }

        private readonly struct Blip
        {
            public readonly Vector3 Location;
            public readonly int Sprite;
            public readonly string Name;
            public readonly int Color;
            public readonly int blipID;

            public Blip(Vector3 Location, int Sprite, string Name, int Color, int blipID)
            {
                this.Location = Location;
                this.Sprite = Sprite;
                this.Name = Name;
                this.Color = Color;
                this.blipID = blipID;
            }
        }

        private readonly List<Blip> blips = new();

        /// <summary>
        /// Toggles blips on/off.
        /// </summary>
        /// <param name="enable"></param>
        private void ToggleBlips(bool enable)
        {
            if (enable)
            {
                try
                {
                    foreach (var bl in vMenuShared.ConfigManager.GetLocationBlipsData())
                    {
                        var blipID = AddBlipForCoord(bl.coordinates.X, bl.coordinates.Y, bl.coordinates.Z);
                        SetBlipSprite(blipID, bl.spriteID);
                        BeginTextCommandSetBlipName("STRING");
                        AddTextComponentSubstringPlayerName(bl.name);
                        EndTextCommandSetBlipName(blipID);
                        SetBlipColour(blipID, bl.color);
                        SetBlipAsShortRange(blipID, true);

                        var b = new Blip(bl.coordinates, bl.spriteID, bl.name, bl.color, blipID);
                        blips.Add(b);
                    }
                }
                catch (JsonReaderException ex)
                {
                    Debug.Write($"\n\n[vMenu] An erro occurred enquanto carregando o localizaçãos.json arquivo. Por favor contact o servidor dono para resolve this.\nWhen contacting o dono, provide o following erro detalhes:\n{ex.Mensagem}.\n\n\n");
                }
            }
            else
            {
                if (blips.Count > 0)
                {
                    foreach (var blip in blips)
                    {
                        var id = blip.blipID;
                        if (DoesBlipExist(id))
                        {
                            RemoveBlip(ref id);
                        }
                    }
                }
                blips.Clear();
            }
        }

    }
}
