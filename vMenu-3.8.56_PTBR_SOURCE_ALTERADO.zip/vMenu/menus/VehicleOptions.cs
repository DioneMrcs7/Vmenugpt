using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

using CitizenFX.Core;

using MenuAPI;

using vMenuClient.data;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.ConfigManager;
using static vMenuShared.PermissionsManager;

namespace vMenuClient.menus
{
    public class VehicleOptions
    {
        #region Variables
        // Menu variable, will be defined in CreateMenu()
        private Menu menu;
        public static Dictionary<uint, Dictionary<int, string>> VehicleExtras;

        // Submenus
        public Menu VehicleModMenu { get; private set; }
        public Menu VehicleDoorsMenu { get; private set; }
        public Menu VehicleWindowsMenu { get; private set; }
        public Menu VehicleComponentsMenu { get; private set; }
        public Menu VehicleLiveriesMenu { get; private set; }
        public Menu VehicleColorsMenu { get; private set; }
        public Menu DeleteConfirmMenu { get; private set; }
        public Menu VehicleUnderglowMenu { get; private set; }

        // Public variables (getters only), return the private variables.
        public bool VehicleGodMode { get; private set; } = UserDefaults.VehicleGodMode;
        public bool VehicleGodInvincible { get; private set; } = UserDefaults.VehicleGodInvincible;
        public bool VehicleGodEngine { get; private set; } = UserDefaults.VehicleGodEngine;
        public bool VehicleGodVisual { get; private set; } = UserDefaults.VehicleGodVisual;
        public bool VehicleGodStrongWheels { get; private set; } = UserDefaults.VehicleGodStrongWheels;
        public bool VehicleGodRamp { get; private set; } = UserDefaults.VehicleGodRamp;
        public bool VehicleGodAutoRepair { get; private set; } = UserDefaults.VehicleGodAutoRepair;

        public bool VehicleNeverDirty { get; private set; } = UserDefaults.VehicleNeverDirty;
        public bool VehicleEngineAlwaysOn { get; private set; } = UserDefaults.VehicleEngineAlwaysOn;
        public bool VehicleNoSiren { get; private set; } = UserDefaults.VehicleNoSiren;
        public bool VehicleNoBikeHelemet { get; private set; } = UserDefaults.VehicleNoBikeHelmet;
        public bool FlashHighbeamsOnHonk { get; private set; } = UserDefaults.VehicleHighbeamsOnHonk;
        public bool DisablePlaneTurbulence { get; private set; } = UserDefaults.VehicleDisablePlaneTurbulence;
        public bool DisableHelicopterTurbulence { get; private set; } = UserDefaults.VehicleDisableHelicopterTurbulence;
        public bool AnchorBoat { get; private set; } = UserDefaults.VehicleAnchorBoat;
        public bool VehicleBikeSeatbelt { get; private set; } = UserDefaults.VehicleBikeSeatbelt;
        public bool VehicleInfiniteFuel { get; private set; } = false;
        public bool VehicleShowHealth { get; private set; } = false;
        public bool VehicleRadioOverride { get; private set; } = UserDefaults.VehicleDefaultRadio >= 0;
        public bool VehicleFrozen { get; private set; } = false;
        public bool VehicleTorqueMultiplier { get; private set; } = false;
        public bool VehiclePowerMultiplier { get; private set; } = false;
        public float VehicleTorqueMultiplierAmount { get; private set; } = 2f;
        public float VehiclePowerMultiplierAmount { get; private set; } = 2f;

        private readonly Dictionary<MenuItem, int> vehicleExtras = new();
        #endregion

        #region CreateMenu()
        /// <summary>
        /// Create menu creates the vehicle options menu.
        /// </summary>
        private void CreateMenu()
        {
            // Create the menu.
            menu = new Menu(Game.Player.Name, "Opções do Veículo");

            #region menu items variables
            // vehicle god mode menu
            var vehGodMenu = new Menu("Invencibilidade do Veículo", "Opções de Invencibilidade do Veículo");
            var vehGodMenuBtn = new MenuItem("Opções de Invencibilidade", "Ative ou desative specific dano types.") { Label = "→→→" };
            MenuController.AddSubmenu(menu, vehGodMenu);

            // Create Checkboxes.
            var vehicleGod = new MenuCheckboxItem("Invencibilidade do Veículo", "Faz com que seu veículo não take any dano. Nãote, você precisa go em o god menu opções below para select what kind de dano you want para desativar.", VehicleGodMode);
            var vehicleNeverDirty = new MenuCheckboxItem("Manter Veículo Limpo", "This will constantly clean seu car se o veículo dirt level goes above 0. Nãote that this somente cleans ~o~dust~s~ ou ~o~dirt~s~. This does não clean mud, snow ou other ~r~dano decals~s~. Repair seu veículo para remover them.", VehicleNeverDirty);
            var vehicleBikeSeatbelt = new MenuCheckboxItem("Cinto para Moto", "Prevents you de being knocked off seu bike, bicyle, ATV ou similar.", VehicleBikeSeatbelt);
            var vehicleEngineAO = new MenuCheckboxItem("Motor Sempre Ligado", "Keeps seu veículo motor em quando you exit seu veículo.", VehicleEngineAlwaysOn);
            var vehicleNoTurbulence = new MenuCheckboxItem("Desativar Turbulência de Aviões", "Desativars o turbulence para todos planes.", DisablePlaneTurbulence);
            var vehicleNoTurbulenceHeli = new MenuCheckboxItem("Desativar Turbulência de Helicópteros", "Desativars o turbulence para todos helicopters.", DisableHelicopterTurbulence);
            var vehicleSetAnchor = new MenuCheckboxItem("Ancorar Barco", "Only works se o veículo atual é um boat e its position é valid para anchoring", AnchorBoat);
            var vehicleNoSiren = new MenuCheckboxItem("Desativar Sirene", "Desativars seu veículo's siren. Only works se seu veículo actutodosy has um siren.", VehicleNoSiren);
            var vehicleNoBikeHelmet = new MenuCheckboxItem("Sem Capacete", "No longer auto-equip a helmet when getting on a bike or quad.", VehicleNoBikeHelemet);
            var vehicleFreeze = new MenuCheckboxItem("Congelar Veículo", "Freeze seu veículo's position.", VehicleFrozen);
            var torqueEnabled = new MenuCheckboxItem("Ativar Multiplicador de Torque", "Ativars o torque multiplier selected de o list below.", VehicleTorqueMultiplier);
            var powerEnabled = new MenuCheckboxItem("Ativar Multiplicador de Potência", "Ativars o power multiplier selected de o list below.", VehiclePowerMultiplier);
            var highbeamsOnHonk = new MenuCheckboxItem("Piscar Farol Alto ao Buzinar", "Ligue seu highbeams em seu veículo quando honking seu horn. Does não work during o day quando you have seu lights girared off.", FlashHighbeamsOnHonk);
            var showHealth = new MenuCheckboxItem("Mostrar Saúde do Veículo", "Mostrars o veículo health em o tela.", VehicleShowHealth);
            var infiniteFuel = new MenuCheckboxItem("Combustível Infinito", "Ativa ou desativa infinite fuel para este veículo, somente works se FRFuel é insttodosed.", VehicleInfiniteFuel);
            var vehicleRadioOverride = new MenuCheckboxItem("Ativar Rádio Padrão", "Ativa ou desativa overriding padrão radio channel in todos veículos", VehicleRadioOverride);

            // Create buttons.
            var fixVehicle = new MenuItem("Reparar Veículo", "Repair any visual e physical dano present em seu veículo.");
            var cleanVehicle = new MenuItem("Lavar Veículo", "Clean seu veículo.");
            var toggleEngine = new MenuItem("Ligar/Desligar Motor", "Girar seu motor em/off.");
            var setLicensePlateText = new MenuItem("Definir Texto da Placa", "Digite um custom license plate para seu veículo.");
            var modMenuBtn = new MenuItem("Menu de Modificações", "Tune e customize seu veículo aqui.")
            {
                Label = "→→→"
            };
            var doorsMenuBtn = new MenuItem("Portas do Veículo", "Abrir, fechar, remover e restaurar veículo portas aqui.")
            {
                Label = "→→→"
            };
            var windowsMenuBtn = new MenuItem("Janelas do Veículo", "Roll seu janelas up/down ou remover/restaurar seu veículo janelas aqui.")
            {
                Label = "→→→"
            };
            var componentsMenuBtn = new MenuItem("Extras do Veículo", "Add/remover veículo components/extras.")
            {
                Label = "→→→"
            };
            var liveriesMenuBtn = new MenuItem("Pinturas do Veículo", "Estilo seu veículo com fancy liveries!")
            {
                Label = "→→→"
            };
            var colorsMenuBtn = new MenuItem("Cores do Veículo", "Estilo seu veículo even further by giving it some ~g~Snailsome ~s~cors!")
            {
                Label = "→→→"
            };
            var underglowMenuBtn = new MenuItem("Neon do Veículo", "Make seu veículo shine com some fancy neon underglow!")
            {
                Label = "→→→"
            };
            var vehicleInvisible = new MenuItem("Alternar Visibilidade do Veículo", "Faz com que seu veículo visible/invisible. ~r~Seu veículo will ser made visible again as soon as you leave o veículo. Otherwise you would não ser able para get back in.");
            var flipVehicle = new MenuItem("Desvirar Veículo", "Definirs seu veículo atual em todos 4 wheels.");
            var vehicleAlarm = new MenuItem("Ativar/Desativar Alarme", "Starts/stops seu veículo's alarm.");
            var cycleSeats = new MenuItem("Trocar de Assento", "Cycle through o disponível veículo seats.");
            var lights = new List<string>()
            {
                "Pisca-Alerta",
                "Seta Esquerda",
                "Seta Direita",
                "Luzes Internas",
                //"Taxi Light", // this doesn't seem to work no matter what.
                "Helicopter Spotlight",
            };
            var vehicleLights = new MenuListItem("Luzes do Veículo", lights, 0, "Girar veículo lights em/off.");

            var stationNames = new List<string>();

            foreach (var radioStationName in Enum.GetNames(typeof(RadioStation)))
            {
                stationNames.Add(radioStationName);
            }

            var radioIndex = UserDefaults.VehicleDefaultRadio;

            if (radioIndex == (int)RadioStation.RadioOff)
            {
                var stations = (RadioStation[])Enum.GetValues(typeof(RadioStation));
                var index = Array.IndexOf(stations, RadioStation.RadioOff);
                radioIndex = index;
            }
            else if (radioIndex < 0)
            {
                radioIndex = 0;
            }

            var radioStations = new MenuListItem("Definir Rádio Padrão", stationNames, radioIndex, "Selecione um padrão radio station para todos cars you criar")
            {
                Enabled = VehicleRadioOverride
            };

            var tiresList = new List<string>() { "Todos os Pneus", "Tire #1", "Tire #2", "Tire #3", "Tire #4", "Tire #5", "Tire #6", "Tire #7", "Tire #8" };
            var vehicleTiresList = new MenuListItem("Reparar/Furar Pneus", tiresList, 0, "Fix ou destroy um specific veículo tire, ou todos de them em once. Nãote, não todos indexes estão valid para todos veículos, some might não do anything em certain veículos.");

            var destroyEngine = new MenuItem("Destroy Motor", "Destroys seu veículo's motor.");

            var deleteBtn = new MenuItem("~r~Excluir Veículo", "Excluir seu veículo, this ~r~can NÃOT ser undone~s~!")
            {
                LeftIcon = MenuItem.Icon.WARNING,
                Label = "→→→"
            };
            var deleteNoBtn = new MenuItem("NO, CANCEL", "NÃO, do NÃOT excluir my veículo e go back!");
            var deleteYesBtn = new MenuItem("~r~SIM, DELETE", "Sim I'm sure, excluir my veículo por favor, I understand that this não pode ser desfeito.")
            {
                LeftIcon = MenuItem.Icon.WARNING
            };

            // Create lists.
            var dirtlevel = new List<string> { "Sem Sujeira", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15" };
            var setDirtLevel = new MenuListItem("Definir Nível de Sujeira", dirtlevel, 0, "Selecionar how much dirt should ser visible em seu veículo, press ~r~enter~s~ " +
                "para apply o selected level.");
            var licensePlates = new List<string> {
                GetLabelText("CMOD_PLA_0"), // Plate Index 0 // BlueOnWhite1
                GetLabelText("CMOD_PLA_1"), // Plate Index 1 // BlueOnWhite2
                GetLabelText("CMOD_PLA_2"), // Plate Index 2 // BlueOnWhite3
                GetLabelText("CMOD_PLA_3"), // Plate Index 3 // YellowOnBlue
                GetLabelText("CMOD_PLA_4"), // Plate Index 4 // YellowOnBlack
                GetLabelText("PROL"), // Plate Index 5 // NorthYankton
                GetLabelText("CMOD_PLA_6"), // Plate Index 6 // ECola
                GetLabelText("CMOD_PLA_7"), // Plate Index 7 // LasVenturas
                GetLabelText("CMOD_PLA_8"), // Plate Index 8 // LibertyCity
                GetLabelText("CMOD_PLA_9"), // Plate Index 9 // LSCarMeet
                GetLabelText("CMOD_PLA_10"), // Plate Index 10 // LSPanic
                GetLabelText("CMOD_PLA_11"), // Plate Index 11 // LSPounders
                GetLabelText("CMOD_PLA_12"), // Plate Index 12 // Sprunk
            };
            var setLicensePlateType = new MenuListItem("Tipo de Placa", licensePlates, 0, "Escolha um license plate type e press ~r~enter ~s~para apply " +
                "it para seu veículo.");
            var torqueMultiplierList = new List<string> { "x2", "x4", "x8", "x16", "x32", "x64", "x128", "x256", "x512", "x1024" };
            var torqueMultiplier = new MenuListItem("Definir Multiplicador de Torque", torqueMultiplierList, 0, "Definir o motor torque multiplier.");
            var powerMultiplierList = new List<string> { "x2", "x4", "x8", "x16", "x32", "x64", "x128", "x256", "x512", "x1024" };
            var powerMultiplier = new MenuListItem("Definir Multiplicador de Potência", powerMultiplierList, 0, "Definir o motor power multiplier.");
            var speedLimiterOptions = new List<string>() { "Set", "Redefinir", "Limite de Velocidade Personalizado" };
            var speedLimiter = new MenuListItem("Limitador de Velocidade", speedLimiterOptions, 0, "Definir seu veículos max velocidade para seu ~y~atual velocidade~s~. Redefinirting seu veículos max velocidade will definir o max velocidade de seu veículo atual back para padrão. Only seu veículo atual é affected by this option.");
            #endregion

            #region Submenus
            // Submenu's
            VehicleModMenu = new Menu("Menu de Modificações", "Modificações do Veículo");
            VehicleModMenu.InstructionalButtons.Add(Control.Jump, "Alternar Portas do Veículo");
            VehicleModMenu.ButtonPressHandlers.Add(new Menu.ButtonPressHandler(Control.Jump, Menu.ControlPressCheckType.JUST_PRESSED, new Action<Menu, Control>((m, c) =>
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                {
                    var open = GetVehicleDoorAngleRatio(veh.Handle, 0) < 0.1f;
                    if (open)
                    {
                        for (var i = 0; i < 8; i++)
                        {
                            SetVehicleDoorOpen(veh.Handle, i, false, false);
                        }
                    }
                    else
                    {
                        SetVehicleDoorsShut(veh.Handle, false);
                    }
                }
            }), false));
            VehicleDoorsMenu = new Menu("Portas do Veículo", "Gerenciar Portas do Veículo");
            VehicleWindowsMenu = new Menu("Janelas do Veículo", "Gerenciar Janelas do Veículo");
            VehicleComponentsMenu = new Menu("Extras do Veículo", "Extras/Componentes do Veículo");
            VehicleLiveriesMenu = new Menu("Pinturas do Veículo", "Pinturas do Veículo");
            VehicleColorsMenu = new Menu("Cores do Veículo", "Cores do Veículo");
            DeleteConfirmMenu = new Menu("Confirm Action", "Excluir Veículo, Tem Certeza?");
            VehicleUnderglowMenu = new Menu("Neon do Veículo", "Opções de Neon Inferior");

            MenuController.AddSubmenu(menu, VehicleModMenu);
            MenuController.AddSubmenu(menu, VehicleDoorsMenu);
            MenuController.AddSubmenu(menu, VehicleWindowsMenu);
            MenuController.AddSubmenu(menu, VehicleComponentsMenu);
            MenuController.AddSubmenu(menu, VehicleLiveriesMenu);
            MenuController.AddSubmenu(menu, VehicleColorsMenu);
            MenuController.AddSubmenu(menu, DeleteConfirmMenu);
            MenuController.AddSubmenu(menu, VehicleUnderglowMenu);
            #endregion

            #region Add items to the menu.
            // Add everything to the menu. (based on permissions)
            if (IsAllowed(Permission.VOGod)) // GOD MODE
            {
                menu.AddMenuItem(vehicleGod);
                menu.AddMenuItem(vehGodMenuBtn);
                MenuController.BindMenuItem(menu, vehGodMenu, vehGodMenuBtn);

                var godInvincible = new MenuCheckboxItem("Invencível", "Makes o car invincible. Includes fire dano, explosion dano, collision dano e mais.", VehicleGodInvincible);
                var godEngine = new MenuCheckboxItem("Dano do Motor", "Desativars seu motor de taking any dano.", VehicleGodEngine);
                var godVisual = new MenuCheckboxItem("Dano Visual", "This prevents scratches e other dano decals de being applied para seu veículo. It does não prevent (corpo) deformation dano.", VehicleGodVisual);
                var godStrongWheels = new MenuCheckboxItem("Rodas Resistentes", "Desativars seu wheels de being deformed e causing reduced handling. This does não make tires bulletproof.", VehicleGodStrongWheels);
                var godRamp = new MenuCheckboxItem("Ramp Dano", "Desativars veículos such as o Ramp Buggy de taking dano quando using o ramp.", VehicleGodRamp);
                var godAutoRepair = new MenuCheckboxItem("~r~Auto Repair", "Automatictodosy repairs seu veículo quando it has ANY type de dano. It's recommended para keep this girared off para prevent glitchyness.", VehicleGodAutoRepair);

                vehGodMenu.AddMenuItem(godInvincible);
                vehGodMenu.AddMenuItem(godEngine);
                vehGodMenu.AddMenuItem(godVisual);
                vehGodMenu.AddMenuItem(godStrongWheels);
                vehGodMenu.AddMenuItem(godRamp);
                vehGodMenu.AddMenuItem(godAutoRepair);

                vehGodMenu.OnCheckboxChange += (sender, item, index, _checked) =>
                {
                    if (item == godInvincible)
                    {
                        VehicleGodInvincible = _checked;
                    }
                    else if (item == godEngine)
                    {
                        VehicleGodEngine = _checked;
                    }
                    else if (item == godVisual)
                    {
                        VehicleGodVisual = _checked;
                    }
                    else if (item == godStrongWheels)
                    {
                        VehicleGodStrongWheels = _checked;
                    }
                    else if (item == godRamp)
                    {
                        VehicleGodRamp = _checked;
                    }
                    else if (item == godAutoRepair)
                    {
                        VehicleGodAutoRepair = _checked;
                    }
                };

            }
            if (IsAllowed(Permission.VORepair)) // REPAIR VEHICLE
            {
                menu.AddMenuItem(fixVehicle);
            }
            if (IsAllowed(Permission.VOKeepClean))
            {
                menu.AddMenuItem(vehicleNeverDirty);
            }
            if (IsAllowed(Permission.VOWash))
            {
                menu.AddMenuItem(cleanVehicle); // CLEAN VEHICLE
                menu.AddMenuItem(setDirtLevel); // SET DIRT LEVEL
            }
            if (IsAllowed(Permission.VOMod)) // MOD MENU
            {
                menu.AddMenuItem(modMenuBtn);
            }
            if (IsAllowed(Permission.VOColors)) // COLORS MENU
            {
                menu.AddMenuItem(colorsMenuBtn);
            }
            if (IsAllowed(Permission.VOUnderglow)) // UNDERGLOW EFFECTS
            {
                menu.AddMenuItem(underglowMenuBtn);
                MenuController.BindMenuItem(menu, VehicleUnderglowMenu, underglowMenuBtn);
            }
            if (IsAllowed(Permission.VOLiveries)) // LIVERIES MENU
            {
                menu.AddMenuItem(liveriesMenuBtn);
            }
            if (IsAllowed(Permission.VOComponents)) // COMPONENTS MENU
            {
                menu.AddMenuItem(componentsMenuBtn);
            }
            if (IsAllowed(Permission.VOEngine)) // TOGGLE ENGINE ON/OFF
            {
                menu.AddMenuItem(toggleEngine);
            }
            if (IsAllowed(Permission.VOChangePlate))
            {
                menu.AddMenuItem(setLicensePlateText); // SET LICENSE PLATE TEXT
                menu.AddMenuItem(setLicensePlateType); // SET LICENSE PLATE TYPE
            }
            if (IsAllowed(Permission.VODoors)) // DOORS MENU
            {
                menu.AddMenuItem(doorsMenuBtn);
            }
            if (IsAllowed(Permission.VOWindows)) // WINDOWS MENU
            {
                menu.AddMenuItem(windowsMenuBtn);
            }
            if (IsAllowed(Permission.VOBikeSeatbelt))
            {
                menu.AddMenuItem(vehicleBikeSeatbelt);
            }
            if (IsAllowed(Permission.VOSpeedLimiter)) // SPEED LIMITER
            {
                menu.AddMenuItem(speedLimiter);
            }
            if (IsAllowed(Permission.VOTorqueMultiplier))
            {
                menu.AddMenuItem(torqueEnabled); // TORQUE ENABLED
                menu.AddMenuItem(torqueMultiplier); // TORQUE LIST
            }
            if (IsAllowed(Permission.VOPowerMultiplier))
            {
                menu.AddMenuItem(powerEnabled); // POWER ENABLED
                menu.AddMenuItem(powerMultiplier); // POWER LIST
            }
            if (IsAllowed(Permission.VODisableTurbulence))
            {
                menu.AddMenuItem(vehicleNoTurbulence);
                menu.AddMenuItem(vehicleNoTurbulenceHeli);
            }
            if (IsAllowed(Permission.VOAnchorBoat))
            {
                menu.AddMenuItem(vehicleSetAnchor);
            }
            if (IsAllowed(Permission.VOFlip)) // FLIP VEHICLE
            {
                menu.AddMenuItem(flipVehicle);
            }
            if (IsAllowed(Permission.VOAlarm)) // TOGGLE VEHICLE ALARM
            {
                menu.AddMenuItem(vehicleAlarm);
            }
            if (IsAllowed(Permission.VOCycleSeats)) // CYCLE THROUGH VEHICLE SEATS
            {
                menu.AddMenuItem(cycleSeats);
            }
            if (IsAllowed(Permission.VOLights)) // VEHICLE LIGHTS LIST
            {
                menu.AddMenuItem(vehicleLights);
            }
            if (IsAllowed(Permission.VOFixOrDestroyTires))
            {
                menu.AddMenuItem(vehicleTiresList);
            }
            if (IsAllowed(Permission.VODestroyEngine))
            {
                menu.AddMenuItem(destroyEngine);
            }
            if (IsAllowed(Permission.VOFreeze)) // FREEZE VEHICLE
            {
                menu.AddMenuItem(vehicleFreeze);
            }
            if (IsAllowed(Permission.VOInvisible)) // MAKE VEHICLE INVISIBLE
            {
                menu.AddMenuItem(vehicleInvisible);
            }
            if (IsAllowed(Permission.VOEngineAlwaysOn)) // LEAVE ENGINE RUNNING
            {
                menu.AddMenuItem(vehicleEngineAO);
            }
            if (IsAllowed(Permission.VOInfiniteFuel)) // INFINITE FUEL
            {
                menu.AddMenuItem(infiniteFuel);
            }
            // always allowed
            menu.AddMenuItem(showHealth); // SHOW VEHICLE HEALTH

            // I don't really see why would you want to disable this so I will not add useless permissions
            menu.AddMenuItem(vehicleRadioOverride);
            menu.AddMenuItem(radioStations);

            if (IsAllowed(Permission.VONoSiren) && !GetSettingsBool(Setting.vmenu_use_els_compatibility_mode)) // DISABLE SIREN
            {
                menu.AddMenuItem(vehicleNoSiren);
            }
            if (IsAllowed(Permission.VONoHelmet)) // DISABLE BIKE HELMET
            {
                menu.AddMenuItem(vehicleNoBikeHelmet);
            }
            if (IsAllowed(Permission.VOFlashHighbeamsOnHonk)) // FLASH HIGHBEAMS ON HONK
            {
                menu.AddMenuItem(highbeamsOnHonk);
            }

            if (IsAllowed(Permission.VODelete)) // DELETE VEHICLE
            {
                menu.AddMenuItem(deleteBtn);
            }
            #endregion

            #region delete vehicle handle stuff
            DeleteConfirmMenu.AddMenuItem(deleteNoBtn);
            DeleteConfirmMenu.AddMenuItem(deleteYesBtn);
            DeleteConfirmMenu.OnItemSelect += (sender, item, index) =>
            {
                if (item == deleteNoBtn)
                {
                    DeleteConfirmMenu.GoBack();
                }
                else
                {
                    DeleteVehicle();
                    DeleteConfirmMenu.GoBack();
                }
            };
            #endregion

            #region Bind Submenus to their buttons.
            MenuController.BindMenuItem(menu, VehicleModMenu, modMenuBtn);
            MenuController.BindMenuItem(menu, VehicleDoorsMenu, doorsMenuBtn);
            MenuController.BindMenuItem(menu, VehicleWindowsMenu, windowsMenuBtn);
            MenuController.BindMenuItem(menu, VehicleComponentsMenu, componentsMenuBtn);
            MenuController.BindMenuItem(menu, VehicleLiveriesMenu, liveriesMenuBtn);
            MenuController.BindMenuItem(menu, VehicleColorsMenu, colorsMenuBtn);
            MenuController.BindMenuItem(menu, DeleteConfirmMenu, deleteBtn);
            #endregion

            #region Handle button presses
            // Manage button presses.
            menu.OnItemSelect += (sender, item, index) =>
            {
                if (item == deleteBtn) // reset the index so that "no" / "cancel" will always be selected by default.
                {
                    DeleteConfirmMenu.RefreshIndex();
                }
                // If the player is actually in a vehicle, continue.
                if (GetVehicle() != null && GetVehicle().Exists())
                {
                    // Create a vehicle object.
                    var vehicle = GetVehicle();

                    // Check if the player is the driver of the vehicle, if so, continue.
                    if (vehicle.GetPedOnSeat(VehicleSeat.Driver) == Game.PlayerPed)
                    {
                        // Repair vehicle.
                        if (item == fixVehicle)
                        {
                            vehicle.Repair();
                        }
                        // Clean vehicle.
                        else if (item == cleanVehicle)
                        {
                            vehicle.Wash();
                        }
                        // Flip vehicle.
                        else if (item == flipVehicle)
                        {
                            SetVehicleOnGroundProperly(vehicle.Handle);
                        }
                        // Toggle alarm.
                        else if (item == vehicleAlarm)
                        {
                            ToggleVehicleAlarm(vehicle);
                        }
                        // Toggle engine
                        else if (item == toggleEngine)
                        {
                            SetVehicleEngineOn(vehicle.Handle, !vehicle.IsEngineRunning, false, true);
                        }
                        // Set license plate text
                        else if (item == setLicensePlateText)
                        {
                            SetLicensePlateCustomText();
                        }
                        // Make vehicle invisible.
                        else if (item == vehicleInvisible)
                        {
                            if (vehicle.IsVisible)
                            {
                                // Check the visibility of all peds inside before setting the vehicle as invisible.
                                var visiblePeds = new Dictionary<Ped, bool>();
                                foreach (var p in vehicle.Occupants)
                                {
                                    visiblePeds.Add(p, p.IsVisible);
                                }

                                // Set the vehicle invisible or invincivble.
                                vehicle.IsVisible = !vehicle.IsVisible;

                                // Restore visibility for each ped.
                                foreach (var pe in visiblePeds)
                                {
                                    pe.Key.IsVisible = pe.Value;
                                }
                            }
                            else
                            {
                                // Set the vehicle invisible or invincivble.
                                vehicle.IsVisible = !vehicle.IsVisible;
                            }
                        }
                        // Destroy vehicle engine
                        else if (item == destroyEngine)
                        {
                            SetVehicleEngineHealth(vehicle.Handle, -4000);
                        }
                    }

                    // If the player is not the driver seat and a button other than the option below (cycle seats) was pressed, notify them.
                    else if (item != cycleSeats)
                    {
                        Notify.Error("You have para ser o motorista de um veículo para access this menu!", true, false);
                    }

                    // Cycle vehicle seats
                    if (item == cycleSeats)
                    {
                        CycleThroughSeats();
                    }
                }
            };
            #endregion

            #region Handle checkbox changes.
            menu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                // Create a vehicle object.
                var vehicle = GetVehicle();

                if (item == vehicleGod) // God Mode Toggled
                {
                    VehicleGodMode = _checked;
                }
                else if (item == vehicleFreeze) // Freeze Vehicle Toggled
                {
                    VehicleFrozen = _checked;
                    if (!_checked)
                    {
                        if (vehicle != null && vehicle.Exists())
                        {
                            FreezeEntityPosition(vehicle.Handle, false);
                        }
                    }
                }
                else if (item == torqueEnabled) // Enable Torque Multiplier Toggled
                {
                    VehicleTorqueMultiplier = _checked;
                }
                else if (item == powerEnabled) // Enable Power Multiplier Toggled
                {
                    VehiclePowerMultiplier = _checked;
                    if (_checked)
                    {
                        if (vehicle != null && vehicle.Exists())
                        {
                            SetVehicleEnginePowerMultiplier(vehicle.Handle, VehiclePowerMultiplierAmount);
                        }
                    }
                    else
                    {
                        if (vehicle != null && vehicle.Exists())
                        {
                            SetVehicleEnginePowerMultiplier(vehicle.Handle, 1f);
                        }
                    }
                }
                else if (item == vehicleEngineAO) // Leave Engine Running (vehicle always on) Toggled
                {
                    VehicleEngineAlwaysOn = _checked;
                }
                else if (item == showHealth) // show vehicle health on screen.
                {
                    VehicleShowHealth = _checked;
                }
                else if (item == vehicleRadioOverride)
                {
                    int overrideDisabled = -1;
                    int starterChannel = (int)RadioStation.LosSantosRockRadio;

                    VehicleRadioOverride = _checked;

                    UserDefaults.VehicleDefaultRadio = _checked ? starterChannel : overrideDisabled;

                    radioStations.ListIndex = starterChannel;
                    radioStations.Enabled = _checked;
                }
                else if (item == vehicleNoSiren) // Disable Siren Toggled
                {
                    VehicleNoSiren = _checked;
                    if (vehicle != null && vehicle.Exists())
                    {
                        vehicle.IsSirenSilent = _checked;
                    }
                }
                else if (item == vehicleNoBikeHelmet) // No Helemet Toggled
                {
                    VehicleNoBikeHelemet = _checked;
                }
                else if (item == highbeamsOnHonk)
                {
                    FlashHighbeamsOnHonk = _checked;
                }
                else if (item == vehicleNoTurbulence)
                {
                    DisablePlaneTurbulence = _checked;
                    if (vehicle != null && vehicle.Exists() && vehicle.Model.IsPlane)
                    {
                        if (MainMenu.VehicleOptionsMenu.DisablePlaneTurbulence)
                        {
                            SetPlaneTurbulenceMultiplier(vehicle.Handle, 0f);
                        }
                        else
                        {
                            SetPlaneTurbulenceMultiplier(vehicle.Handle, 1.0f);
                        }
                    }
                }
                else if (item == vehicleNoTurbulenceHeli)
                {
                    DisableHelicopterTurbulence = _checked;
                    if (vehicle != null && vehicle.Exists() && vehicle.Model.IsHelicopter)
                    {
                        if (MainMenu.VehicleOptionsMenu.DisableHelicopterTurbulence)
                        {
                            SetHeliTurbulenceScalar(vehicle.Handle, 0f);
                        }
                        else
                        {
                            SetHeliTurbulenceScalar(vehicle.Handle, 1f);
                        }
                    }
                }
                else if (item == vehicleSetAnchor)
                {
                    AnchorBoat = _checked;
                    if (vehicle != null && vehicle.Exists() && vehicle.Model.IsBoat && CanAnchorBoatHere(vehicle.Handle))
                    {
                        if (MainMenu.VehicleOptionsMenu.AnchorBoat)
                        {
                            SetBoatAnchor(vehicle.Handle, true);
                            SetBoatFrozenWhenAnchored(vehicle.Handle, true);
                            SetForcedBoatLocationWhenAnchored(vehicle.Handle, true);
                        }
                        else
                        {
                            SetBoatAnchor(vehicle.Handle, false);
                            SetBoatFrozenWhenAnchored(vehicle.Handle, false);
                            SetForcedBoatLocationWhenAnchored(vehicle.Handle, false);
                        }
                    }
                }
                else if (item == vehicleNeverDirty)
                {
                    VehicleNeverDirty = _checked;
                }
                else if (item == vehicleBikeSeatbelt)
                {
                    VehicleBikeSeatbelt = _checked;
                }
                else if (item == infiniteFuel)
                {
                    VehicleInfiniteFuel = _checked;
                    TriggerEvent("vMenu:InfiniteFuelToggled", _checked);
                }
            };
            #endregion

            #region Handle List Changes.
            // Handle list changes.
            menu.OnListIndexChange += (sender, item, oldIndex, newIndex, itemIndex) =>
            {
                Vehicle veh = GetVehicle();
                bool vehExists = veh != null && veh.Exists();

                if (vehExists)
                {
                    // If the torque multiplier changed. Change the torque multiplier to the new value.
                    if (item == torqueMultiplier)
                    {
                        // Get the selected value and remove the "x" in the string with nothing.
                        var value = torqueMultiplierList[newIndex].ToString().Replace("x", "");
                        // Convert the value to a float and set it as a public variable.
                        VehicleTorqueMultiplierAmount = float.Parse(value);
                    }
                    // If the power multiplier is changed. Change the power multiplier to the new value.
                    else if (item == powerMultiplier)
                    {
                        // Get the selected value. Remove the "x" from the string.
                        var value = powerMultiplierList[newIndex].ToString().Replace("x", "");
                        // Conver the string into a float and set it to be the value of the public variable.
                        VehiclePowerMultiplierAmount = float.Parse(value);
                        if (VehiclePowerMultiplier)
                        {
                            SetVehicleEnginePowerMultiplier(veh.Handle, VehiclePowerMultiplierAmount);
                        }
                    }
                    else if (item == setLicensePlateType)
                    {
                        // Set the license plate style.
                        switch (newIndex)
                        {
                            case 0:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.BlueOnWhite1;
                                break;
                            case 1:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.BlueOnWhite2;
                                break;
                            case 2:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.BlueOnWhite3;
                                break;
                            case 3:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.YellowOnBlue;
                                break;
                            case 4:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.YellowOnBlack;
                                break;
                            case 5:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.NorthYankton;
                                break;
                            case 6:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.ECola;
                                break;
                            case 7:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.LasVenturas;
                                break;
                            case 8:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.LibertyCity;
                                break;
                            case 9:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.LSCarMeet;
                                break;
                            case 10:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.LSPanic;
                                break;
                            case 11:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.LSPounders;
                                break;
                            case 12:
                                veh.Mods.LicensePlateStyle = LicensePlateStyle.Sprunk;
                                break;
                            default:
                                break;
                        }
                    }
                }

                if (item == radioStations)
                {
                    var newStation = (RadioStation)Enum.GetValues(typeof(RadioStation)).GetValue(newIndex);

                    if (vehExists && DoesPlayerVehHaveRadio())
                    {
                        veh.RadioStation = newStation;
                    }

                    UserDefaults.VehicleDefaultRadio = (int)newStation;
                }
            };
            #endregion

            #region Handle List Items Selected
            menu.OnListItemSelect += async (sender, item, listIndex, itemIndex) =>
            {
                // Set dirt level
                if (item == setDirtLevel)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        GetVehicle().DirtLevel = float.Parse(listIndex.ToString());
                    }
                    else
                    {
                        Notify.Error(CommonErrors.NoVehicle);
                    }
                }
                // Toggle vehicle lights
                else if (item == vehicleLights)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        var veh = GetVehicle();
                        // We need to do % 4 because this seems to be some sort of flags system. For a taxi, this function returns 65, 66, etc.
                        // So % 4 takes care of that.
                        var state = GetVehicleIndicatorLights(veh.Handle) % 4; // 0 = none, 1 = left, 2 = right, 3 = both

                        if (listIndex == 0) // Hazard lights
                        {
                            if (state != 3) // either all lights are off, or one of the two (left/right) is off.
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, true); // left on
                                SetVehicleIndicatorLights(veh.Handle, 0, true); // right on
                            }
                            else // both are on.
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, false); // left off
                                SetVehicleIndicatorLights(veh.Handle, 0, false); // right off
                            }
                        }
                        else if (listIndex == 1) // left indicator
                        {
                            if (state != 1) // Left indicator is (only) off
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, true); // left on
                                SetVehicleIndicatorLights(veh.Handle, 0, false); // right off
                            }
                            else
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, false); // left off
                                SetVehicleIndicatorLights(veh.Handle, 0, false); // right off
                            }
                        }
                        else if (listIndex == 2) // right indicator
                        {
                            if (state != 2) // Right indicator (only) is off
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, false); // left off
                                SetVehicleIndicatorLights(veh.Handle, 0, true); // right on
                            }
                            else
                            {
                                SetVehicleIndicatorLights(veh.Handle, 1, false); // left off
                                SetVehicleIndicatorLights(veh.Handle, 0, false); // right off
                            }
                        }
                        else if (listIndex == 3) // Interior lights
                        {
                            SetVehicleInteriorlight(veh.Handle, !IsVehicleInteriorLightOn(veh.Handle));
                            //CommonFunctions.Log("Something cool here.");
                        }
                        //else if (listIndex == 4) // taxi light
                        //{
                        //    veh.IsTaxiLightOn = !veh.IsTaxiLightOn;
                        //    //    SetTaxiLights(veh, true);
                        //    //    SetTaxiLights(veh, false);
                        //    //    //CommonFunctions.Log(IsTaxiLightOn(veh).ToString());
                        //    //    //SetTaxiLights(veh, true);
                        //    //    //CommonFunctions.Log(IsTaxiLightOn(veh).ToString());
                        //    //    //SetTaxiLights(veh, false);
                        //    //    //SetTaxiLights(veh, !IsTaxiLightOn(veh));
                        //    //    CommonFunctions.Log
                        //}
                        else if (listIndex == 4) // helicopter spotlight
                        {
                            SetVehicleSearchlight(veh.Handle, !IsVehicleSearchlightOn(veh.Handle), true);
                        }
                    }
                    else
                    {
                        Notify.Error(CommonErrors.NoVehicle);
                    }
                }
                // Speed Limiter
                else if (item == speedLimiter)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        var vehicle = GetVehicle();

                        if (vehicle != null && vehicle.Exists())
                        {
                            if (listIndex == 0) // Set
                            {
                                SetEntityMaxSpeed(vehicle.Handle, 500.01f);
                                SetEntityMaxSpeed(vehicle.Handle, vehicle.Speed);

                                if (ShouldUseMetricMeasurements()) // kph
                                {
                                    Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(vehicle.Speed * 3.6f, 1)} KPH~s~.");
                                }
                                else // mph
                                {
                                    Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(vehicle.Speed * 2.237f, 1)} MPH~s~.");
                                }

                            }
                            else if (listIndex == 1) // Reset
                            {
                                SetEntityMaxSpeed(vehicle.Handle, 500.01f); // Default max speed seemingly for all vehicles.
                                Notify.Info("Veículo velocidade é agora no longer limited.");
                            }
                            else if (listIndex == 2) // custom speed
                            {
                                var inputSpeed = await GetUserInput("Digite um velocidade (in meters/sec)", "20.0", 5);
                                if (!string.IsNullOrEmpty(inputSpeed))
                                {
                                    if (float.TryParse(inputSpeed, out var outFloat))
                                    {
                                        //vehicle.MaxSpeed = outFloat;
                                        SetEntityMaxSpeed(vehicle.Handle, 500.01f);
                                        await BaseScript.Delay(0);
                                        SetEntityMaxSpeed(vehicle.Handle, outFloat + 0.01f);
                                        if (ShouldUseMetricMeasurements()) // kph
                                        {
                                            Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(outFloat * 3.6f, 1)} KPH~s~.");
                                        }
                                        else // mph
                                        {
                                            Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(outFloat * 2.237f, 1)} MPH~s~.");
                                        }
                                    }
                                    else if (int.TryParse(inputSpeed, out var outInt))
                                    {
                                        SetEntityMaxSpeed(vehicle.Handle, 500.01f);
                                        await BaseScript.Delay(0);
                                        SetEntityMaxSpeed(vehicle.Handle, outInt + 0.01f);
                                        if (ShouldUseMetricMeasurements()) // kph
                                        {
                                            Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(outInt * 3.6f, 1)} KPH~s~.");
                                        }
                                        else // mph
                                        {
                                            Notify.Info($"Veículo velocidade é agora limited para ~b~{Math.Round(outInt * 2.237f, 1)} MPH~s~.");
                                        }
                                    }
                                    else
                                    {
                                        Notify.Error("This é não um valid number. Por favor enter um valid velocidade in meters per segundo.");
                                    }
                                }
                                else
                                {
                                    Notify.Error(CommonErrors.InvalidInput);
                                }
                            }
                        }
                    }
                }
                else if (item == vehicleTiresList)
                {
                    //bool fix = item == vehicleTiresList;

                    var veh = GetVehicle();
                    if (veh != null && veh.Exists())
                    {
                        if (Game.PlayerPed == veh.Driver)
                        {
                            if (listIndex == 0)
                            {
                                if (IsVehicleTyreBurst(veh.Handle, 0, false))
                                {
                                    for (var i = 0; i < 8; i++)
                                    {
                                        SetVehicleTyreFixed(veh.Handle, i);
                                    }
                                    Notify.Success("Todos veículo tyres have been fixed.");
                                }
                                else
                                {
                                    for (var i = 0; i < 8; i++)
                                    {
                                        SetVehicleTyreBurst(veh.Handle, i, false, 1f);
                                    }
                                    Notify.Success("Todos veículo tyres have been destroyed.");
                                }
                            }
                            else
                            {
                                var index = listIndex - 1;
                                if (IsVehicleTyreBurst(veh.Handle, index, false))
                                {
                                    SetVehicleTyreFixed(veh.Handle, index);
                                    Notify.Success($"Veículo tyre #{listIndex} has been fixed.");
                                }
                                else
                                {
                                    SetVehicleTyreBurst(veh.Handle, index, false, 1f);
                                    Notify.Success($"Veículo tyre #{listIndex} has been destroyed.");
                                }
                            }
                        }
                        else
                        {
                            Notify.Error(CommonErrors.NeedToBeTheDriver);
                        }
                    }
                    else
                    {
                        Notify.Error(CommonErrors.NoVehicle);
                    }
                }
            };
            #endregion

            #region Vehicle Colors Submenu Stuff
            // color customization menu
            var customizeColorMenu = new Menu("Cores do Veículo", "Customize Colors");
            MenuController.AddSubmenu(VehicleColorsMenu, customizeColorMenu);

            var colorsCustomizationBtn = new MenuItem("Customize Colors") { Label = "→→→" };
            VehicleColorsMenu.AddMenuItem(colorsCustomizationBtn);
            MenuController.BindMenuItem(VehicleColorsMenu, customizeColorMenu, colorsCustomizationBtn);

            // primary menu
            var primaryColorsMenu = new Menu("Cores do Veículo", "Primary Colors");
            MenuController.AddSubmenu(customizeColorMenu, primaryColorsMenu);

            var primaryColorsBtn = new MenuItem("Cor Primária") { Label = "→→→" };
            customizeColorMenu.AddMenuItem(primaryColorsBtn);
            MenuController.BindMenuItem(customizeColorMenu, primaryColorsMenu, primaryColorsBtn);

            // secondary menu
            var secondaryColorsMenu = new Menu("Cores do Veículo", "Secondary Colors");
            MenuController.AddSubmenu(customizeColorMenu, secondaryColorsMenu);

            var secondaryColorsBtn = new MenuItem("Cor Secundária") { Label = "→→→" };
            customizeColorMenu.AddMenuItem(secondaryColorsBtn);
            MenuController.BindMenuItem(customizeColorMenu, secondaryColorsMenu, secondaryColorsBtn);

            var presetColorsBtn = new MenuListItem("Preset Colors", [], 0);
            customizeColorMenu.AddMenuItem(presetColorsBtn);

            var chrome = new MenuItem("Chrome");
            customizeColorMenu.AddMenuItem(chrome);

            // color lists
            var classic = new List<string>();
            var matte = new List<string>();
            var metals = new List<string>();
            var util = new List<string>();
            var worn = new List<string>();
            var chameleon = new List<string>();
            var wheelColors = new List<string>() { "Padrão Todosoy" };

            // Just quick and dirty solution to put this in a new enclosed section so that we can still use 'i' as a counter in the other code parts.
            {
                var i = 0;
                foreach (var vc in VehicleData.ClassicColors)
                {
                    classic.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.ClassicColors.Count})");
                    i++;
                }

                i = 0;
                foreach (var vc in VehicleData.MatteColors)
                {
                    matte.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.MatteColors.Count})");
                    i++;
                }

                i = 0;
                foreach (var vc in VehicleData.MetalColors)
                {
                    metals.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.MetalColors.Count})");
                    i++;
                }

                i = 0;
                foreach (var vc in VehicleData.UtilColors)
                {
                    util.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.UtilColors.Count})");
                    i++;
                }

                i = 0;
                foreach (var vc in VehicleData.WornColors)
                {
                    worn.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.WornColors.Count})");
                    i++;
                }

                if (GetSettingsBool(Setting.vmenu_using_chameleon_colours))
                {
                    i = 0;
                    foreach (var vc in VehicleData.ChameleonColors)
                    {
                        chameleon.Add($"{GetLabelText(vc.label)} ({i + 1}/{VehicleData.ChameleonColors.Count})");
                        i++;
                    }
                }

                wheelColors.AddRange(classic);
            }

            var wheelColorsList = new MenuListItem("Cor das Rodas", wheelColors, 0);
            var dashColorList = new MenuListItem("Cor do Painel", classic, 0);
            var intColorList = new MenuListItem("Interior / Trim Cor", classic, 0);
            var vehicleEnveffScale = new MenuSliderItem("Veículo Enveff Scale", "This works em certain veículos somente, like o besra para example. It 'fades' certain paint layers.", 0, 20, 10, true);

            VehicleColorsMenu.AddMenuItem(vehicleEnveffScale);

            VehicleColorsMenu.OnSliderPositionChange += (m, sliderItem, oldPosition, newPosition, itemIndex) =>
            {
                var veh = GetVehicle();
                if (veh != null && veh.Driver == Game.PlayerPed && !veh.IsDead)
                {
                    if (sliderItem == vehicleEnveffScale)
                    {
                        SetVehicleEnveffScale(veh.Handle, newPosition / 20f);
                    }
                }
                else
                {
                    Notify.Error("Você precisa ser o motorista de um driveable veículo para alterar this slider.");
                }
            };

            VehicleColorsMenu.AddMenuItem(dashColorList);
            VehicleColorsMenu.AddMenuItem(intColorList);
            VehicleColorsMenu.AddMenuItem(wheelColorsList);

            VehicleColorsMenu.OnListIndexChange += HandleListIndexChanges;

            void HandleListIndexChanges(Menu sender, MenuListItem listItem, int oldIndex, int newIndex, int itemIndex)
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                {
                    var primaryColor = 0;
                    var secondaryColor = 0;
                    var pearlColor = 0;
                    var wheelColor = 0;
                    var dashColor = 0;
                    var intColor = 0;

                    GetVehicleColours(veh.Handle, ref primaryColor, ref secondaryColor);
                    GetVehicleExtraColours(veh.Handle, ref pearlColor, ref wheelColor);
                    GetVehicleDashboardColour(veh.Handle, ref dashColor);
                    GetVehicleInteriorColour(veh.Handle, ref intColor);

                    if (sender == primaryColorsMenu)
                    {
                        if (itemIndex == 2)
                        {
                            pearlColor = VehicleData.ClassicColors[newIndex].id;
                        }
                        else
                        {
                            pearlColor = 0;
                        }

                        switch (itemIndex)
                        {
                            case 0:
                            case 1:
                            case 2:
                                primaryColor = VehicleData.ClassicColors[newIndex].id;
                                break;
                            case 3:
                                primaryColor = VehicleData.MatteColors[newIndex].id;
                                break;
                            case 4:
                                primaryColor = VehicleData.MetalColors[newIndex].id;
                                break;
                            case 5:
                                primaryColor = VehicleData.UtilColors[newIndex].id;
                                break;
                            case 6:
                                primaryColor = VehicleData.WornColors[newIndex].id;
                                break;
                        }

                        if (GetSettingsBool(Setting.vmenu_using_chameleon_colours))
                        {
                            if (itemIndex == 7)
                            {
                                primaryColor = VehicleData.ChameleonColors[newIndex].id;
                                secondaryColor = VehicleData.ChameleonColors[newIndex].id;

                                SetVehicleModKit(veh.Handle, 0);
                            }
                        }

                        ClearVehicleCustomPrimaryColour(veh.Handle);
                        veh.State.Set("vMenu:PrimaryPaintFinish", null, true);
                        SetVehicleColours(veh.Handle, primaryColor, secondaryColor);
                    }
                    else if (sender == secondaryColorsMenu)
                    {
                        switch (itemIndex)
                        {
                            case 0:
                            case 1:
                                pearlColor = VehicleData.ClassicColors[newIndex].id;
                                break;
                            case 2:
                            case 3:
                                secondaryColor = VehicleData.ClassicColors[newIndex].id;
                                break;
                            case 4:
                                secondaryColor = VehicleData.MatteColors[newIndex].id;
                                break;
                            case 5:
                                secondaryColor = VehicleData.MetalColors[newIndex].id;
                                break;
                            case 6:
                                secondaryColor = VehicleData.UtilColors[newIndex].id;
                                break;
                            case 7:
                                secondaryColor = VehicleData.WornColors[newIndex].id;
                                break;
                        }

                        ClearVehicleCustomSecondaryColour(veh.Handle);
                        veh.State.Set("vMenu:SecondaryPaintFinish", null, true);
                        SetVehicleColours(veh.Handle, primaryColor, secondaryColor);
                    }
                    else if (sender == VehicleColorsMenu)
                    {
                        if (listItem == wheelColorsList)
                        {
                            if (newIndex == 0)
                            {
                                wheelColor = 156; // default alloy color.
                            }
                            else
                            {
                                wheelColor = VehicleData.ClassicColors[newIndex - 1].id;
                            }
                        }
                        else if (listItem == dashColorList)
                        {
                            dashColor = VehicleData.ClassicColors[newIndex].id;
                            // sadly these native names are mixed up :/ but ofc it's impossible to fix due to backwards compatibility.
                            // this should actually be called SetVehicleDashboardColour
                            SetVehicleInteriorColour(veh.Handle, dashColor);
                        }
                        else if (listItem == intColorList)
                        {
                            intColor = VehicleData.ClassicColors[newIndex].id;
                            // sadly these native names are mixed up :/ but ofc it's impossible to fix due to backwards compatibility.
                            // this should actually be called SetVehicleInteriorColour
                            SetVehicleDashboardColour(veh.Handle, intColor);
                        }
                    }

                    SetVehicleExtraColours(veh.Handle, pearlColor, wheelColor);
                }
                else
                {
                    Notify.Error("Você precisa ser o motorista de um veículo in order para alterar o veículo cors.");
                }
            }

            for (var i = 0; i < 2; i++)
            {
                var customColour = new MenuItem("Custom RGB") { Label = "→→→" };
                var pearlescentList = new MenuListItem("Pearlescent", classic, 0);
                var classicList = new MenuListItem("Classic", classic, 0);
                var metallicList = new MenuListItem("Metallic", classic, 0);
                var matteList = new MenuListItem("Matte", matte, 0);
                var metalList = new MenuListItem("Metals", metals, 0);
                var utilList = new MenuListItem("Util", util, 0);
                var wornList = new MenuListItem("Worn", worn, 0);

                if (i == 0)
                {
                    var customColourMenuPrimary = new Menu("Custom Colour", "Custom Veículo Colour");
                    primaryColorsMenu.AddMenuItem(customColour);
                    primaryColorsMenu.AddMenuItem(classicList);
                    primaryColorsMenu.AddMenuItem(metallicList);
                    primaryColorsMenu.AddMenuItem(matteList);
                    primaryColorsMenu.AddMenuItem(metalList);
                    primaryColorsMenu.AddMenuItem(utilList);
                    primaryColorsMenu.AddMenuItem(wornList);
                    MenuController.AddSubmenu(primaryColorsMenu, customColourMenuPrimary);
                    MenuController.BindMenuItem(primaryColorsMenu, customColourMenuPrimary, customColour);
                    

                    if (GetSettingsBool(Setting.vmenu_using_chameleon_colours))
                    {
                        var chameleonList = new MenuListItem("Chameleon", chameleon, 0);

                        primaryColorsMenu.AddMenuItem(chameleonList);
                    }
                    
                    CreateCustomColourMenu(customColourMenuPrimary, RGBType.primaryPaint);
                    primaryColorsMenu.OnListIndexChange += HandleListIndexChanges;
                }
                else
                {
                    var customColourMenuSecondary = new Menu("Custom Colour", "Custom Veículo Colour");
                    secondaryColorsMenu.AddMenuItem(customColour);
                    secondaryColorsMenu.AddMenuItem(pearlescentList);
                    secondaryColorsMenu.AddMenuItem(classicList);
                    secondaryColorsMenu.AddMenuItem(metallicList);
                    secondaryColorsMenu.AddMenuItem(matteList);
                    secondaryColorsMenu.AddMenuItem(metalList);
                    secondaryColorsMenu.AddMenuItem(utilList);
                    secondaryColorsMenu.AddMenuItem(wornList);
                    MenuController.AddSubmenu(secondaryColorsMenu, customColourMenuSecondary);
                    MenuController.BindMenuItem(secondaryColorsMenu, customColourMenuSecondary, customColour);

                    CreateCustomColourMenu(customColourMenuSecondary, RGBType.secondaryPaint);
                    secondaryColorsMenu.OnListIndexChange += HandleListIndexChanges;
                }
            }

            customizeColorMenu.OnMenuOpen += (_) =>
            {
                int numVehColors = GetNumberOfVehicleColours(GetVehicle().Handle);

                if (numVehColors == 0)
                {
                    presetColorsBtn.Enabled = false;
                    presetColorsBtn.ListItems = ["No Preset Colors"];
                    presetColorsBtn.ListIndex = 0;
                    return;
                }

                List<string> colorOptions = [];

                presetColorsBtn.Enabled = true;

                for (int i = 0; i < numVehColors; i++)
                {
                    colorOptions.Add($"Predefinir Cor #{i + 1}");
                }

                int currentColor = GetVehicleColourCombination(GetVehicle().Handle);

                presetColorsBtn.ListItems = colorOptions;
                presetColorsBtn.ListIndex = currentColor < 0 ? 0 : currentColor;
            };

            customizeColorMenu.OnItemSelect += (_, item, _) =>
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                {
                    if (item == chrome)
                    {
                        SetVehicleColours(veh.Handle, 120, 120); // chrome is index 120
                    }
                }
                else
                {
                    Notify.Error("Você precisa ser o motorista de um driveable veículo para alterar this.");
                }
            };

            customizeColorMenu.OnListItemSelect += (_, _, index, _) => ChangeVehiclePresetColor(index);

            customizeColorMenu.OnListIndexChange += (_, _, _, index, _) => ChangeVehiclePresetColor(index);

            void ChangeVehiclePresetColor(int index)
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                {
                    SetVehicleColourCombination(veh.Handle, index);
                }
                else
                {
                    Notify.Error("Você precisa ser o motorista de um driveable veículo para alterar this.");
                }
            }
            #endregion

            #region Vehicle Doors Submenu Stuff
            var openAll = new MenuItem("Abrir Todas as Portas", "Abrir todos veículo portas.");
            var closeAll = new MenuItem("Fechar Todas as Portas", "Fechar todos veículo portas.");
            var LF = new MenuItem("Porta Dianteira Esquerda", "Abrir/fechar o esquerda dianteira porta.");
            var RF = new MenuItem("Porta Dianteira Direita", "Abrir/fechar o direita dianteira porta.");
            var LR = new MenuItem("Porta Traseira Esquerda", "Abrir/fechar o esquerda traseira porta.");
            var RR = new MenuItem("Porta Traseira Direita", "Abrir/fechar o direita traseira porta.");
            var HD = new MenuItem("Hood", "Abrir/fechar o hood.");
            var TR = new MenuItem("Trunk", "Abrir/fechar o trunk.");
            var E1 = new MenuItem("Extra 1", "Abrir/fechar o extra porta (#1). Nãote this porta é não present em most veículos.");
            var E2 = new MenuItem("Extra 2", "Abrir/fechar o extra porta (#2). Nãote this porta é não present em most veículos.");
            var BB = new MenuItem("Bomb Bay", "Abrir/fechar o bomb bay. Only disponível em some planes.");
            var doors = new List<string>() { "Dianteira Esquerda", "Dianteira Direita", "Traseira Esquerda", "Traseira Direita", "Hood", "Trunk", "Extra 1", "Extra 2" };
            var removeDoorList = new MenuListItem("Remover Porta", doors, 0, "Remover um specific veículo porta completely.");
            var deleteDoors = new MenuCheckboxItem("Excluir Portas Removidas", "When ativard, portas that you remover using o list above will ser excluird de o mundo. If desativard, then o portas will just ftodos em o ground.", false);

            VehicleDoorsMenu.AddMenuItem(LF);
            VehicleDoorsMenu.AddMenuItem(RF);
            VehicleDoorsMenu.AddMenuItem(LR);
            VehicleDoorsMenu.AddMenuItem(RR);
            VehicleDoorsMenu.AddMenuItem(HD);
            VehicleDoorsMenu.AddMenuItem(TR);
            VehicleDoorsMenu.AddMenuItem(E1);
            VehicleDoorsMenu.AddMenuItem(E2);
            VehicleDoorsMenu.AddMenuItem(BB);
            VehicleDoorsMenu.AddMenuItem(openAll);
            VehicleDoorsMenu.AddMenuItem(closeAll);
            VehicleDoorsMenu.AddMenuItem(removeDoorList);
            VehicleDoorsMenu.AddMenuItem(deleteDoors);

            VehicleDoorsMenu.OnListItemSelect += (sender, item, index, itemIndex) =>
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists())
                {
                    if (veh.Driver == Game.PlayerPed)
                    {
                        if (item == removeDoorList)
                        {
                            SetVehicleDoorBroken(veh.Handle, index, deleteDoors.Checked);
                        }
                    }
                    else
                    {
                        Notify.Error(CommonErrors.NeedToBeTheDriver);
                    }
                }
                else
                {
                    Notify.Error(CommonErrors.NoVehicle);
                }
            };

            // Handle button presses.
            VehicleDoorsMenu.OnItemSelect += (sender, item, index) =>
            {
                // Get the vehicle.
                var veh = GetVehicle();
                // If the player is in a vehicle, it's not dead and the player is the driver, continue.
                if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                {
                    // If button 0-5 are pressed, then open/close that specific index/door.
                    if (index < 8)
                    {
                        // If the door is open.
                        var open = GetVehicleDoorAngleRatio(veh.Handle, index) > 0.1f;

                        if (open)
                        {
                            // Close the door.
                            SetVehicleDoorShut(veh.Handle, index, false);
                        }
                        else
                        {
                            // Open the door.
                            SetVehicleDoorOpen(veh.Handle, index, false, false);
                        }
                    }
                    // If the index >= 8, and the button is "openAll": open all doors.
                    else if (item == openAll)
                    {
                        // Loop through all doors and open them.
                        for (var door = 0; door < 8; door++)
                        {
                            SetVehicleDoorOpen(veh.Handle, door, false, false);
                        }
                        if (veh.HasBombBay)
                        {
                            veh.OpenBombBay();
                        }
                    }
                    // If the index >= 8, and the button is "closeAll": close all doors.
                    else if (item == closeAll)
                    {
                        // Close all doors.
                        SetVehicleDoorsShut(veh.Handle, false);
                        if (veh.HasBombBay)
                        {
                            veh.CloseBombBay();
                        }
                    }
                    // If bomb bay doors button is pressed and the vehicle has bomb bay doors.
                    else if (item == BB && veh.HasBombBay)
                    {
                        var bombBayOpen = AreBombBayDoorsOpen(veh.Handle);
                        // If open, close them.
                        if (bombBayOpen)
                        {
                            veh.CloseBombBay();
                        }
                        // Otherwise, open them.
                        else
                        {
                            veh.OpenBombBay();
                        }
                    }
                }
                else
                {
                    Notify.Alert(CommonErrors.NoVehicle, placeholderValue: "para abrir/fechar um veículo porta");
                }
            };

            #endregion

            #region Vehicle Windows Submenu Stuff
            var fwu = new MenuItem("~y~↑~s~ Roll Dianteira Janelas Up", "Roll both dianteira janelas up.");
            var fwd = new MenuItem("~o~↓~s~ Roll Dianteira Janelas Down", "Roll both dianteira janelas down.");
            var rwu = new MenuItem("~y~↑~s~ Roll Traseira Janelas Up", "Roll both traseira janelas up.");
            var rwd = new MenuItem("~o~↓~s~ Roll Traseira Janelas Down", "Roll both traseira janelas down.");
            VehicleWindowsMenu.AddMenuItem(fwu);
            VehicleWindowsMenu.AddMenuItem(fwd);
            VehicleWindowsMenu.AddMenuItem(rwu);
            VehicleWindowsMenu.AddMenuItem(rwd);
            VehicleWindowsMenu.OnItemSelect += (sender, item, index) =>
            {
                var veh = GetVehicle();
                if (veh != null && veh.Exists() && !veh.IsDead)
                {
                    if (item == fwu)
                    {
                        RollUpWindow(veh.Handle, 0);
                        RollUpWindow(veh.Handle, 1);
                    }
                    else if (item == fwd)
                    {
                        RollDownWindow(veh.Handle, 0);
                        RollDownWindow(veh.Handle, 1);
                    }
                    else if (item == rwu)
                    {
                        RollUpWindow(veh.Handle, 2);
                        RollUpWindow(veh.Handle, 3);
                    }
                    else if (item == rwd)
                    {
                        RollDownWindow(veh.Handle, 2);
                        RollDownWindow(veh.Handle, 3);
                    }
                }
            };
            #endregion

            #region Vehicle Liveries Submenu Stuff
            menu.OnItemSelect += (sender, item, idex) =>
            {
                // If the liverys menu button is selected.
                if (item == liveriesMenuBtn)
                {
                    // Get the player's vehicle.
                    var veh = GetVehicle();
                    // If it exists, isn't dead and the player is in the drivers seat continue.
                    if (veh != null && veh.Exists() && !veh.IsDead)
                    {
                        if (veh.Driver == Game.PlayerPed)
                        {
                            VehicleLiveriesMenu.ClearMenuItems();
                            SetVehicleModKit(veh.Handle, 0);
                            var liveryCount = GetVehicleLiveryCount(veh.Handle);

                            if (liveryCount > 0)
                            {
                                var liveryList = new List<string>();
                                for (var i = 0; i < liveryCount; i++)
                                {
                                    var livery = GetLiveryName(veh.Handle, i);
                                    livery = GetLabelText(livery) != "NULL" ? GetLabelText(livery) : $"Livery #{i}";
                                    liveryList.Add(livery);
                                }
                                var liveryListItem = new MenuListItem("Definir Livery", liveryList, GetVehicleLivery(veh.Handle), "Escolha um livery para este veículo.");
                                VehicleLiveriesMenu.AddMenuItem(liveryListItem);
                                VehicleLiveriesMenu.OnListIndexChange += (_menu, listItem, oldIndex, newIndex, itemIndex) =>
                                {
                                    if (listItem == liveryListItem)
                                    {
                                        veh = GetVehicle();
                                        SetVehicleLivery(veh.Handle, newIndex);
                                    }
                                };
                                VehicleLiveriesMenu.RefreshIndex();
                                //VehicleLiveriesMenu.UpdateScaleform();
                            }
                            else
                            {
                                Notify.Error("Este veículo does não have any liveries.");
                                VehicleLiveriesMenu.CloseMenu();
                                menu.OpenMenu();
                                var backBtn = new MenuItem("Não Liveries Disponível :(", "Click me para go back.")
                                {
                                    Label = "Go Back"
                                };
                                VehicleLiveriesMenu.AddMenuItem(backBtn);
                                VehicleLiveriesMenu.OnItemSelect += (sender2, item2, index2) =>
                                {
                                    if (item2 == backBtn)
                                    {
                                        VehicleLiveriesMenu.GoBack();
                                    }
                                };

                                VehicleLiveriesMenu.RefreshIndex();
                                //VehicleLiveriesMenu.UpdateScaleform();
                            }
                        }
                        else
                        {
                            Notify.Error("You have para ser o motorista de um veículo para access this menu.");
                        }
                    }
                    else
                    {
                        Notify.Error("You have para ser o motorista de um veículo para access this menu.");
                    }
                }
            };
            #endregion

            #region Vehicle Mod Submenu Stuff
            menu.OnItemSelect += (sender, item, index) =>
            {
                // When the mod submenu is openend, reset all items in there.
                if (item == modMenuBtn)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        UpdateMods();
                    }
                    else
                    {
                        VehicleModMenu.CloseMenu();
                        menu.OpenMenu();
                    }

                }
            };
            #endregion

            #region Vehicle Components Submenu
            // when the components menu is opened.
            menu.OnItemSelect += (sender, item, index) =>
            {
                // If the components menu is opened.
                if (item == componentsMenuBtn)
                {
                    // Empty the menu in case there were leftover buttons from another vehicle.
                    if (VehicleComponentsMenu.Size > 0)
                    {
                        VehicleComponentsMenu.ClearMenuItems();
                        vehicleExtras.Clear();
                        VehicleComponentsMenu.RefreshIndex();
                        //VehicleComponentsMenu.UpdateScaleform();
                    }

                    // Get the vehicle.
                    var veh = GetVehicle();

                    // Check if the vehicle exists, it's actually a vehicle, it's not dead/broken and the player is in the drivers seat.
                    if (veh != null && veh.Exists() && !veh.IsDead && veh.Driver == Game.PlayerPed)
                    {
                        Dictionary<int, string> extraLabels;
                        if (!VehicleExtras.TryGetValue((uint)veh.Model.Hash, out extraLabels))
                        {
                            extraLabels = new Dictionary<int, string>();
                        }
                      
                        //List<int> extraIds = new List<int>();
                        // Loop through all possible extra ID's (AFAIK: 0-14).
                        for (var extra = 0; extra < 14; extra++)
                        {
                            // If this extra exists...
                            if (veh.ExtraExists(extra))
                            {
                                // Add it's ID to the list.
                                //extraIds.Add(extra);

                                // Create the checkbox label
                                string extraLabel;
                                if (!extraLabels.TryGetValue(extra, out extraLabel))
                                    extraLabel = $"Extra #{extra}";
                                // Create a checkbox for it.
                                var extraCheckbox = new MenuCheckboxItem(extraLabel, extra.ToString(), veh.IsExtraOn(extra));
                                // Add the checkbox to the menu.
                                VehicleComponentsMenu.AddMenuItem(extraCheckbox);

                                // Add it's ID to the dictionary.
                                vehicleExtras[extraCheckbox] = extra;
                            }
                        }



                        if (vehicleExtras.Count > 0)
                        {
                            var backBtn = new MenuItem("Go Back", "Go back para o Opções do Veículo menu.");
                            VehicleComponentsMenu.AddMenuItem(backBtn);
                            VehicleComponentsMenu.OnItemSelect += (sender3, item3, index3) =>
                            {
                                VehicleComponentsMenu.GoBack();
                            };
                        }
                        else
                        {
                            var backBtn = new MenuItem("Não Extras Disponível :(", "Go back para o Opções do Veículo menu.")
                            {
                                Label = "Go Back"
                            };
                            VehicleComponentsMenu.AddMenuItem(backBtn);
                            VehicleComponentsMenu.OnItemSelect += (sender3, item3, index3) =>
                            {
                                VehicleComponentsMenu.GoBack();
                            };
                        }
                        // And update the submenu to prevent weird glitches.
                        VehicleComponentsMenu.RefreshIndex();
                        //VehicleComponentsMenu.UpdateScaleform();

                    }
                }
            };

            // Disable all extra options if vehicle is too damaged
            VehicleComponentsMenu.OnMenuOpen += (menu) =>
            {
                Vehicle vehicle;
                bool checkDamageBeforeChangingExtras = GetSettingsBool(Setting.vmenu_prevent_extras_when_damaged) && !IsAllowed(Permission.VOBypassExtraDamage);

                if (!checkDamageBeforeChangingExtras || !Entity.Exists(vehicle = GetVehicle()))
                {
                    return;
                }

                List<MenuItem> menuItems = menu.GetMenuItems();
                bool isTooDamaged = IsVehicleTooDamagedToChangeExtras(vehicle);

                menu.ClearMenuItems();

                if (isTooDamaged && !menuItems.Exists(i => i.Text.Contains("too damaged")))
                {
                    MenuItem spacer = GetSpacerMenuItem("Veículo too danod!", "Veículo é too danod para alterar extras, repair it primeiro!");

                    // Place at the start of the menu
                    menuItems.Insert(0, spacer);
                }

                foreach (MenuItem item in menuItems)
                {
                    // Check for spacer
                    if (item.Text.Contains("too damaged"))
                    {
                        if (!isTooDamaged)
                        {
                            continue;
                        }
                    }
                    else if (item.Text != "Go Back")
                    {
                        item.Enabled = !isTooDamaged;
                    }

                    menu.AddMenuItem(item);
                }

                menu.RefreshIndex();
            };

            // when a checkbox in the components menu changes
            VehicleComponentsMenu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                // When a checkbox is checked/unchecked, get the selected checkbox item index and use that to get the component ID from the list.
                // Then toggle that extra.
                if (vehicleExtras.TryGetValue(item, out var extra))
                {
                    var veh = GetVehicle();

                    if (!Entity.Exists(veh))
                    {
                        Notify.Error(CommonErrors.NoVehicle);
                        return;
                    }

                    bool checkDamageBeforeChangingExtras = GetSettingsBool(Setting.vmenu_prevent_extras_when_damaged) && !IsAllowed(Permission.VOBypassExtraDamage);

                    if (checkDamageBeforeChangingExtras)
                    {
                        bool isTooDamaged = IsVehicleTooDamagedToChangeExtras(veh);

                        if (isTooDamaged)
                        {
                            // Send message to player when extra change is denied
                            Notify.Alert("Veículo é too danod para alterar extra, repair it primeiro!", true, false);

                            // Send to previous menu
                            VehicleComponentsMenu.GoBack();
                            return;
                        }
                    }

                    veh.ToggleExtra(extra, _checked);
                }
            };
            #endregion

            #region Underglow Submenu
            var underglowFront = new MenuCheckboxItem("Ativar Dianteira Light", "Ative ou desative o underglow em o dianteira side de o veículo. Nãote não todos veículos have lights.", false);
            var underglowBack = new MenuCheckboxItem("Ativar Traseira Light", "Ative ou desative o underglow em o esquerda side de o veículo. Nãote não todos veículos have lights.", false);
            var underglowLeft = new MenuCheckboxItem("Ativar Esquerda Light", "Ative ou desative o underglow em o direita side de o veículo. Nãote não todos veículos have lights.", false);
            var underglowRight = new MenuCheckboxItem("Ativar Direita Light", "Ative ou desative o underglow em o back side de o veículo. Nãote não todos veículos have lights.", false);
            var underglowColorsList = new List<string>();
            for (var i = 0; i < 13; i++)
            {
                underglowColorsList.Add(GetLabelText($"CMOD_NEONCOL_{i}"));
            }
            var underglowColor = new MenuListItem(GetLabelText("CMOD_NEON_1"), underglowColorsList, 0, "Selecione o cor de o neon underglow.");

            VehicleUnderglowMenu.AddMenuItem(underglowFront);
            VehicleUnderglowMenu.AddMenuItem(underglowBack);
            VehicleUnderglowMenu.AddMenuItem(underglowLeft);
            VehicleUnderglowMenu.AddMenuItem(underglowRight);

            VehicleUnderglowMenu.AddMenuItem(underglowColor);

            CreateCustomColourMenu(VehicleUnderglowMenu, RGBType.underglow);
            menu.OnItemSelect += (sender, item, index) =>
            {
                #region reset checkboxes state when opening the menu.
                if (item == underglowMenuBtn)
                {
                    var veh = GetVehicle();
                    if (veh != null)
                    {
                        if (veh.Mods.HasNeonLights)
                        {
                            underglowFront.Checked = veh.Mods.HasNeonLight(VehicleNeonLight.Front) && veh.Mods.IsNeonLightsOn(VehicleNeonLight.Front);
                            underglowBack.Checked = veh.Mods.HasNeonLight(VehicleNeonLight.Back) && veh.Mods.IsNeonLightsOn(VehicleNeonLight.Back);
                            underglowLeft.Checked = veh.Mods.HasNeonLight(VehicleNeonLight.Left) && veh.Mods.IsNeonLightsOn(VehicleNeonLight.Left);
                            underglowRight.Checked = veh.Mods.HasNeonLight(VehicleNeonLight.Right) && veh.Mods.IsNeonLightsOn(VehicleNeonLight.Right);

                            underglowFront.Enabled = true;
                            underglowBack.Enabled = true;
                            underglowLeft.Enabled = true;
                            underglowRight.Enabled = true;

                            underglowFront.LeftIcon = MenuItem.Icon.NONE;
                            underglowBack.LeftIcon = MenuItem.Icon.NONE;
                            underglowLeft.LeftIcon = MenuItem.Icon.NONE;
                            underglowRight.LeftIcon = MenuItem.Icon.NONE;
                        }
                        else
                        {
                            underglowFront.Checked = false;
                            underglowBack.Checked = false;
                            underglowLeft.Checked = false;
                            underglowRight.Checked = false;

                            underglowFront.Enabled = false;
                            underglowBack.Enabled = false;
                            underglowLeft.Enabled = false;
                            underglowRight.Enabled = false;

                            underglowFront.LeftIcon = MenuItem.Icon.LOCK;
                            underglowBack.LeftIcon = MenuItem.Icon.LOCK;
                            underglowLeft.LeftIcon = MenuItem.Icon.LOCK;
                            underglowRight.LeftIcon = MenuItem.Icon.LOCK;
                        }
                    }
                    else
                    {
                        underglowFront.Checked = false;
                        underglowBack.Checked = false;
                        underglowLeft.Checked = false;
                        underglowRight.Checked = false;

                        underglowFront.Enabled = false;
                        underglowBack.Enabled = false;
                        underglowLeft.Enabled = false;
                        underglowRight.Enabled = false;

                        underglowFront.LeftIcon = MenuItem.Icon.LOCK;
                        underglowBack.LeftIcon = MenuItem.Icon.LOCK;
                        underglowLeft.LeftIcon = MenuItem.Icon.LOCK;
                        underglowRight.LeftIcon = MenuItem.Icon.LOCK;
                    }

                    underglowColor.ListIndex = GetIndexFromColor();
                }
                #endregion
            };
            // handle item selections
            VehicleUnderglowMenu.OnCheckboxChange += (sender, item, index, _checked) =>
            {
                if (Game.PlayerPed.IsInVehicle())
                {
                    var veh = GetVehicle();
                    if (veh.Mods.HasNeonLights)
                    {
                        veh.Mods.NeonLightsColor = GetColorFromIndex(underglowColor.ListIndex);
                        if (item == underglowLeft)
                        {
                            veh.Mods.SetNeonLightsOn(VehicleNeonLight.Left, veh.Mods.HasNeonLight(VehicleNeonLight.Left) && _checked);
                        }
                        else if (item == underglowRight)
                        {
                            veh.Mods.SetNeonLightsOn(VehicleNeonLight.Right, veh.Mods.HasNeonLight(VehicleNeonLight.Right) && _checked);
                        }
                        else if (item == underglowBack)
                        {
                            veh.Mods.SetNeonLightsOn(VehicleNeonLight.Back, veh.Mods.HasNeonLight(VehicleNeonLight.Back) && _checked);
                        }
                        else if (item == underglowFront)
                        {
                            veh.Mods.SetNeonLightsOn(VehicleNeonLight.Front, veh.Mods.HasNeonLight(VehicleNeonLight.Front) && _checked);
                        }
                    }
                }
            };

            VehicleUnderglowMenu.OnListIndexChange += (sender, item, oldIndex, newIndex, itemIndex) =>
            {
                if (item == underglowColor)
                {
                    if (Game.PlayerPed.IsInVehicle())
                    {
                        var veh = GetVehicle();
                        if (veh.Mods.HasNeonLights)
                        {
                            veh.Mods.NeonLightsColor = GetColorFromIndex(newIndex);
                        }
                    }
                }
            };
            #endregion

            #region Handle menu-opening refreshing license plate
            menu.OnMenuOpen += (sender) =>
            {
                menu.GetMenuItems().ForEach((item) =>
                {
                    var veh = GetVehicle(true);

                    if (item == setLicensePlateType && item is MenuListItem listItem && veh != null && veh.Exists())
                    {
                        // Set the license plate style.
                        switch (veh.Mods.LicensePlateStyle)
                        {
                            case LicensePlateStyle.BlueOnWhite1:
                                listItem.ListIndex = 0;
                                break;
                            case LicensePlateStyle.BlueOnWhite2:
                                listItem.ListIndex = 1;
                                break;
                            case LicensePlateStyle.BlueOnWhite3:
                                listItem.ListIndex = 2;
                                break;
                            case LicensePlateStyle.YellowOnBlue:
                                listItem.ListIndex = 3;
                                break;
                            case LicensePlateStyle.YellowOnBlack:
                                listItem.ListIndex = 4;
                                break;
                            case LicensePlateStyle.NorthYankton:
                                listItem.ListIndex = 5;
                                break;
                            case LicensePlateStyle.ECola:
                                listItem.ListIndex = 6;
                                break;
                            case LicensePlateStyle.LasVenturas:
                                listItem.ListIndex = 7;
                                break;
                            case LicensePlateStyle.LibertyCity:
                                listItem.ListIndex = 8;
                                break;
                            case LicensePlateStyle.LSCarMeet:
                                listItem.ListIndex = 9;
                                break;
                            case LicensePlateStyle.LSPanic:
                                listItem.ListIndex = 10;
                                break;
                            case LicensePlateStyle.LSPounders:
                                listItem.ListIndex = 11;
                                break;
                            case LicensePlateStyle.Sprunk:
                                listItem.ListIndex = 12;
                                break;
                            default:
                                break;
                        }
                    }
                });
            };
            #endregion

        }
        #endregion

        /// <summary>
        /// Public get method for the menu. Checks if the menu exists, if not create the menu first.
        /// </summary>
        /// <returns>Returns the Vehicle Options menu.</returns>
        public Menu GetMenu()
        {
            // If menu doesn't exist. Create one.
            if (menu == null)
            {
                CreateMenu();
            }
            // Return the menu.
            return menu;
        }

        #region Update Vehicle Mods Menu
        /// <summary>
        /// Refreshes the mods page. The selectedIndex allows you to go straight to a specific index after refreshing the menu.
        /// This is used because when the wheel type is changed, the menu is refreshed to update the available wheels list.
        /// </summary>
        /// <param name="selectedIndex">Pass this if you want to go straight to a specific mod/index.</param>
        public void UpdateMods(int selectedIndex = 0)
        {
            // If there are items, remove all of them.
            if (VehicleModMenu.Size > 0)
            {
                if (selectedIndex != 0)
                {
                    VehicleModMenu.ClearMenuItems(true);
                }
                else
                {
                    VehicleModMenu.ClearMenuItems(false);
                }

            }

            // Get the vehicle.
            var veh = GetVehicle();

            // Check if the vehicle exists, is still drivable/alive and it's actually a vehicle.
            if (veh != null && veh.Exists() && !veh.IsDead)
            {
                #region initial setup & dynamic vehicle mods setup
                // Set the modkit so we can modify the car.
                SetVehicleModKit(veh.Handle, 0);

                // Get all mods available on this vehicle.
                var mods = GetAllVehicleMods(veh);

                // Loop through all the mods.
                foreach (var mod in mods)
                {
                    veh = GetVehicle();

                    // Get the proper localized mod type (suspension, armor, etc) name.
                    var rawLabel = GetModSlotName(veh.Handle, (int)mod.ModType);
                    var resolvedLabel = !string.IsNullOrEmpty(rawLabel) ? GetLabelText(rawLabel) : null;
                    if (resolvedLabel == "NULL") { resolvedLabel = null; }
                    var typeName = resolvedLabel ?? mod.LocalizedModTypeName ?? rawLabel;

                    // Create a list to all available upgrades for this modtype.
                    var modlist = new List<string>();

                    // Get the current item index ({current}/{max upgrades})
                    var currentItem = $"[1/{mod.ModCount + 1}]";

                    // Add the stock value for this mod.
                    var name = $"Stock {typeName} {currentItem}";
                    modlist.Add(name);

                    // Loop through all available upgrades for this specific mod type.
                    for (var x = 0; x < mod.ModCount; x++)
                    {
                        // Create the item index.
                        currentItem = $"[{2 + x}/{mod.ModCount + 1}]";

                        // Create the name (again, converting to proper case), then add the name.
                        name = mod.GetLocalizedModName(x) != "" ? $"{ToProperString(mod.GetLocalizedModName(x))} {currentItem}" : $"{typeName} #{x} {currentItem}";
                        modlist.Add(name);
                    }

                    // Create the MenuListItem for this mod type.
                    var currIndex = GetVehicleMod(veh.Handle, (int)mod.ModType) + 1;
                    var modTypeListItem = new MenuListItem(
                        typeName,
                        modlist,
                        currIndex,
                        $"Escolha um ~y~{typeName}~s~ upgrade, it will ser automatictodosy applied para seu veículo."
                    )
                    {
                        ItemData = (int)mod.ModType
                    };

                    // Add the list item to the menu.
                    VehicleModMenu.AddMenuItem(modTypeListItem);
                }
                #endregion

                #region more variables and setup
                veh = GetVehicle();
                // Create the wheel types list & listitem and add it to the menu.
                var wheelTypes = new List<string>()
                {
                    "Sports",       // 0
                    "Muscle",       // 1
                    "Lowrider",     // 2
                    "SUV",          // 3
                    "Offroad",      // 4
                    "Tuner",        // 5
                    "Bike Wheels",  // 6
                    "High End",     // 7
                    "Benny's (1)",  // 8
                    "Benny's (2)",  // 9
                    "Abrir Wheel",   // 10
                    "Street",       // 11
                    "Track"         // 12    
                };
                var vehicleWheelType = new MenuListItem("Wheel Type", wheelTypes, MathUtil.Clamp(GetVehicleWheelType(veh.Handle), 0, 12), $"Escolha um ~y~wheel type~s~ para seu veículo.");
                if (!veh.Model.IsBoat && !veh.Model.IsHelicopter && !veh.Model.IsPlane && !veh.Model.IsBicycle && !veh.Model.IsTrain)
                {
                    VehicleModMenu.AddMenuItem(vehicleWheelType);
                }

                var headlightsButton = new MenuItem("Headlights");
                var headlightsMenu = new Menu("Headlights", "headlights");
                var xenonHeadlights = new MenuCheckboxItem("Xenon Headlights", "Ative ou desative ~b~xenon ~s~headlights.", IsToggleModOn(veh.Handle, 22));
                headlightsMenu.AddMenuItem(xenonHeadlights);
                var currentHeadlightColor = GetHeadlightsColorForVehicle(veh);
                if (currentHeadlightColor is < 0 or > 12)
                {
                    currentHeadlightColor = 13;
                }
                var headlightColor = new MenuListItem("Headlight Cor", new List<string>() { "White", "Blue", "Electric Blue", "Mint Green", "Lime Green", "Yellow", "Golden Shower", "Orange", "Red", "Pony Pink", "Hot Pink", "Purple", "Blacklight", "Padrão Xenon" }, currentHeadlightColor, "Novo in o Arena Wars GTA V update: Cored headlights. Nãote você deve ativar Xenon Headlights primeiro.");
                headlightsMenu.AddMenuItem(headlightColor);
                headlightsMenu.OnCheckboxChange += (sender2, item2, index2, _checked) =>
                {
                    veh = GetVehicle();

                    // Xenon Headlights
                    if (item2 == xenonHeadlights)
                    {
                        ToggleVehicleMod(veh.Handle, 22, _checked);
                    }
                };
                headlightsMenu.OnListIndexChange += (sender2, item2, oldIndex, newIndex, itemIndex) =>
                {
                    veh = GetVehicle();
                    if (item2 == headlightColor)
                    {
                        if (newIndex == 13) // default
                        {
                            SetHeadlightsColorForVehicle(veh, 255);
                        }
                        else if (newIndex is > (-1) and < 13)
                        {
                            ClearVehicleXenonLightsCustomColor(veh.Handle);
                            SetHeadlightsColorForVehicle(veh, newIndex);
                        }
                    }
                };
                MenuController.AddSubmenu(VehicleModMenu, headlightsMenu);
                MenuController.BindMenuItem(VehicleModMenu, headlightsMenu, headlightsButton);
                VehicleModMenu.AddMenuItem(headlightsButton);
                CreateCustomColourMenu(headlightsMenu, RGBType.headlight);


                // Create the checkboxes for some options.
                var toggleCustomWheels = new MenuCheckboxItem("Alternar Rodas Personalizadas", "Press this para add ou remover ~y~custom~s~ wheels.", GetVehicleModVariation(veh.Handle, 23));
                var turbo = new MenuCheckboxItem("Turbo", "Ative ou desative o ~y~turbo~s~ para este veículo.", IsToggleModOn(veh.Handle, 18));
                var bulletProofTires = new MenuCheckboxItem("Bullet Proof Tires", "Ative ou desative ~y~bullet proof tires~s~ para este veículo.", !GetVehicleTyresCanBurst(veh.Handle));

            

                // Add the checkboxes to the menu.
                VehicleModMenu.AddMenuItem(toggleCustomWheels);
                VehicleModMenu.AddMenuItem(turbo);
                VehicleModMenu.AddMenuItem(bulletProofTires);

                bool isLowGripAvailable = GetGameBuildNumber() >= 2372;
                var lowGripTires = new MenuCheckboxItem("Low Grip Tires", "Ative ou desative ~y~low grip tires~s~ para este veículo.", isLowGripAvailable ? GetDriftTyresEnabled(veh.Handle) : false);
                if (isLowGripAvailable)
                {
                    VehicleModMenu.AddMenuItem(lowGripTires);
                }

                var tireSmokeButton = new MenuItem("Tire Smoke");
                var tireSmokeMenu = new Menu("Tire Smoke", "Tire Smoke");
                // Create a list of tire smoke options.
                var tireSmokes = new List<string>() { "Red", "Orange", "Yellow", "Gold", "Light Green", "Dark Green", "Light Blue", "Dark Blue", "Purple", "Pink", "Black" };
                var tireSmokeColors = new Dictionary<string, int[]>()
                {
                    ["Red"] = new int[] { 244, 65, 65 },
                    ["Orange"] = new int[] { 244, 167, 66 },
                    ["Yellow"] = new int[] { 244, 217, 65 },
                    ["Gold"] = new int[] { 181, 120, 0 },
                    ["Light Green"] = new int[] { 158, 255, 84 },
                    ["Dark Green"] = new int[] { 44, 94, 5 },
                    ["Light Blue"] = new int[] { 65, 211, 244 },
                    ["Dark Blue"] = new int[] { 24, 54, 163 },
                    ["Purple"] = new int[] { 108, 24, 192 },
                    ["Pink"] = new int[] { 192, 24, 172 },
                    ["Black"] = new int[] { 1, 1, 1 }
                };
                int smoker = 0, smokeg = 0, smokeb = 0;
                GetVehicleTyreSmokeColor(veh.Handle, ref smoker, ref smokeg, ref smokeb);
                var item = tireSmokeColors.ToList().Find((f) => { return f.Value[0] == smoker && f.Value[1] == smokeg && f.Value[2] == smokeb; });
                var index = tireSmokeColors.ToList().IndexOf(item);
                if (index < 0)
                {
                    index = 0;
                }

                var tireSmoke = new MenuListItem("Tire Smoke Cor", tireSmokes, index, $"Escolha um ~y~tire smoke cor~s~ para seu veículo.");
                tireSmokeMenu.AddMenuItem(tireSmoke);

                // Create the checkbox to enable/disable the tiresmoke.
                var tireSmokeEnabled = new MenuCheckboxItem("Tire Smoke", "Ative ou desative ~y~tire smoke~s~ para seu veículo. ~h~~r~Important:~s~ When disabling tire smoke, you'll need para drive around before it takes affect.", IsToggleModOn(veh.Handle, 20));
                tireSmokeMenu.AddMenuItem(tireSmokeEnabled);


                tireSmokeMenu.OnCheckboxChange += (sender2, item2, index2, _checked) =>
                {
                    veh = GetVehicle();

                    // Toggle Tire Smoke
                    if (item2 == tireSmokeEnabled)
                    {
                        // If it should be enabled:
                        if (_checked)
                        {
                            // Enable it.
                            ToggleVehicleMod(veh.Handle, 20, true);
                            // Get the selected color values.
                            var r = tireSmokeColors[tireSmokes[tireSmoke.ListIndex]][0];
                            var g = tireSmokeColors[tireSmokes[tireSmoke.ListIndex]][1];
                            var b = tireSmokeColors[tireSmokes[tireSmoke.ListIndex]][2];
                            // Set the color.
                            SetVehicleTyreSmokeColor(veh.Handle, r, g, b);
                        }
                        // If it should be disabled:
                        else
                        {
                            // Set the smoke to white.
                            SetVehicleTyreSmokeColor(veh.Handle, 255, 255, 255);
                            // Disable it.
                            ToggleVehicleMod(veh.Handle, 20, false);
                            // Remove the mod.
                            RemoveVehicleMod(veh.Handle, 20);
                        }
                    }
                };
                tireSmokeMenu.OnListIndexChange += (sender2, item2, oldIndex, newIndex, itemIndex) =>
                {
                    // Get the vehicle and set the mod kit.
                    veh = GetVehicle();
                    SetVehicleModKit(veh.Handle, 0);

                    // Tire smoke
                    if (item2 == tireSmoke)
                    {
                        // Get the selected color values.
                        var r = tireSmokeColors[tireSmokes[newIndex]][0];
                        var g = tireSmokeColors[tireSmokes[newIndex]][1];
                        var b = tireSmokeColors[tireSmokes[newIndex]][2];

                        // Set the color.
                        SetVehicleTyreSmokeColor(veh.Handle, r, g, b);
                    }
                };

                MenuController.AddSubmenu(VehicleModMenu, tireSmokeMenu);
                MenuController.BindMenuItem(VehicleModMenu, tireSmokeMenu, tireSmokeButton);
                VehicleModMenu.AddMenuItem(tireSmokeButton);
                CreateCustomColourMenu(tireSmokeMenu, RGBType.tiresmoke);

                // Create list for window tint
                var windowTints = new List<string>() { "Stock [1/7]", "None [2/7]", "Limo [3/7]", "Light Smoke [4/7]", "Dark Smoke [5/7]", "Pure Black [6/7]", "Green [7/7]" };
                var currentTint = GetVehicleWindowTint(veh.Handle);
                if (currentTint == -1)
                {
                    currentTint = 4; // stock
                }

                // Convert window tint to the correct index of the list above.
                switch (currentTint)
                {
                    case 0:
                        currentTint = 1; // None
                        break;
                    case 1:
                        currentTint = 5; // Pure Black
                        break;
                    case 2:
                        currentTint = 4; // Dark Smoke
                        break;
                    case 3:
                        currentTint = 3; // Light Smoke
                        break;
                    case 4:
                        currentTint = 0; // Stock
                        break;
                    case 5:
                        currentTint = 2; // Limo
                        break;
                    case 6:
                        currentTint = 6; // Green
                        break;
                    default:
                        break;
                }

                var windowTint = new MenuListItem("Janela Tint", windowTints, currentTint, "Aplicar tint para seu janelas.");
                VehicleModMenu.AddMenuItem(windowTint);

                #endregion

                #region Checkbox Changes
                // Handle checkbox changes.
                VehicleModMenu.OnCheckboxChange += (sender2, item2, index2, _checked) =>
                {
                    veh = GetVehicle();

                    // Turbo
                    if (item2 == turbo)
                    {
                        ToggleVehicleMod(veh.Handle, 18, _checked);
                    }
                    // Bullet Proof Tires
                    else if (item2 == bulletProofTires)
                    {
                        SetVehicleTyresCanBurst(veh.Handle, !_checked);
                    }
                    // Low Grip Tyres
                    else if (item2 == lowGripTires)
                    {
                        SetDriftTyresEnabled(veh.Handle, _checked);
                    }
                    // Custom Wheels
                    else if (item2 == toggleCustomWheels)
                    {
                        SetVehicleMod(veh.Handle, 23, GetVehicleMod(veh.Handle, 23), !GetVehicleModVariation(veh.Handle, 23));

                        // If the player is on a motorcycle, also change the back wheels.
                        if (IsThisModelABike((uint)GetEntityModel(veh.Handle)))
                        {
                            SetVehicleMod(veh.Handle, 24, GetVehicleMod(veh.Handle, 24), GetVehicleModVariation(veh.Handle, 23));
                        }
                    }
                };
                #endregion

                #region List Changes
                // Handle list selections
                VehicleModMenu.OnListIndexChange += (sender2, item2, oldIndex, newIndex, itemIndex) =>
                {
                    // Get the vehicle and set the mod kit.
                    veh = GetVehicle();
                    SetVehicleModKit(veh.Handle, 0);

                    #region handle the dynamic (vehicle-specific) mods
                    // If the affected list is actually a "dynamically" generated list, continue. If it was one of the manual options, go to else.
                    if (item2.ItemData is int modType)
                    {
                        var selectedUpgrade = item2.ListIndex - 1;
                        var customWheels = GetVehicleModVariation(veh.Handle, 23);

                        SetVehicleMod(veh.Handle, modType, selectedUpgrade, customWheels);
                    }
                    #endregion
                    // If it was not one of the lists above, then it was one of the manual lists/options selected, 
                    // either: vehicle Wheel Type, or window tint:
                    #region Handle the items available on all vehicles.
                    // Wheel types
                    else if (item2 == vehicleWheelType)
                    {
                        var vehicleClass = GetVehicleClass(veh.Handle);
                        var isBikeOrOpenWheel = (newIndex == 6 && veh.Model.IsBike) || (newIndex == 10 && vehicleClass == 22);
                        var isNotBikeNorOpenWheel = newIndex != 6 && !veh.Model.IsBike && newIndex != 10 && vehicleClass != 22;
                        var isCorrectVehicleType = isBikeOrOpenWheel || isNotBikeNorOpenWheel;
                        if (!isCorrectVehicleType)
                        {
                            // Go past the index if it's not a bike.
                            if (!veh.Model.IsBike && vehicleClass != 22)
                            {
                                if (newIndex > oldIndex)
                                {
                                    item2.ListIndex++;
                                }
                                else
                                {
                                    item2.ListIndex--;
                                }
                            }
                            // Reset the index to 6 if it is a bike
                            else
                            {
                                item2.ListIndex = veh.Model.IsBike ? 6 : 10;
                            }
                        }
                        // Set the wheel type
                        SetVehicleWheelType(veh.Handle, item2.ListIndex);

                        var customWheels = GetVehicleModVariation(veh.Handle, 23);

                        // Reset the wheel mod index for front wheels
                        SetVehicleMod(veh.Handle, 23, -1, customWheels);

                        // If the model is a bike, do the same thing for the rear wheels.
                        if (veh.Model.IsBike)
                        {
                            SetVehicleMod(veh.Handle, 24, -1, customWheels);
                        }

                        // Refresh the menu with the item index so that the view doesn't change
                        UpdateMods(selectedIndex: itemIndex);
                    }
                    // Window Tint
                    else if (item2 == windowTint)
                    {
                        // Stock = 4,
                        // None = 0,
                        // Limo = 5,
                        // LightSmoke = 3,
                        // DarkSmoke = 2,
                        // PureBlack = 1,
                        // Green = 6,

                        switch (newIndex)
                        {
                            case 1:
                                SetVehicleWindowTint(veh.Handle, 0); // None
                                break;
                            case 2:
                                SetVehicleWindowTint(veh.Handle, 5); // Limo
                                break;
                            case 3:
                                SetVehicleWindowTint(veh.Handle, 3); // Light Smoke
                                break;
                            case 4:
                                SetVehicleWindowTint(veh.Handle, 2); // Dark Smoke
                                break;
                            case 5:
                                SetVehicleWindowTint(veh.Handle, 1); // Pure Black
                                break;
                            case 6:
                                SetVehicleWindowTint(veh.Handle, 6); // Green
                                break;
                            case 0:
                            default:
                                SetVehicleWindowTint(veh.Handle, 4); // Stock
                                break;
                        }
                    }
                    #endregion
                };

                #endregion
            }
            // Refresh Index and update the scaleform to prevent weird broken menus.
            if (selectedIndex == 0)
            {
                VehicleModMenu.RefreshIndex();
            }

            //VehicleModMenu.UpdateScaleform();

            // Set the selected index to the provided index (0 by default)
            // Used for example, when the wheelstype is changed, the menu is refreshed and we want to set the
            // selected item back to the "wheelsType" list so the user doesn't have to scroll down each time they
            // change the wheels type.
            //VehicleModMenu.CurrentIndex = selectedIndex;
        }

        internal static void SetHeadlightsColorForVehicle(Vehicle veh, int newIndex)
        {

            if (veh != null && veh.Exists() && veh.Driver == Game.PlayerPed)
            {
                if (newIndex is > (-1) and < 13)
                {
                    SetVehicleHeadlightsColour(veh.Handle, newIndex);
                }
                else
                {
                    SetVehicleHeadlightsColour(veh.Handle, -1);
                }
            }
        }

        internal static int GetHeadlightsColorForVehicle(Vehicle vehicle)
        {
            if (vehicle != null && vehicle.Exists())
            {
                if (IsToggleModOn(vehicle.Handle, 22))
                {
                    var val = GetVehicleHeadlightsColour(vehicle.Handle);
                    if (val is > (-1) and < 13)
                    {
                        return val;
                    }
                    return -1;
                }
            }
            return -1;
        }
        #endregion

        #region GetColorFromIndex function (underglow)
        /// <summary>
        /// Converts a list index to a <see cref="System.Drawing.Color"/> struct.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private static System.Drawing.Color GetColorFromIndex(int index)
        {
            if (index is >= 0 and < 13)
            {
                return System.Drawing.Color.FromArgb(VehicleData.NeonLightColors[index][0], VehicleData.NeonLightColors[index][1], VehicleData.NeonLightColors[index][2]);
            }
            return System.Drawing.Color.FromArgb(255, 255, 255);
        }
        public enum Colour_Types
        {
            Metallic = 0,
            Classic,
            Pearlescent,
            Matte,
            Metals,
            Chrome,
            Chameleon
        }
        private static bool IsHex(IEnumerable<char> chars)
        {
            bool isHex;
            foreach (var c in chars)
            {
                isHex = ((c >= '0' && c <= '9') ||
                         (c >= 'a' && c <= 'f') ||
                         (c >= 'A' && c <= 'F'));

                if (!isHex)
                    return false;
            }
            return true;
        }
        public enum RGBType
        {
            primaryPaint,
            secondaryPaint,
            underglow,
            headlight,
            tiresmoke,

        }

        public static void CreateCustomColourMenu(Menu menu, RGBType type = RGBType.primaryPaint)
        {
            
            var hexColour = new MenuItem("Hex Cor Code");
            var typeList = new MenuListItem("Acabamento da Pintura", Enum.GetNames(typeof(Colour_Types)).ToList(), 0);
            
            int r = 0,  g = 0, b = 0;     

            var redColour = new MenuSliderItem("Red Cor", 0, 255, 128, true)
            {
                BarColor = System.Drawing.Color.FromArgb(155, 0, 0, 0),
                BackgroundColor = System.Drawing.Color.FromArgb(200, 79, 79, 79),
            };
            var greenColour = new MenuSliderItem("Green Cor", 0, 255, 128, true)
            {
                BarColor = System.Drawing.Color.FromArgb(155, 0, 0, 0),
                BackgroundColor = System.Drawing.Color.FromArgb(200, 79, 79, 79),
            };
            var blueColour = new MenuSliderItem("Blue Cor", 0, 255, 128, true)
            {
                BarColor = System.Drawing.Color.FromArgb(155, 0, 0, 0),
                BackgroundColor = System.Drawing.Color.FromArgb(200, 79, 79, 79),
            };

            menu.AddMenuItem(hexColour);
            menu.AddMenuItem(redColour);
            menu.AddMenuItem(greenColour);
            menu.AddMenuItem(blueColour);
            if (type == RGBType.primaryPaint || type == RGBType.secondaryPaint)
                menu.AddMenuItem(typeList);

            menu.OnMenuOpen += (menu) =>
            {
                Vehicle vehicle = GetVehicle();

                if (type == RGBType.primaryPaint)
                    GetVehicleCustomPrimaryColour(vehicle.Handle, ref r, ref g, ref b);
                else if (type == RGBType.secondaryPaint)
                    GetVehicleCustomSecondaryColour(vehicle.Handle, ref r, ref g, ref b);
                else if (type == RGBType.underglow)
                {
                    r = vehicle.Mods.NeonLightsColor.R;
                    g = vehicle.Mods.NeonLightsColor.G;
                    b = vehicle.Mods.NeonLightsColor.B; 
                }
                else if (type == RGBType.headlight)
                {
                    if (!GetVehicleXenonLightsCustomColor(vehicle.Handle, ref r, ref g, ref b))
                    {
                        if (IsToggleModOn(vehicle.Handle, 22))
                        {
                            int headlight = GetHeadlightsColorForVehicle(vehicle) < 0 ? 0 : GetHeadlightsColorForVehicle(vehicle);
                            r = VehicleData.NeonLightColors[headlight][0];
                            g = VehicleData.NeonLightColors[headlight][1];
                            b = VehicleData.NeonLightColors[headlight][2]; 
                        }
                    }

                }
                else if (type == RGBType.tiresmoke)
                    GetVehicleTyreSmokeColor(vehicle.Handle, ref r, ref g, ref b);


                redColour.Text = $"Red Cor ({r})";
                redColour.Position = r;

                greenColour.Text = $"Green Cor ({g})";
                greenColour.Position = g;

                blueColour.Text = $"Blue Cor ({b})";
                blueColour.Position = b;

                redColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
                greenColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
                blueColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
            };

            menu.OnItemSelect += async (sender, item, index) =>
            {
                Vehicle vehicle = GetVehicle();
                if (item == hexColour)
                {
                    string hexValue = redColour.Position.ToString("X2") + greenColour.Position.ToString("X2") + blueColour.Position.ToString("X2");
                    var result = await GetUserInput(windowTitle: "Digite Cor Hex", defaultText: (hexValue).Replace("#", ""), maxInputLength: 6);
                    if (!string.IsNullOrEmpty(result))
                    {
                        if (IsHex(result))
                        {
                            int RGBint = Convert.ToInt32(result, 16);
                            byte red = (byte)((RGBint >> 16) & 255);
                            byte green = (byte)((RGBint >> 8) & 255);
                            byte blue = (byte)(RGBint & 255);

                            if (type == RGBType.primaryPaint)
                                SetVehicleCustomPrimaryColour(vehicle.Handle, red, green, blue);
                            else if (type == RGBType.secondaryPaint)
                                SetVehicleCustomSecondaryColour(vehicle.Handle, red, green, blue);
                            else if (type == RGBType.underglow)
                                vehicle.Mods.NeonLightsColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                            else if (type == RGBType.headlight)
                                SetVehicleXenonLightsCustomColor(vehicle.Handle, red, green, blue);
                            else if (type == RGBType.tiresmoke)
                                SetVehicleTyreSmokeColor(vehicle.Handle, red, green, blue);

                            redColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                            greenColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                            blueColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);

                            redColour.Text = $"Red Cor ({red})";
                            redColour.Position = red;

                            greenColour.Text = $"Green Cor ({green})";
                            greenColour.Position = green;

                            blueColour.Text = $"Blue Cor ({blue})";
                            blueColour.Position = blue;
                        }
                    }
                }
            };
            menu.OnSliderPositionChange += (m, sliderItem, oldPosition, newPosition, itemIndex) =>
            {
                Vehicle vehicle = GetVehicle();

                if (type == RGBType.primaryPaint)
                    GetVehicleCustomPrimaryColour(vehicle.Handle, ref r, ref g, ref b);
                else if (type == RGBType.secondaryPaint)
                    GetVehicleCustomSecondaryColour(vehicle.Handle, ref r, ref g, ref b);
                else if (type == RGBType.underglow)
                {
                    r = vehicle.Mods.NeonLightsColor.R;
                    g = vehicle.Mods.NeonLightsColor.G;
                    b = vehicle.Mods.NeonLightsColor.B; 
                }
                else if (type == RGBType.headlight)
                {
                    if (!GetVehicleXenonLightsCustomColor(vehicle.Handle, ref r, ref g, ref b))
                    {
                        if (IsToggleModOn(vehicle.Handle, 22))
                        {
                            int headlight = GetHeadlightsColorForVehicle(vehicle) < 0 ? 0 : GetHeadlightsColorForVehicle(vehicle);
                            r = VehicleData.NeonLightColors[headlight][0];
                            g = VehicleData.NeonLightColors[headlight][1];
                            b = VehicleData.NeonLightColors[headlight][2]; 
                        }
                    }

                }
                else if (type == RGBType.tiresmoke)
                    GetVehicleTyreSmokeColor(vehicle.Handle, ref r, ref g, ref b);


                if (sliderItem == redColour)
                {
                    if (type == RGBType.primaryPaint)
                        SetVehicleCustomPrimaryColour(vehicle.Handle, newPosition, g, b);
                    else if (type == RGBType.secondaryPaint)
                        SetVehicleCustomSecondaryColour(vehicle.Handle, newPosition, g, b);
                    else if (type == RGBType.underglow)
                        vehicle.Mods.NeonLightsColor = System.Drawing.Color.FromArgb(255, newPosition, g, b);
                    else if (type == RGBType.headlight)
                        SetVehicleXenonLightsCustomColor(vehicle.Handle, newPosition, g, b);
                    else if (type == RGBType.tiresmoke)
                        vehicle.Mods.TireSmokeColor = System.Drawing.Color.FromArgb(255, newPosition, g, b);

                    redColour.Text = $"Red Cor ({newPosition})";
                }
                if (sliderItem == greenColour)
                {
                    if (type == RGBType.primaryPaint)
                        SetVehicleCustomPrimaryColour(vehicle.Handle, r, newPosition, b);
                    else if (type == RGBType.secondaryPaint)
                        SetVehicleCustomSecondaryColour(vehicle.Handle, r, newPosition, b);
                    else if (type == RGBType.underglow)
                        vehicle.Mods.NeonLightsColor = System.Drawing.Color.FromArgb(255, r, newPosition, b);
                    else if (type == RGBType.headlight)
                        SetVehicleXenonLightsCustomColor(vehicle.Handle, r, newPosition, b);
                    else if (type == RGBType.tiresmoke)
                        vehicle.Mods.TireSmokeColor = System.Drawing.Color.FromArgb(255, r, newPosition, b);

                    greenColour.Text = $"Green Cor ({newPosition})";
                }
                if (sliderItem == blueColour)
                {
                     if (type == RGBType.primaryPaint)
                        SetVehicleCustomPrimaryColour(vehicle.Handle, r, g, newPosition);
                    else if (type == RGBType.secondaryPaint)
                        SetVehicleCustomSecondaryColour(vehicle.Handle, r, g, newPosition);
                    else if (type == RGBType.underglow)
                        vehicle.Mods.NeonLightsColor = System.Drawing.Color.FromArgb(255, r, g, newPosition);
                    else if (type == RGBType.headlight)
                        SetVehicleXenonLightsCustomColor(vehicle.Handle, r, g, newPosition);
                    else if (type == RGBType.tiresmoke)
                        vehicle.Mods.TireSmokeColor = System.Drawing.Color.FromArgb(255, r, g, newPosition);

                    blueColour.Text = $"Blue Cor ({newPosition})";
                }
                redColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
                greenColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
                blueColour.BarColor = System.Drawing.Color.FromArgb(255, redColour.Position, greenColour.Position, blueColour.Position);
            };

            menu.OnListIndexChange += (sender, item, oldIndex, newIndex, itemIndex) =>
            {
                Vehicle vehicle = GetVehicle();

                if (type == RGBType.primaryPaint)
                {
                    var pearlColorReset = 0;
                    var wheelColorReset = 0;
                    GetVehicleExtraColours(vehicle.Handle, ref pearlColorReset, ref wheelColorReset);
                    SetVehicleModColor_1(vehicle.Handle, newIndex, 0, 0);
                    vehicle.State.Set("vMenu:PrimaryPaintFinish", newIndex, true);
                    SetVehicleExtraColours(vehicle.Handle, pearlColorReset, wheelColorReset);
                }
                else if (type == RGBType.secondaryPaint)
                {
                    var pearlColorReset = 0;
                    var wheelColorReset = 0;
                    GetVehicleExtraColours(vehicle.Handle, ref pearlColorReset, ref wheelColorReset);
                    SetVehicleModColor_2(vehicle.Handle, newIndex, 0);
                    vehicle.State.Set("vMenu:SecondaryPaintFinish", newIndex, true);
                    SetVehicleExtraColours(vehicle.Handle, pearlColorReset, wheelColorReset);
                }
                else if (type == RGBType.underglow)
                {
                    Color underglow = GetColorFromIndex(newIndex);
                    int red = underglow.R;
                    int green = underglow.G;
                    int blue = underglow.B;
                    
                    redColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    greenColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    blueColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);

                    redColour.Text = $"Red Cor ({red})";
                    redColour.Position = red;

                    greenColour.Text = $"Green Cor ({green})";
                    greenColour.Position = green;

                    blueColour.Text = $"Blue Cor ({blue})";
                    blueColour.Position = blue; 
                }
                else if (type == RGBType.headlight)
                {
                    int headlight = GetHeadlightsColorForVehicle(vehicle) < 0 ? 0 : GetHeadlightsColorForVehicle(vehicle);
                    int red = VehicleData.NeonLightColors[headlight][0];
                    int green = VehicleData.NeonLightColors[headlight][1];
                    int blue = VehicleData.NeonLightColors[headlight][2];
                    

                    redColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    greenColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    blueColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);

                    redColour.Text = $"Red Cor ({red})";
                    redColour.Position = red;

                    greenColour.Text = $"Green Cor ({green})";
                    greenColour.Position = green;

                    blueColour.Text = $"Blue Cor ({blue})";
                    blueColour.Position = blue; 
                }
                else if (type == RGBType.tiresmoke)
                {
                    int red = vehicle.Mods.TireSmokeColor.R;
                    int green = vehicle.Mods.TireSmokeColor.G;
                    int blue = vehicle.Mods.TireSmokeColor.B; 
                    
                    redColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    greenColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);
                    blueColour.BarColor = System.Drawing.Color.FromArgb(255, red, green, blue);

                    redColour.Text = $"Red Cor ({red})";
                    redColour.Position = red;

                    greenColour.Text = $"Green Cor ({green})";
                    greenColour.Position = green;

                    blueColour.Text = $"Blue Cor ({blue})";
                    blueColour.Position = blue; 
                }
    
            };
        }

        /// <summary>
        /// Returns the color index that is applied on the current vehicle. 
        /// If a color is active on the vehicle which is not in the list, it'll return the default index 0 (white).
        /// </summary>
        /// <returns></returns>
        private int GetIndexFromColor()
        {
            var veh = GetVehicle();

            if (veh == null || !veh.Exists() || !veh.Mods.HasNeonLights)
            {
                return 0;
            }

            int r = 255, g = 255, b = 255;

            GetVehicleNeonLightsColour(veh.Handle, ref r, ref g, ref b);

            if (r == 255 && g == 0 && b == 255) // default return value when the vehicle has no neon kit selected.
            {
                return 0;
            }

            if (VehicleData.NeonLightColors.Any(a => { return a[0] == r && a[1] == g && a[2] == b; }))
            {
                return VehicleData.NeonLightColors.FindIndex(a => { return a[0] == r && a[1] == g && a[2] == b; });
            }

            return 0;
        }
        #endregion

        private bool IsVehicleTooDamagedToChangeExtras(Vehicle vehicle)
        {
            float bodyHealth = vehicle.BodyHealth;
            float engineHealth = vehicle.EngineHealth;
            float allowedBodyHealth = GetSettingsInt(Setting.vmenu_allowed_body_damage_for_extra_change);
            float allowedEngineHealth = GetSettingsInt(Setting.vmenu_allowed_engine_damage_for_extra_change);

            return bodyHealth < allowedBodyHealth || engineHealth < allowedEngineHealth;
        }
    }
}
