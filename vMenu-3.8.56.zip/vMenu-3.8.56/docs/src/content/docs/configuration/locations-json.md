---
title: "locations.json"
---

## About
In this file you can configure as many blips or teleport locations as you want. The teleport locations are accessible from the Misc Settings menu (scroll down until you see the Teleport Locations button). The blips can also be turned on from the Misc Settings menu (near the player blips option).


## Blips
For a list of all possible blip sprite ID's, click [here][blip-sprites].


## Example config
In this example config I've added 2 example teleport locations, and a total of 4 blip locations. Simply follow the setup below and copy/paste as many new blips/locations as you want. Just make sure you keep track of the brackets and all the commas in the right places!

```json
{
  "teleports":[
    {
      "name":"Example Location 1",
      "coordinates":{
        "x":472.94,
        "y":-3035.96,
        "z":6.2
      },
      "heading":356.1
    },
    {
      "name":"Example Location 2",
      "coordinates":{
        "x":800.94,
        "y":-500.96,
        "z":20.2
      },
      "heading":30.1
    }
  ],
  "blips":[
    {
      "name":"Example Blip 1",
      "coordinates":{
        "x":472.94,
        "y":-3035.96,
        "z":6.2
      },
      "spriteID":1,
      "color":1
    },
    {
      "name":"Example Blip 2",
      "coordinates":{
        "x":20.94,
        "y":20.96,
        "z":80.2
      },
      "spriteID":176,
      "color":5
    },
    {
      "name":"Example Blip 3",
      "coordinates":{
        "x":70.94,
        "y":700.96,
        "z":70.2
      },
      "spriteID":51,
      "color":8
    },
    {
      "name":"Example Blip 4",
      "coordinates":{
        "x":472.94,
        "y":-3035.96,
        "z":6.2
      },
      "spriteID":303,
      "color":7
    }
  ]
}
```

## Default locations.json
```json
{
   "teleports":[
      {
         "name":"Example Location",
         "coordinates":{
            "x":472.94,
            "y":-3035.96,
            "z":6.2
         },
         "heading":356.1
      }
   ],
  "blips": [
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": 442.18,
        "y": -983.14,
        "z": 30.10
      }
    },
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": -1094.83,
        "y": -836.18,
        "z": 38.06
      }
    },
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": 825.62,
        "y": -1290.11,
        "z": 28.24
      }
    },
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": -560.62,
        "y": -133.38,
        "z": 38.08
      }
    },
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": 1853.82,
        "y": 3686.43,
        "z": 34.27
      }
    },
    {
      "name": "Police Station",
      "spriteID": 526,
      "color": 0,
      "coordinates": {
        "x": -445.80,
        "y": 6014.20,
        "z": 31.71
      }
    },
    {
      "name": "Ammu-Nation With Range",
      "spriteID": 313,
      "color": 0,
      "coordinates": {
        "x": 21.13,
        "y": -1108.05,
        "z": 29.79
      }
    },
    {
      "name": "Ammu-Nation With Range",
      "spriteID": 313,
      "color": 0,
      "coordinates": {
        "x": 812.37,
        "y": -2157.64,
        "z": 29.61
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": -663.57,
        "y": -939.91,
        "z": 21.82
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": 2569.44,
        "y": 300.06,
        "z": 108.73
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": -1310.64,
        "y": -392.84,
        "z": 36.69
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": 248.45,
        "y": -47.13,
        "z": 69.94
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": -1115.16,
        "y": 2695.98,
        "z": 18.55
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": 1696.98,
        "y": 3754.87,
        "z": 34.70
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": -327.41,
        "y": 6080.03,
        "z": 31.45
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": -3167.55,
        "y": 1084.48,
        "z": 20.83
      }
    },
    {
      "name": "Ammu-Nation",
      "spriteID": 110,
      "color": 0,
      "coordinates": {
        "x": 843.89,
        "y": -1027.62,
        "z": 28.19
      }
    },
    {
      "name": "Golf Club",
      "spriteID": 109,
      "color": 0,
      "coordinates": {
        "x": -1369.88,
        "y": 57.38,
        "z": 53.70
      }
    },
    {
      "name": "Fort Zancudo",
      "spriteID": 419,
      "color": 0,
      "coordinates": {
        "x": -2086.37,
        "y": 3080.96,
        "z": 32.81
      }
    },
    {
      "name": "Horse Race Track",
      "spriteID": 309,
      "color": 0,
      "coordinates": {
        "x": 1151.84,
        "y": 119.37,
        "z": 81.87
      }
    },
    {
      "name": "Prison",
      "spriteID": 58,
      "color": 0,
      "coordinates": {
        "x": 1693.35,
        "y": 2605.47,
        "z": 45.56
      }
    },
    {
      "name": "Cave",
      "spriteID": 162,
      "color": 0,
      "coordinates": {
        "x": 3109.63,
        "y": 2192.22,
        "z": 8.59
      }
    },
    {
      "name": "N.O.O.S.E Facility",
      "spriteID": 60,
      "color": 0,
      "coordinates": {
        "x": 2506.00,
        "y": -382.86,
        "z": 94.12
      }
    },
    {
      "name": "Vehicle Impound",
      "spriteID": 225,
      "color": 0,
      "coordinates": {
        "x": 395.18,
        "y": -1615.73,
        "z": 29.29
      }
    },
    {
      "name": "Hospital",
      "spriteID": 61,
      "color": 0,
      "coordinates": {
        "x": 306.58,
        "y": -1435.32,
        "z": 29.80
      }
    },
    {
      "name": "Hospital",
      "spriteID": 61,
      "color": 0,
      "coordinates": {
        "x": 305.00,
        "y": -583.00,
        "z": 50.00
      }
    },
    {
      "name": "Hospital",
      "spriteID": 61,
      "color": 0,
      "coordinates": {
        "x": -463.67,
        "y": -338.42,
        "z": 34.50
      }
    },
    {
      "name": "Hospital",
      "spriteID": 61,
      "color": 0,
      "coordinates": {
        "x": 1828.13,
        "y": 3667.26,
        "z": 34.28
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 1689.29,
        "y": 4820.49,
        "z": 42.06
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 1199.00,
        "y": 2706.09,
        "z": 38.22
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 78.62,
        "y": -1391.16,
        "z": 29.37
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 422.37,
        "y": -807.84,
        "z": 29.49
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -1196.41,
        "y": -774.02,
        "z": 17.32
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 0.61,
        "y": 6514.44,
        "z": 31.87
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 124.54,
        "y": -218.71,
        "z": 54.55
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -1097.86,
        "y": 2708.82,
        "z": 19.11
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -3170.29,
        "y": 1051.89,
        "z": 20.86
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -818.76,
        "y": -1076.82,
        "z": 11.33
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -162.18,
        "y": -302.30,
        "z": 39.71
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": -712.28,
        "y": -154.21,
        "z": 37.41
      }
    },
    {
      "name": "Clothes Store",
      "spriteID": 73,
      "color": 0,
      "coordinates": {
        "x": 617.84,
        "y": 2756.28,
        "z": 42.09
      }
    },
    {
      "name": "Mask Store",
      "spriteID": 362,
      "color": 0,
      "coordinates": {
        "x": -1336.30,
        "y": -1277.71,
        "z": 4.87
      }
    },
    {
      "name": "Tattoo Parlor",
      "spriteID": 75,
      "color": 0,
      "coordinates": {
        "x": -3169.42,
        "y": 1074.76,
        "z": 20.83
      }
    },
    {
      "name": "Tattoo Parlor",
      "spriteID": 75,
      "color": 0,
      "coordinates": {
        "x": 1862.07,
        "y": 3749.95,
        "z": 33.03
      }
    },
    {
      "name": "Tattoo Parlor",
      "spriteID": 75,
      "color": 0,
      "coordinates": {
        "x": 322.11,
        "y": 180.81,
        "z": 103.59
      }
    },
    {
      "name": "Tattoo Parlor",
      "spriteID": 75,
      "color": 0,
      "coordinates": {
        "x": -1153.31,
        "y": -1425.48,
        "z": 4.95
      }
    },
    {
      "name": "Barber",
      "spriteID": 71,
      "color": 0,
      "coordinates": {
        "x": 1933.21,
        "y": 3727.99,
        "z": 32.84
      }
    },
    {
      "name": "Barber",
      "spriteID": 71,
      "color": 0,
      "coordinates": {
        "x": 134.77,
        "y": -1710.31,
        "z": 29.29
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 1166.78,
        "y": 2708.10,
        "z": 38.15
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 544.50,
        "y": 2669.01,
        "z": 42.15
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 1393.15,
        "y": 3602.00,
        "z": 34.98
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -1225.30,
        "y": -905.10,
        "z": 12.33
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -3041.25,
        "y": 589.09,
        "z": 7.91
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -2970.96,
        "y": 309.88,
        "z": 15.04
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 1701.72,
        "y": 4927.75,
        "z": 42.06
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -50.7,
        "y": -1755.71,
        "z": 29.42
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -3241.03,
        "y": 1004.56,
        "z": 12.83
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 2680.96,
        "y": 3282.95,
        "z": 55.24
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 1964.67,
        "y": 3741.80,
        "z": 32.34
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": -1488.68,
        "y": -381.17,
        "z": 40.16
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 377.0,
        "y": 324.88,
        "z": 103.57
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 2558.06,
        "y": 385.81,
        "z": 108.62
      }
    },
    {
      "name": "Store",
      "spriteID": 52,
      "color": 0,
      "coordinates": {
        "x": 29.04,
        "y": -1347.47,
        "z": 29.5
      }
    },
    {
      "name": "Benny's",
      "spriteID": 446,
      "color": 28,
      "coordinates": {
        "x": -211.60,
        "y": -1323.28,
        "z": 30.80
      }
    },
    {
      "name": "Los Santos Customs",
      "spriteID": 72,
      "color": 0,
      "coordinates": {
        "x": -352.94,
        "y": -135.84,
        "z": 39.00
      }
    },
    {
      "name": "Los Santos Customs",
      "spriteID": 72,
      "color": 0,
      "coordinates": {
        "x": 729.16,
        "y": -1088.22,
        "z": 22.17
      }
    },
    {
      "name": "Los Santos Customs",
      "spriteID": 72,
      "color": 0,
      "coordinates": {
        "x": -1148.52,
        "y": -1994.11,
        "z": 13.18
      }
    },
    {
      "name": "Los Santos Customs",
      "spriteID": 72,
      "color": 0,
      "coordinates": {
        "x": 1179.05,
        "y": 2644.00,
        "z": 37.79
      }
    },
    {
      "name": "Los Santos Customs",
      "spriteID": 72,
      "color": 0,
      "coordinates": {
        "x": 110.70,
        "y": 6625.64,
        "z": 31.78
      }
    },
    {
      "name": "Helicopter Pad",
      "spriteID": 360,
      "color": 0,
      "coordinates": {
        "x": -735.56,
        "y": -1456.48,
        "z": 5.00
      }
    },
    {
      "name": "Harbor",
      "spriteID": 356,
      "color": 0,
      "coordinates": {
        "x": -854.76,
        "y": -1424.97,
        "z": 5.00
      }
    },
    {
      "name": "Del Perro Pier",
      "spriteID": 266,
      "color": 0,
      "coordinates": {
        "x": -1843.59,
        "y": -1219.52,
        "z": 12.81
      }
    },
    {
      "name": "Strip Club",
      "spriteID": 121,
      "color": 0,
      "coordinates": {
        "x": 126.55,
        "y": -1289.25,
        "z": 29.28
      }
    },
    {
      "name": "Tequi-la-la",
      "spriteID": 93,
      "color": 0,
      "coordinates": {
        "x": -555.16,
        "y": 284.97,
        "z": 82.17
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": -818.05,
        "y": 177.76,
        "z": 72.22
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": 1985.481,
        "y": 3828.768,
        "z": 32.5
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": -1117.163,
        "y": 303.0907,
        "z": 66.52217
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": 1395.17,
        "y": 1141.81,
        "z": 114.63
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": 5.09,
        "y": 532.59,
        "z": 175.34
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": -14.69,
        "y": -1439.27,
        "z": 31.1
      }
    },
    {
      "name": "Safehouse",
      "spriteID": 40,
      "color": 0,
      "coordinates": {
        "x": -3086.428,
        "y": 339.2523,
        "z": 6.3717
      }
    },
    {
      "name": "Redwood Lights Race Track",
      "spriteID": 127,
      "color": 0,
      "coordinates": {
        "x": 1022.50,
        "y": 2408.15,
        "z": 55.22
      }
    },
    {
      "name": "Simeon's Showroom",
      "spriteID": 369,
      "color": 0,
      "coordinates": {
        "x": -47.1617,
        "y": -1115.333,
        "z": 26.5
      }
    },
    {
      "name": "Jewel Store",
      "spriteID": 439,
      "color": 0,
      "coordinates": {
        "x": -637.2016,
        "y": -239.1625,
        "z": 38.1
      }
    },
    {
      "name": "Union Depository Heist",
      "spriteID": 107,
      "color": 0,
      "coordinates": {
        "x": 2.696893,
        "y": -667.0166,
        "z": 16.13063
      }
    },
    {
      "name": "Morgue",
      "spriteID": 162,
      "color": 0,
      "coordinates": {
        "x": 239.752,
        "y": -1360.65,
        "z": 39.53437
      }
    },
    {
      "name": "Cluckin Bell",
      "spriteID": 162,
      "color": 0,
      "coordinates": {
        "x": -146.3837,
        "y": 6161.5,
        "z": 30.2062
      }
    },
    {
      "name": "O'Neil Brothers",
      "spriteID": 140,
      "color": 0,
      "coordinates": {
        "x": 2447.9,
        "y": 4973.4,
        "z": 47.7
      }
    },
    {
      "name": "FIB Building",
      "spriteID": 475,
      "color": 0,
      "coordinates": {
        "x": 105.4557,
        "y": -745.4835,
        "z": 44.7548
      }
    },
    {
      "name": "Lester's Factory",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 716.84,
        "y": -962.05,
        "z": 31.59
      }
    },
    {
      "name": "Life Invader",
      "spriteID": 475,
      "color": 0,
      "coordinates": {
        "x": -1047.9,
        "y": -233,
        "z": 39.0
      }
    },
    {
      "name": "Carwash",
      "spriteID": 100,
      "color": 0,
      "coordinates": {
        "x": 55.7,
        "y": -1391.3,
        "z": 30.5
      }
    },
    {
      "name": "Carwash",
      "spriteID": 100,
      "color": 0,
      "coordinates": {
        "x": -700.01,
        "y": -933.06,
        "z": 18.48
      }
    },
    {
      "name": "The Lost",
      "spriteID": 226,
      "color": 0,
      "coordinates": {
        "x": 49.49379,
        "y": 3744.472,
        "z": 46.38629
      }
    },
    {
      "name": "The Lost",
      "spriteID": 226,
      "color": 0,
      "coordinates": {
        "x": 984.1552,
        "y": -95.3662,
        "z": 74.5
      }
    },
    {
      "name": "Heist Aircraft Carrier",
      "spriteID": 455,
      "color": 0,
      "coordinates": {
        "x": 3082.312,
        "y": -4717.119,
        "z": 15.2622
      }
    },
    {
      "name": "Heist Yacht",
      "spriteID": 455,
      "color": 0,
      "coordinates": {
        "x": -2043.974,
        "y": -1031.582,
        "z": 11.981
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 848,
        "y": 3004,
        "z": 44
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 2118,
        "y": 3330,
        "z": 46
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 2491,
        "y": 3150,
        "z": 50
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 486,
        "y": 3005,
        "z": 42
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": -391,
        "y": 4354,
        "z": 57
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 1815,
        "y": 4706,
        "z": 41
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 1571,
        "y": 2241,
        "z": 79
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": -772,
        "y": 5938,
        "z": 23
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": 31,
        "y": 2945,
        "z": 58
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": -3046,
        "y": 3331,
        "z": 11
      }
    },
    {
      "name": "Bunker",
      "spriteID": 473,
      "color": 0,
      "coordinates": {
        "x": -3171,
        "y": 1375,
        "z": 18
      }
    },
    {
      "name": "Bahama Mamas",
      "spriteID": 93,
      "color": 0,
      "coordinates": {
        "x": -1388.001,
        "y": -618.4197,
        "z": 30.8196
      }
    },
    {
      "name": "Aircraft Hangar",
      "spriteID": 359,
      "color": 0,
      "coordinates": {
        "x": -1152.17,
        "y": -3410.83,
        "z": 13.95
      }
    },
    {
      "name": "Aircraft Hangar",
      "spriteID": 359,
      "color": 0,
      "coordinates": {
        "x": -1395.4,
        "y": -3266.66,
        "z": 13.95
      }
    },
    {
      "name": "Aircraft Hangar",
      "spriteID": 359,
      "color": 0,
      "coordinates": {
        "x": -2470.22,
        "y": 3274.79,
        "z": 32.83
      }
    },
    {
      "name": "Aircraft Hangar",
      "spriteID": 359,
      "color": 0,
      "coordinates": {
        "x": -2021.5,
        "y": 3157.4,
        "z": 32.81
      }
    },
    {
      "name": "Aircraft Hangar",
      "spriteID": 359,
      "color": 0,
      "coordinates": {
        "x": -1878.01,
        "y": 3108.85,
        "z": 32.81
      }
    }
  ]
}
```

## Appreciate my work?
Consider supporting me on [Patreon](https://www.patreon.com/vespura)!

[blip-sprites]: https://docs.fivem.net/docs/game-references/blips/
