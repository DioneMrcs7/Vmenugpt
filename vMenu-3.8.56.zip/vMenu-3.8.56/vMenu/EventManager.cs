﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using CitizenFX.Core;

using Newtonsoft.Json;

using vMenuClient.data;
using vMenuClient.menus;

using static CitizenFX.Core.Native.API;
using static vMenuClient.CommonFunctions;
using static vMenuShared.ConfigManager;
using static vMenuShared.PermissionsManager;

namespace vMenuClient
{
    public class EventManager : BaseScript
    {
        public static WeatherOptions WeatherOptionsMenu { get; private set; }
        public static bool IsSnowEnabled => GetSettingsBool(Setting.vmenu_enable_snow);
        public static int GetServerMinutes => MathUtil.Clamp(GetSettingsInt(Setting.vmenu_current_minute), 0, 59);
        public static int GetServerHours => MathUtil.Clamp(GetSettingsInt(Setting.vmenu_current_hour), 0, 23);
        public static int GetServerMinuteDuration => GetSettingsInt(Setting.vmenu_ingame_minute_duration);
        public static bool IsServerTimeFrozen => GetSettingsBool(Setting.vmenu_freeze_time);
        public static bool IsServerTimeSyncedWithMachineTime => GetSettingsBool(Setting.vmenu_sync_to_machine_time);
        public static string GetServerWeather => GetSettingsString(Setting.vmenu_current_weather, "CLEAR");
        public static bool DynamicWeatherEnabled => GetSettingsBool(Setting.vmenu_enable_dynamic_weather);
        public static bool IsBlackoutEnabled => GetSettingsBool(Setting.vmenu_blackout_enabled);
        public static bool IsVehicleLightsEnabled => GetSettingsBool(Setting.vmenu_vehicle_blackout_enabled);
        public static int WeatherChangeTime => MathUtil.Clamp(GetSettingsInt(Setting.vmenu_weather_change_duration), 0, 45);

        /// <summary>
        /// Constructor.
        /// </summary>
        public EventManager()
        {
            // Add event handlers.
            EventHandlers.Add("vMenu:SetAddons", new Action(SetConfigOptions)); // DEPRECATED: Backwards-compatible event handler; use 'vMenu:SetConfigOptions' instead
            EventHandlers.Add("vMenu:SetConfigOptions", new Action(SetConfigOptions));
            EventHandlers.Add("vMenu:SetPermissions", new Action<string>(MainMenu.SetPermissions));
            EventHandlers.Add("vMenu:SetSupplementaryPermissions", new Action<string>(MainMenu.SetSupplementaryPermissions));
            EventHandlers.Add("vMenu:KillMe", new Action<string>(KillMe));
            EventHandlers.Add("vMenu:Notify", new Action<string>(NotifyPlayer));
            EventHandlers.Add("vMenu:SetClouds", new Action<float, string>(SetClouds));
            EventHandlers.Add("vMenu:GoodBye", new Action(GoodBye));
            EventHandlers.Add("vMenu:SetBanList", new Action<string>(UpdateBanList));
            EventHandlers.Add("vMenu:ClearArea", new Action<Vector3>(ClearAreaNearPos));
            EventHandlers.Add("vMenu:updatePedDecors", new Action(UpdatePedDecors));
            EventHandlers.Add("playerSpawned", new Action(SetAppearanceOnFirstSpawn));
            EventHandlers.Add("vMenu:PrivateMessage", new Action<string, string>(PrivateMessage));
            EventHandlers.Add("vMenu:UpdateTeleportLocations", new Action<string>(UpdateTeleportLocations));

            if (GetSettingsBool(Setting.vmenu_enable_weather_sync))
            {
                Tick += WeatherSync;
            }

            if (GetSettingsBool(Setting.vmenu_enable_time_sync))
            {
                Tick += TimeSync;
            }
        }

        private bool firstSpawn = true;
        /// <summary>
        /// Sets the saved character whenever the player first spawns.
        /// </summary>
        private async void SetAppearanceOnFirstSpawn()
        {
            if (firstSpawn)
            {
                firstSpawn = false;
                if (MainMenu.MiscSettingsMenu != null && MainMenu.MpPedCustomizationMenu != null && MainMenu.MiscSettingsMenu.MiscRespawnDefaultCharacter && !string.IsNullOrEmpty(GetResourceKvpString("vmenu_default_character")) && !GetSettingsBool(Setting.vmenu_disable_spawning_as_default_character))
                {
                    await MainMenu.MpPedCustomizationMenu.SpawnThisCharacter(GetResourceKvpString("vmenu_default_character"), false);
                }
                while (!IsScreenFadedIn() || IsPlayerSwitchInProgress() || IsPauseMenuActive() || GetIsLoadingScreenActive())
                {
                    await Delay(0);
                }
                if (MainMenu.WeaponLoadoutsMenu != null && MainMenu.WeaponLoadoutsMenu.WeaponLoadoutsSetLoadoutOnRespawn && IsAllowed(Permission.WLEquipOnRespawn))
                {
                    var saveName = GetResourceKvpString("vmenu_string_default_loadout");
                    if (!string.IsNullOrEmpty(saveName))
                    {
                        await SpawnWeaponLoadoutAsync(saveName, true, false, true);
                    }

                }
            }
        }

        /// <summary>
        /// Sets the addon models from the addons.json file.
        /// </summary>
        private void SetConfigOptions()
        {
            SetAddons();
            SetWhiteLists();
            SetExtras();
            SetTattoos();

            MainMenu.ConfigOptionsSetupComplete = true;
        }

        /// <summary>
        /// Sets the addon models from the addons.json file.
        /// </summary>
        private void SetAddons()
        {
            // reset addons
            VehicleSpawner.AddonVehicles = new Dictionary<string, uint>();
            WeaponOptions.AddonWeapons = new Dictionary<string, uint>();
            PlayerAppearance.AddonPeds = new Dictionary<string, uint>();
            MpPedCustomization.ExtraBlendableFaces = [];

            var jsonData = LoadResourceFile(GetCurrentResourceName(), "config/addons.json") ?? "{}";
            try
            {
                // load new addons.
                var addons = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(jsonData);

                // load vehicles
                if (addons.ContainsKey("vehicles"))
                {
                    foreach (var addon in addons["vehicles"])
                    {
                        if (!VehicleSpawner.AddonVehicles.ContainsKey(addon))
                        {
                            VehicleSpawner.AddonVehicles.Add(addon, Game.GenerateHashASCII(addon));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your addons.json file contains 2 or more entries with the same vehicle name! ({addon}) Please remove duplicate lines!");
                        }
                    }
                }

                // load weapons
                if (addons.ContainsKey("weapons"))
                {
                    foreach (var addon in addons["weapons"])
                    {
                        if (!WeaponOptions.AddonWeapons.ContainsKey(addon))
                        {
                            WeaponOptions.AddonWeapons.Add(addon, Game.GenerateHashASCII(addon));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your addons.json file contains 2 or more entries with the same weapon name! ({addon}) Please remove duplicate lines!");
                        }
                    }
                }

                // load peds.
                if (addons.ContainsKey("peds"))
                {
                    foreach (var addon in addons["peds"])
                    {
                        if (!PlayerAppearance.AddonPeds.ContainsKey(addon))
                        {
                            PlayerAppearance.AddonPeds.Add(addon, Game.GenerateHashASCII(addon));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your addons.json file contains 2 or more entries with the same ped name! ({addon}) Please remove duplicate lines!");
                        }
                    }
                }

                if (addons.ContainsKey("extra_blendable_faces"))
                {
                    foreach (var addon in addons["extra_blendable_faces"])
                    {
                        if (!MpPedCustomization.ExtraBlendableFaces.Contains(addon))
                        {
                            MpPedCustomization.ExtraBlendableFaces.Add(addon);
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your addons.json file contains 2 or more entries with the same extra blendable face name! ({addon}) Please remove duplicate lines!");
                        }
                    }
                }
            }
            catch (JsonReaderException ex)
            {
                Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Your addons.json file contains a problem! Error details: {ex.Message}\n\n");
            }
        }

        /// <summary>
        /// Sets the addon models from the addons.json file.
        /// </summary>
        private void SetWhiteLists()
        {
            // reset addons
            VehicleSpawner.WhitelistVehicles = new Dictionary<string, uint>();
            PlayerAppearance.WhitelistedPeds = new Dictionary<string, uint>();
            WeaponOptions.WeaponWhitelist = new Dictionary<string, uint>();

            var jsonData = LoadResourceFile(GetCurrentResourceName(), "config/model-whitelists.json") ?? "{}";
            try
            {
                // load new addons.
                var whitelists = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(jsonData);

                // load whitelist vehicles
                if (whitelists.ContainsKey("whitelistedvehicle"))
                {
                    foreach (var whitelist in whitelists["whitelistedvehicle"])
                    {
                        if (!VehicleSpawner.WhitelistVehicles.ContainsKey(whitelist))
                        {
                            VehicleSpawner.WhitelistVehicles.Add(whitelist, Game.GenerateHashASCII(whitelist));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your model-whitelists.json file contains 2 or more entries with the same vehicle name! ({whitelist}) Please remove duplicate lines!");
                        }
                    }
                }

                // load whitelisted peds.
                if (whitelists.ContainsKey("whitelistedpeds"))
                {
                    foreach (var whitelist in whitelists["whitelistedpeds"])
                    {
                        if (!PlayerAppearance.WhitelistedPeds.ContainsKey(whitelist))
                        {
                            PlayerAppearance.WhitelistedPeds.Add(whitelist, Game.GenerateHashASCII(whitelist));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your model-whitelists.json file contains 2 or more entries with the same ped name! ({whitelist}) Please remove duplicate lines!");
                        }
                    }
                }

                // load whitelisted weapon.
                if (whitelists.ContainsKey("whitelistedweapons"))
                {
                    foreach (var whitelist in whitelists["whitelistedweapons"])
                    {
                        if (!WeaponOptions.WeaponWhitelist.ContainsKey(whitelist))
                        {
                            WeaponOptions.WeaponWhitelist.Add(whitelist, Game.GenerateHashASCII(whitelist));
                        }
                        else
                        {
                            Debug.WriteLine($"[vMenu] [Error] Your model-whitelists.json file contains 2 or more entries with the same ped name! ({whitelist}) Please remove duplicate lines!");
                        }
                    }
                }
            }
            catch (JsonReaderException ex)
            {
                Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Your model-whitelists.json file contains a problem! Error details: {ex.Message}\n\n");
            }
        }
        /// <summary>
        /// Sets the extras labels from the extras.json file.
        /// </summary>
        private void SetExtras()
        {
            // reset addons
            VehicleOptions.VehicleExtras = new Dictionary<uint, Dictionary<int, string>>();

            string jsonData = LoadResourceFile(GetCurrentResourceName(), "config/extras.json") ?? "{}";

            try
            {
                // load new extras.
                var extras = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<int, string>>>(jsonData);

                foreach (string model in extras.Keys)
                {
                    uint modelHash = Game.GenerateHashASCII(model);

                    if (extras[model] != null && extras[model].Count > 0)
                    {
                        if (!VehicleOptions.VehicleExtras.ContainsKey(modelHash) || VehicleOptions.VehicleExtras[modelHash] == null)
                            VehicleOptions.VehicleExtras.Add(modelHash, extras[model]);
                        else
                        {
                            foreach(int extra in extras[model].Keys)
                            {
                                if(!VehicleOptions.VehicleExtras[modelHash].ContainsKey(extra))
                                    VehicleOptions.VehicleExtras[modelHash].Add(extra, extras[model][extra]);
                                else
                                    Debug.WriteLine($"[vMenu] [Warning] Your extras.json file contains 2 or more entries with the same extra index! ({model}, Extra {extra}) Please remove duplicate!");
                            }
                        }
                    }
                }
            }
            catch (JsonReaderException ex)
            {
                Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Your extras.json file contains a problem! Error details: {ex.Message}\n\n");
            }
        }

        private void SetTattoos()
        {
            TattoosData.Addons = [];

            var jsonData = LoadResourceFile(GetCurrentResourceName(), "config/tattoos.json") ?? "[]";
            try
            {
                List<Tattoo> addons = JsonConvert.DeserializeObject<List<Tattoo>>(jsonData);

                foreach (Tattoo tattoo in addons)
                {
                    if (!TattoosData.Addons.Exists(i => i.collectionName == tattoo.collectionName && i.name == tattoo.name))
                    {
                        TattoosData.Addons.Add(tattoo);
                    }
                    else
                    {
                        Debug.WriteLine($"[vMenu] [Error] Your tattoos.json file contains 2 or more entries with the same collection and tattoo names! ({tattoo.collectionName} & {tattoo.name}) Please remove duplicate lines!");
                    }
                }
            }
            catch (JsonReaderException ex)
            {
                Debug.WriteLine($"\n\n^1[vMenu] [ERROR] ^7Your tattoos.json file contains a problem! Error details: {ex.Message}\n\n");
            }
        }

        /// <summary>
        /// Update ban list.
        /// </summary>
        /// <param name="list"></param>
        private void UpdateBanList(string list)
        {
            MainMenu.BannedPlayersMenu?.UpdateBanList(list);
        }

        /// <summary>
        /// Used for cheaters.
        /// </summary>
        private void GoodBye()
        {
            ForceSocialClubUpdate();
        }

        /// <summary>
        /// Loads/unloads the snow fx particles if needed.
        /// </summary>
        private async Task UpdateWeatherParticles()
        {
            ForceSnowPass(IsSnowEnabled);
            SetForceVehicleTrails(IsSnowEnabled);
            SetForcePedFootstepsTracks(IsSnowEnabled);
            if (IsSnowEnabled)
            {
                if (!HasNamedPtfxAssetLoaded("core_snow"))
                {
                    RequestNamedPtfxAsset("core_snow");
                    while (!HasNamedPtfxAssetLoaded("core_snow"))
                    {
                        await Delay(0);
                    }
                }
                UseParticleFxAssetNextCall("core_snow");
            }
            else
            {
                RemoveNamedPtfxAsset("core_snow");
            }
        }

        /// <summary>
        /// OnTick loop to keep the weather synced.
        /// </summary>
        /// <returns></returns>
        private async Task WeatherSync()
        {
            await UpdateWeatherParticles();
            SetArtificialLightsState(IsBlackoutEnabled);
            SetArtificialLightsStateAffectsVehicles(!IsVehicleLightsEnabled);

            if (GetNextWeatherType() != GetHashKey(GetServerWeather))
            {
                SetWeatherTypeOvertimePersist(GetServerWeather, (float)WeatherChangeTime);
                await Delay((WeatherChangeTime * 1000) + 2000);

                TriggerEvent("vMenu:WeatherChangeComplete", GetServerWeather);
            }

            await Delay(1000);
        }


        /// <summary>
        /// This function will take care of time sync. It'll be called once, and never stop.
        /// </summary>
        /// <returns></returns>
        private async Task TimeSync()
        {
            NetworkOverrideClockTime(GetServerHours, GetServerMinutes, 0);
            if (IsServerTimeFrozen || IsServerTimeSyncedWithMachineTime)
            {
                await Delay(5);
            }
            else
            {
                await Delay(MathUtil.Clamp(GetServerMinuteDuration, 100, 2000));
            }
        }

        /// <summary>
        /// Set the cloud hat type.
        /// </summary>
        /// <param name="opacity"></param>
        /// <param name="cloudsType"></param>
        private void SetClouds(float opacity, string cloudsType)
        {
            if (opacity == 0f && cloudsType == "removed")
            {
                ClearCloudHat();
            }
            else
            {
                SetCloudHatOpacity(opacity);
                SetCloudHatTransition(cloudsType, 4f);
            }
        }

        /// <summary>
        /// Used by events triggered from the server to notify a user.
        /// </summary>
        /// <param name="message"></param>
        private void NotifyPlayer(string message)
        {
            Notify.Custom(message, true, true);
        }

        /// <summary>
        /// Kill this player, poor thing, someone wants you dead... R.I.P.
        /// </summary>
        private void KillMe(string sourceName)
        {
            Notify.Alert($"You have been killed by <C>{GetSafePlayerName(sourceName)}</C>~s~ using the ~r~Kill Player~s~ option in vMenu.");
            SetEntityHealth(Game.PlayerPed.Handle, 0);
        }

        /// <summary>
        /// Clear the area around the provided x, y, z coordinates. Clears everything like (destroyed) objects, peds, (ai) vehicles, etc.
        /// Also restores broken streetlights, etc.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        private void ClearAreaNearPos(Vector3 position) => ClearAreaOfEverything(position.X, position.Y, position.Z, 100f, false, false, false, false);

        /// <summary>
        /// Updates ped decorators for the clothing animation when players have joined.
        /// </summary>
        private async void UpdatePedDecors()
        {
            await Delay(1000);
            var backup = PlayerAppearance.ClothingAnimationType;
            PlayerAppearance.ClothingAnimationType = -1;
            await Delay(100);
            PlayerAppearance.ClothingAnimationType = backup;
        }

        /// <summary>
        /// Updates the teleports locations data from the server side locations.json, because that doesn't update client side on change.
        /// </summary>
        /// <param name="jsonData"></param>
        private void UpdateTeleportLocations(string jsonData)
        {
            MiscSettings.TpLocations = JsonConvert.DeserializeObject<List<vMenuShared.ConfigManager.TeleportLocation>>(jsonData);
        }
    }
}
